import{a as e,n as t,t as n}from"./jsx-runtime-BVQXJMCF.js";import{s as r,t as i}from"./Ui-DUyl9t38.js";import{G as a,H as o}from"./index-Fqu0rJTh.js";import"./custom-code-D6y0X4ha.js";import{t as s}from"./controller-uTEBxHDT.js";/* empty css                        *//* empty css                 */import{n as c,t as l}from"./algorithms-Ciy6UhR-.js";var u=e(t(),1),d={schemaVersion:`1.0.0`,id:`catalog.cpp.kmp`,version:`1.0.0`,packageRef:{id:`content.c.p05`,version:`1.0.0`},learningAuthority:!1,case:{id:`case.cpp.kmp`,version:`1.0.0`,programRef:{id:`program.cpp.kmp`,version:`1.0.0`},language:`cpp`,engine:`engine.rust.advanced`,sourceFile:`content/algorithms/cpp/kmp-1.0.0.cpp`,prerequisiteLessonRef:{id:`lesson.c.nested-loops`,version:`1.0.0`},knowledgeRefs:[{id:`knowledge.c.loops`,version:`1.0.0`},{id:`knowledge.c.variables`,version:`1.0.0`}],title:`KMP字符串匹配`,topic:`保留已知前缀，失配时回退模式指针`,statement:`先构造模式的最长真前后缀长度表，再在文本中查找首个完整匹配，返回从0开始的位置。`,platformConstraints:`文本与模式各0～30个可打印ASCII字节（空格至~）。空字段是空串，空格按原样参与匹配；空模式返回0，未匹配返回−1。字符位置与字节下标在此范围内一致。`,defaults:{text:`ababcabcabababd`,pattern:`ababd`},strategy:`prefix存长度，失配沿真实已知前缀继续`,explanation:[`prefix[i]表示pattern[0..i]最长真前缀同时为后缀的长度；真前缀不含整个片段，因此prefix[0]=0，且prefix[i]不超过i。这里不是使用−1哨兵的next表。`,`建表时buildIndex指向待计算项，border是当前候选前后缀长度。字符失配且border>0时，实际执行border=prefix[border−1]；找到可延续的相等字符后再增长，随后写入prefix[buildIndex]。未来槽保持未初始化。`,`匹配时textIndex逐项前进，matched记录已匹配的模式前缀长度。失配只沿prefix[matched−1]回退matched，保留已知字符关系，不把文本指针退回重扫。matched等于模式长度时，首个起点为textIndex−m+1。`,`空模式单独返回0，空文本与非空模式返回−1。存在重叠或多个匹配时只返回首个；重复前后缀仍影响建表和匹配中的候选回退。所有字符、prefix、指针与高亮来自当前真实执行，不由前端重新计算。`],complexity:`建表O(m)，匹配O(n)，含输入读取/值复制总O(n+m)；prefix额外O(m)，输入字符串O(n+m)。`,derivation:`建表指针最多前进m−1次，每次border增长最多1，所有回退可摊到此前增长；匹配中文本只前进n次，matched增长与回退同样累计O(n)。固定prefix[30]是有界教学容量，按一般规模为O(m)；不是每次失配重扫整个前缀。`,pitfalls:[`prefix是长度；回退下标为matched−1或border−1，不能写成prefix[matched]形成停滞。`,`必须先检查模式为空，避免读取pattern[0]；空格不是缺失输入，也不应被trim。`,`字节索引仅在本可打印ASCII域与字符位置一致；不支持Unicode字符、字素或多字节中文输入。`,`未计算prefix槽不补0；程序退出会销毁局部对象，后退可恢复。`],reviewQuestion:`为什么失配后可以保留prefix[matched−1]个字符，而文本指针不必退回？`,samples:[{key:`empty-both`,text:``,pattern:``,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`empty-text`,text:``,pattern:`a`,expectedIndex:-1,expectedStdout:`-1
`,expectedReturn:0},{key:`empty-pattern`,text:`abc`,pattern:``,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`single-hit`,text:`a`,pattern:`a`,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`single-miss`,text:`a`,pattern:`b`,expectedIndex:-1,expectedStdout:`-1
`,expectedReturn:0},{key:`head`,text:`abcde`,pattern:`abc`,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`tail`,text:`abcde`,pattern:`cde`,expectedIndex:2,expectedStdout:`2
`,expectedReturn:0},{key:`default-middle`,text:`ababcabcabababd`,pattern:`ababd`,expectedIndex:10,expectedStdout:`10
`,expectedReturn:0},{key:`missing`,text:`abc`,pattern:`d`,expectedIndex:-1,expectedStdout:`-1
`,expectedReturn:0},{key:`pattern-longer`,text:`abc`,pattern:`abcd`,expectedIndex:-1,expectedStdout:`-1
`,expectedReturn:0},{key:`exact`,text:`abab`,pattern:`abab`,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`overlap-first`,text:`ababab`,pattern:`abab`,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`repeated-border`,text:`aaaaab`,pattern:`aaab`,expectedIndex:2,expectedStdout:`2
`,expectedReturn:0},{key:`multiple-fallback`,text:`ababababac`,pattern:`ababac`,expectedIndex:4,expectedStdout:`4
`,expectedReturn:0},{key:`near-end-miss`,text:`aaaaa`,pattern:`aaab`,expectedIndex:-1,expectedStdout:`-1
`,expectedReturn:0},{key:`repeated-candidate`,text:`baaaaa`,pattern:`aaa`,expectedIndex:1,expectedStdout:`1
`,expectedReturn:0},{key:`embedded-spaces`,text:`a b c`,pattern:`b `,expectedIndex:2,expectedStdout:`2
`,expectedReturn:0},{key:`spaces-only`,text:`   `,pattern:` `,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`spaces-empty-pattern`,text:`   `,pattern:``,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`printable-ends`,text:` ~"\\<>[]{}!?0Az`,pattern:`?0A`,expectedIndex:11,expectedStdout:`11
`,expectedReturn:0},{key:`quotes-backslash`,text:`x"\\?y`,pattern:`"\\?`,expectedIndex:1,expectedStdout:`1
`,expectedReturn:0},{key:`maximum-exact`,text:`aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`,pattern:`aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`,expectedIndex:0,expectedStdout:`0
`,expectedReturn:0},{key:`maximum-tail`,text:`aaaaaaaaaaaaaaaaaaaaaaaaaaaaab`,pattern:`aaaaaaaaaaaaaab`,expectedIndex:15,expectedStdout:`15
`,expectedReturn:0},{key:`maximum-fallback-miss`,text:`aaaaaaaaaaaaaaaaaaaaaaaaaaaaac`,pattern:`aaaaaaaaaaaaaaaaaaaaaaaaaaaaab`,expectedIndex:-1,expectedStdout:`-1
`,expectedReturn:0}]}},f=`#include <iostream>
#include <string>
int main() {
  std::string text;
  std::string pattern;
  int phase = 0;
  std::getline(std::cin, text);
  std::getline(std::cin, pattern);
  int n = text.size();
  int m = pattern.size();
  int prefix[30];
  int built = 0;
  int buildIndex = 1;
  int border = 0;
  int textIndex = 0;
  int matched = 0;
  int answer = -1;
  phase = 1;
  if (m > 0) {
    prefix[0] = 0;
    built = 1;
    while (buildIndex < m) {
      while (border > 0 && pattern[buildIndex] != pattern[border]) {
        border = prefix[border - 1];
      }
      if (pattern[buildIndex] == pattern[border]) { border = border + 1; }
      prefix[buildIndex] = border;
      built = buildIndex + 1;
      buildIndex = buildIndex + 1;
    }
  }
  phase = 2;
  if (m == 0) { answer = 0; }
  else {
    while (textIndex < n && answer < 0) {
      while (matched > 0 && text[textIndex] != pattern[matched]) {
        matched = prefix[matched - 1];
      }
      if (text[textIndex] == pattern[matched]) { matched = matched + 1; }
      if (matched == m) { answer = textIndex - m + 1; }
      textIndex = textIndex + 1;
    }
  }
  phase = 3;
  std::cout << answer << "\\n";
  return 0;
}
`,p=d.case;d.id,d.version;var m=e=>typeof e==`string`&&/^[\x20-\x7e]{0,30}$/.test(e);function h(e,t){return{valid:m(e)&&m(t),issue:`文本与模式都必须为0～30个可打印ASCII字节（空格至~）；空字段是空串，空格不省略。`}}function g(e,t){if(!m(e)||!m(t))throw Error(`E_INPUT_INVALID`);return{source:f,input:{kind:`lines`,values:[e,t]}}}var _=[`phase`,`n`,`m`,`built`,`buildIndex`,`border`,`textIndex`,`matched`,`answer`];function v(e){let t=t=>e.objects.find(e=>e.alive&&e.name===t),n=Object.fromEntries(_.map(e=>{let n=t(e)?.cells[0]?.value;return[e,typeof n==`number`?n:null]})),r=[`text`,`pattern`].map(e=>{let n=t(e),r=n?.cells[0]?.value;return{name:e,present:!!n,value:typeof r==`string`?r:null}}),i=t(`prefix`),a=n.m;return{scalars:n,strings:r,prefix:{present:!!i,capacity:i?.length??null,extent:a,values:i&&a!==null?Array.from({length:Math.max(0,Math.min(i.length,a))},(e,t)=>{let n=i.cells.find(e=>e.byteOffset===t*4)?.value;return typeof n==`number`?n:null}):[]}}}var y=n();function b({state:e}){let t=v(e),n=t.scalars;return(0,y.jsxs)(`section`,{className:`kmp-state`,"aria-label":`KMP真实字符与前缀状态`,"data-testid":`kmp-state`,"data-phase":n.phase??`absent`,children:[(0,y.jsx)(`h3`,{children:`字符、前缀表与指针`}),(0,y.jsx)(`p`,{children:n.phase===null?`本阶段对象尚未声明或已结束；后退可查看存活状态。`:[`读取输入`,`构造前缀表`,`匹配文本`,`搜索结束`][n.phase]}),(0,y.jsx)(`p`,{children:`下标从0开始，在可打印ASCII范围内同时表示字节和字符位置。␠表示一个实际空格；空串没有字符槽。`}),t.strings.map(e=>{let t=e.name===`text`?n.phase===2&&n.textIndex!==null?[n.textIndex]:[]:n.phase===1?[n.buildIndex,n.border].filter(e=>e!==null):n.phase===2&&n.matched!==null?[n.matched]:[];return(0,y.jsxs)(`section`,{"data-testid":`kmp-string`,"data-name":e.name,"data-present":e.present,"data-value":e.value??``,children:[(0,y.jsx)(`h4`,{children:e.name===`text`?`text · 文本`:`pattern · 模式`}),e.value===null?(0,y.jsx)(`p`,{children:`此字符串尚未声明或已结束。`}):(0,y.jsxs)(y.Fragment,{children:[(0,y.jsxs)(`p`,{children:[`当前真实长度`,e.value.length,`；`,t.length?`指针位置${t.join(`、`)}。等于长度时位于边界，不读取字符。`:`此阶段没有字符读取指针。`]}),e.value.length?(0,y.jsx)(`ol`,{className:`advanced-array-grid kmp-character-grid`,children:Array.from(e.value,(e,n)=>(0,y.jsxs)(`li`,{"data-index":n,"data-current":t.includes(n),children:[(0,y.jsxs)(`small`,{children:[`[`,n,`]`,t.includes(n)?` · 指针`:``]}),(0,y.jsx)(`strong`,{children:e===` `?`␠`:e}),(0,y.jsxs)(`small`,{children:[`ASCII `,e.charCodeAt(0)]})]},n))}):(0,y.jsx)(`p`,{children:`空串（长度0）。`})]})]},e.name)}),(0,y.jsxs)(`section`,{"data-testid":`kmp-prefix`,"data-present":t.prefix.present,"data-extent":t.prefix.extent??`unknown`,children:[(0,y.jsx)(`h4`,{children:`prefix · 最长真前后缀长度`}),t.prefix.present?(0,y.jsxs)(y.Fragment,{children:[(0,y.jsxs)(`p`,{children:[`物理容量`,t.prefix.capacity,`，当前逻辑长度`,t.prefix.extent??`尚未声明m`,`；built=`,n.built??`尚未声明`,`。尚未写入的槽保持未初始化。`]}),t.prefix.values.length?(0,y.jsx)(`ol`,{className:`advanced-array-grid`,children:t.prefix.values.map((e,t)=>(0,y.jsxs)(`li`,{"data-index":t,"data-current":n.phase===1&&n.buildIndex===t,children:[(0,y.jsxs)(`small`,{children:[`[`,t,`]`]}),(0,y.jsx)(`strong`,{children:e===null?`未初始化`:e})]},t))}):(0,y.jsx)(`p`,{children:`当前没有逻辑前缀项。`})]}):(0,y.jsx)(`p`,{children:`此前缀数组尚未声明或已结束。`})]}),(0,y.jsx)(`dl`,{className:`kmp-scalars`,children:Object.entries(n).map(([e,t])=>(0,y.jsxs)(`div`,{children:[(0,y.jsx)(`dt`,{children:e}),(0,y.jsx)(`dd`,{"data-testid":`kmp-scalar`,"data-name":e,children:t??`尚未声明或已结束`})]},e))}),(0,y.jsx)(`p`,{className:`muted`,children:`phase：0读取、1建表、2匹配、3结束。buildIndex/border用于建表，textIndex/matched用于匹配；它们都是程序实际标量。完整匹配后matched可以等于m，随后不再读取pattern[matched]。`})]})}function x(){let{service:e}=a(),[t]=(0,u.useState)(()=>new s),[n,d]=(0,u.useState)(p.defaults),[f,_]=(0,u.useState)(``),v=(0,u.useSyncExternalStore)(t.subscribe,t.getSnapshot),x=h(n.text,n.pattern),S=x.valid?g(n.text,n.pattern):null;(0,u.useEffect)(()=>{t.setSource(g(p.defaults.text,p.defaults.pattern).source,`cpp`);let n=e.subscribeSessionInvalidation(()=>t.invalidate()),r=()=>{document.visibilityState!==`visible`&&t.pause()};return document.addEventListener(`visibilitychange`,r),()=>{t.invalidate(),n(),document.removeEventListener(`visibilitychange`,r)}},[t,e]);let C=(e,n=``)=>{t.invalidate(),t.setSource(h(e.text,e.pattern).valid?g(e.text,e.pattern).source:``,`cpp`),d(e),_(n)};return(0,y.jsxs)(`div`,{className:`advanced-course example-page sieve-page kmp-page`,"data-testid":`kmp-workspace`,"data-case":p.id,"data-state":v.status,"data-cursor":v.view.cursor,"data-length":v.view.length,children:[(0,y.jsx)(i,{items:[{label:`进阶课程`,to:`/advanced`},{label:`算法与演示`,to:`/cases`},{label:p.title}]}),(0,y.jsxs)(`header`,{className:`advanced-heading`,children:[(0,y.jsx)(`h1`,{tabIndex:-1,children:p.title}),(0,y.jsx)(`p`,{children:p.statement})]}),(0,y.jsxs)(`form`,{className:`example-input kmp-input`,onSubmit:e=>{e.preventDefault(),S&&v.status!==`running`&&t.execute(S.source,`cpp`,S.input)},children:[[`text`,`pattern`].map(e=>(0,y.jsxs)(`label`,{children:[e===`text`?`文本 text`:`模式 pattern`,(0,y.jsx)(`input`,{"data-testid":`kmp-`+e+`-input`,value:n[e],maxLength:1024,spellCheck:!1,autoComplete:`off`,"aria-invalid":!m(n[e]),"aria-describedby":`kmp-input-help`,onChange:t=>C({...n,[e]:t.target.value})}),(0,y.jsx)(`small`,{children:m(n[e])?`${n[e].length}/30 字节；${n[e]===``?`明确空串`:`空格按原样保留`}`:`输入超出长度或字符范围`})]},e)),(0,y.jsxs)(`div`,{className:`inline-actions`,children:[(0,y.jsx)(`button`,{className:`button button-primary`,type:`submit`,disabled:!S||v.status===`running`,children:`运行C++ KMP`}),(0,y.jsx)(`button`,{className:`button`,type:`button`,onClick:()=>C(p.defaults),children:`恢复默认输入`}),v.status===`running`&&(0,y.jsx)(`button`,{className:`button`,type:`button`,onClick:()=>t.cancel(),children:`取消运行`})]}),(0,y.jsxs)(`label`,{children:[`边界样例`,(0,y.jsxs)(`select`,{"aria-label":`KMP边界样例`,value:f,onChange:e=>{let t=p.samples.find(t=>t.key===e.target.value);t&&C({text:t.text,pattern:t.pattern},t.key)},children:[(0,y.jsx)(`option`,{value:``,children:`选择一组输入`}),p.samples.map(e=>(0,y.jsxs)(`option`,{value:e.key,children:[e.key,` · 文本`,e.text.length,`/模式`,e.pattern.length,`字节`]},e.key))]})]}),(0,y.jsx)(`p`,{id:`kmp-input-help`,role:x.valid?void 0:`alert`,children:x.valid?p.platformConstraints:x.issue})]}),(0,y.jsx)(c,{spec:p}),(0,y.jsx)(`p`,{className:`muted`,children:`独立C++教学演示，不保存文本、模式或轨迹，不计学习完成或积分。输出首个匹配位置，前缀表和指针来自真实执行。`}),(0,y.jsx)(l,{controller:t,snap:v,source:S?.source??null,renderArrays:e=>(0,y.jsx)(b,{state:e})}),(0,y.jsx)(o,{}),(0,y.jsxs)(`nav`,{className:`advanced-bottom`,"aria-label":`KMP导航`,children:[(0,y.jsx)(r,{to:`/advanced/algorithms`,children:`筛法与序列`}),(0,y.jsx)(r,{to:`/cases`,children:`算法与演示`}),(0,y.jsx)(r,{to:`/advanced`,children:`进阶课程与复习入口`})]})]})}export{x as default};