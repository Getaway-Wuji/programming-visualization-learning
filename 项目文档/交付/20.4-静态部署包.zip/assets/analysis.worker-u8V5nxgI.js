(function(){function e(e,t,r){let i=o(e,p.__wbindgen_malloc,p.__wbindgen_realloc),a=f,c=o(t,p.__wbindgen_malloc,p.__wbindgen_realloc),l=f,u=p.analyze_code_draft(i,a,c,l,r);if(u[3])throw s(u[2]);var d=n(u[0],u[1]).slice();return p.__wbindgen_free(u[0],u[1]*1,1),d}function t(){return{__proto__:null,"./c_viz_wasm_bg.js":{__proto__:null,__wbg_now_1b05fba468b632aa:function(){return performance.now()},__wbindgen_generic_0000000000000001:function(e,t){return r(e,t)},__wbindgen_init_externref_table:function(){let e=p.__wbindgen_externrefs,t=e.grow(4);e.set(0,void 0),e.set(t+0,void 0),e.set(t+1,null),e.set(t+2,!0),e.set(t+3,!1)}}}}function n(e,t){return e>>>=0,a().subarray(e/1,e/1+t)}function r(e,t){return u(e>>>0,t)}let i=null;function a(){return(i===null||i.byteLength===0)&&(i=new Uint8Array(p.memory.buffer)),i}function o(e,t,n){if(n===void 0){let n=d.encode(e),r=t(n.length,1)>>>0;return a().subarray(r,r+n.length).set(n),f=n.length,r}let r=e.length,i=t(r,1)>>>0,o=a(),s=0;for(;s<r;s++){let t=e.charCodeAt(s);if(t>127)break;o[i+s]=t}if(s!==r){s!==0&&(e=e.slice(s)),i=n(i,r,r=s+e.length*3,1)>>>0;let t=a().subarray(i+s,i+r),o=d.encodeInto(e,t);s+=o.written,i=n(i,r,s,1)>>>0}return f=s,i}function s(e){let t=p.__wbindgen_externrefs.get(e);return p.__externref_table_dealloc(e),t}let c=new TextDecoder(`utf-8`,{ignoreBOM:!0,fatal:!0});c.decode();let l=0;function u(e,t){return l+=t,l>=2146435072&&(c=new TextDecoder(`utf-8`,{ignoreBOM:!0,fatal:!0}),c.decode(),l=t),c.decode(a().subarray(e,e+t))}let d=new TextEncoder;`encodeInto`in d||(d.encodeInto=function(e,t){let n=d.encode(e);return t.set(n),{read:e.length,written:n.length}});let f=0,p;function m(e,t){return p=e.exports,i=null,p.__wbindgen_start(),p}async function h(e,t){if(typeof Response==`function`&&e instanceof Response){if(!e.ok)throw Error(`failed to fetch Wasm: ${e.status} ${e.statusText} fetching '${e.url}'`);if(typeof WebAssembly.instantiateStreaming==`function`)try{return await WebAssembly.instantiateStreaming(e,t)}catch(t){if(n(e.type)&&e.headers.get(`Content-Type`)!==`application/wasm`)console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n",t);else throw t}let r=await e.arrayBuffer();return await WebAssembly.instantiate(r,t)}{let n=await WebAssembly.instantiate(e,t);return n instanceof WebAssembly.Instance?{instance:n,module:e}:n}function n(e){switch(e){case`basic`:case`cors`:case`default`:return!0}return!1}}async function ee(e){if(p!==void 0)return p;e!==void 0&&(Object.getPrototypeOf(e)===Object.prototype?{module_or_path:e}=e:console.warn(`using deprecated parameters for the initialization function; pass a single object instead`)),e===void 0&&(e=new URL(`/assets/c_viz_wasm_bg-tXcnXUY_.wasm`,``+self.location.href));let n=t();(typeof e==`string`||typeof Request==`function`&&e instanceof Request||typeof URL==`function`&&e instanceof URL)&&(e=fetch(e));let{instance:r,module:i}=await h(await e,n);return m(r,i)}let g={practiceVersion:`1.0.0`,file:`content/practice/course-practice-1.0.0.json`,sha256:`9f2e834d76f1bbf5b3f8aaaa0de1326dba8cedd23a735d9502a306a32a819ed2`,bytes:29102,sourceSha256:`713133313e65ba9ea000daa18d5feaea84beeb65f296b8102edc5de114fa2611`,capabilities:[`temporary-judgement`,`temporary-review`],fullContentPublication:!1,learningEvents:!1},_={enabled:!0,file:`content/course/course-bundle-1.2.0.json`,bytes:725431,sha256:`0a0f9de9cd62a694fe8cf9b43d8c10d5b70d1decc9ab9fd640743b083dc78b50`,registered:!0,sourceSha256:`85fd3d38faf4f677e50c860d30a0390b84f2d092a77fdcd08036a4d4e5a57948`,bugSupplement:{registryRef:{id:`bug-catalog.c.syntax-logic`,version:`1.0.0`},sourceSha256:`6a11fbe8e727d61a3059bd37a17b95427bad365713888225eb69e96f141a172b`},memoryBugSupplement:{registryRef:{id:`bug-catalog.cpp.memory-loop`,version:`1.0.0`},sourceSha256:`781db995e547d3b59a19cf7edd1601d9c3d5391f026c0400a73c64acf7dd110f`},projections:{reading:{file:`content/reading/course-reading-1.1.0.json`,bytes:301635,sha256:`e4803ac3161ffdfc4412f945507a3e6031e889d7cd9c8fc672ef825ffc67da2c`},practice:{file:`content/practice/course-practice-1.2.0.json`,bytes:180494,sha256:`12107b9aa4a0408636fcfb6002061fb7152910ce8f8560a4cd235c4a9f011331`},cases:{file:`content/case-view/case-view-1.1.0.json`,bytes:37098,sha256:`a389fea06289ffa3da40ff9f0f28296e498d6d5be54dc0d206885bec8d57d3be`},learning:{file:`content/learning/course-learning-1.0.68.json`,bytes:29635,sha256:`76382839b4f1e4c586197248ca33e4b841ae36d7d4397a3d738cea7fac652c9a`}}};function v(e){e&&e.chapters.map(e=>({id:e.id,title:e.title,description:`按推荐顺序学习本章的 ${e.lessonRefs.length} 个小节。`,number:String(e.order).padStart(2,`0`)})),e&&e.lessons.map(t=>({id:t.id,title:t.title,chapterId:t.chapterRef.id,exerciseId:t.requiredExerciseRefs[0].id,exerciseTitle:e.exercises.find(e=>e.id===t.requiredExerciseRefs[0].id)?.title??`必修练习`,caseIds:t.caseRefs.map(e=>e.id)}))}var y={registryVersion:`1.0.0`,registryRef:{id:`bug-catalog.c.syntax-logic`,version:`1.0.0`},packageRef:{id:`content.c.p05`,version:`1.0.0`},questions:[{exerciseRef:{id:`exercise.c.bug-semicolon`,version:`1.0.0`},baseExerciseRef:{id:`exercise.c.echo`,version:`1.1.0`},category:`syntax`,title:`输出语句少了什么？`,prompt:`修复这份输出程序的语法错误。保留输入声明，让任意合法x都被原样输出，末尾换行；不要打印固定答案。`,tests:[{caseKey:`negative`,input:{x:-9},expectedStdout:`-9
`,expectedExitCode:0},{caseKey:`zero`,input:{x:0},expectedStdout:`0
`,expectedExitCode:0},{caseKey:`positive`,input:{x:7},expectedStdout:`7
`,expectedExitCode:0},{caseKey:`upper`,input:{x:999},expectedStdout:`999
`,expectedExitCode:0}],brokenBody:`printf("%d\\n", x)
return 0;`,solutionBody:`printf("%d\\n", x);
return 0;`,alternativeBody:`int copy = x;
printf("%d\\n", copy);
return 0;`,hints:[`先读真实语法诊断，发现位置可能在问题后面。`,`检查printf语句是否完整结束。`,`调用右括号后需要分号；同时保留换行输出。`],explanation:`缺分号让解析器在下一条语句附近停止。补齐后还要真正输出输入x；四组测试和输入依赖目标共同判定，不比较答案文本。`},{exerciseRef:{id:`exercise.c.bug-parenthesis`,version:`1.0.0`},baseExerciseRef:{id:`exercise.c.two-x-plus-three`,version:`1.1.0`},category:`syntax`,title:`输出调用没有闭合`,prompt:`补齐语法错误，并计算x的两倍加三，输出整数及换行。保留输入绑定，真实使用乘法和加法；合法等价顺序或临时变量均可。`,tests:[{caseKey:`negative`,input:{x:-4},expectedStdout:`-5
`,expectedExitCode:0},{caseKey:`zero`,input:{x:0},expectedStdout:`3
`,expectedExitCode:0},{caseKey:`positive`,input:{x:5},expectedStdout:`13
`,expectedExitCode:0},{caseKey:`upper`,input:{x:999},expectedStdout:`2001
`,expectedExitCode:0}],brokenBody:`printf("%d\\n", x * 2 + 3;
return 0;`,solutionBody:`printf("%d\\n", x * 2 + 3);
return 0;`,alternativeBody:`int doubled = x * 2;
int answer = 3 + doubled;
printf("%d\\n", answer);
return 0;`,hints:[`分清算式和包住整个调用的括号。`,`检查printf从左括号开始的参数列表。`,`在分号前补齐右括号；算式仍须先乘二再加三。`],explanation:`参数表达式完成后，printf调用还需要右括号。结构修复与数学目标是两件事：错误的2*(x+3)即使可执行仍不能通过。`},{exerciseRef:{id:`exercise.c.bug-zero-branch`,version:`1.0.0`},baseExerciseRef:{id:`exercise.c.nonnegative`,version:`1.1.0`},category:`logic`,title:`零走错了分支`,prompt:`修复边界判断：x非负时输出1，否则输出0，末尾换行。必须保留真实if/else及输入依赖，两条路径都要在测试中执行。`,tests:[{caseKey:`negative`,input:{x:-3},expectedStdout:`0
`,expectedExitCode:0},{caseKey:`zero`,input:{x:0},expectedStdout:`1
`,expectedExitCode:0},{caseKey:`positive`,input:{x:4},expectedStdout:`1
`,expectedExitCode:0},{caseKey:`upper`,input:{x:999},expectedStdout:`1
`,expectedExitCode:0}],brokenBody:`if (x > 0) { printf("1\\n"); } else { printf("0\\n"); }
return 0;`,solutionBody:`if (x >= 0) { printf("1\\n"); } else { printf("0\\n"); }
return 0;`,alternativeBody:`if (x < 0) { printf("0\\n"); } else { printf("1\\n"); }
return 0;`,hints:[`程序可以正常结束，但输出不一定符合题意。`,`比较负数、零、正数分别经过哪条路径。`,`零属于非负数；也可以反过来先判断是否为负。`],explanation:`严格大于零遗漏了零。修复可以采用x>=0，也可以用x<0调换分支；真实判题同时核对输出和if/else覆盖，不要求固定写法。`},{exerciseRef:{id:`exercise.c.bug-sum-initial`,version:`1.0.0`},baseExerciseRef:{id:`exercise.c.array-sum`,version:`1.1.0`},category:`logic`,title:`总和为什么总多一？`,prompt:`修复数组累加程序，真实遍历逻辑范围[0,n)，输出总和及换行。空数组的和为0；保留输入和n，不读取空数组占位元素。`,tests:[{caseKey:`empty`,input:{values:[]},expectedStdout:`0
`,expectedExitCode:0},{caseKey:`single`,input:{values:[4]},expectedStdout:`4
`,expectedExitCode:0},{caseKey:`mixed`,input:{values:[-2,5]},expectedStdout:`3
`,expectedExitCode:0},{caseKey:`seven`,input:{values:[7,-3,0,5,-3,2,9]},expectedStdout:`17
`,expectedExitCode:0}],brokenBody:`int sum = 1;
for (int i = 0; i < n; i = i + 1) { sum = sum + values[i]; }
printf("%d\\n", sum);
return 0;`,solutionBody:`int sum = 0;
for (int i = 0; i < n; i = i + 1) { sum = sum + values[i]; }
printf("%d\\n", sum);
return 0;`,alternativeBody:`int total = 0;
for (int i = n - 1; i >= 0; i = i - 1) { total = total + values[i]; }
printf("%d\\n", total);
return 0;`,hints:[`比较期望输出和实际输出的差，再观察变量初始值。`,`空数组不进入循环，此时输出应是多少？`,`加法累计从0开始；前向或后向遍历都要覆盖全部逻辑元素。`],explanation:`初值1在任何输入上都会多加一。初值改为0后，空数组无需特殊读取；合法反向遍历也能通过实际求和与遍历目标。`}]};function b(e){return e&&typeof e==`object`&&(Object.values(e).forEach(b),Object.freeze(e)),e}b(y);let x=y.questions,S=y.registryRef,C=(e,t)=>e.id===t.id&&e.version===t.version;if(y.registryVersion!==`1.0.0`||x.length!==4||new Set(x.map(e=>e.exerciseRef.id)).size!==4||x.filter(e=>e.category===`syntax`).length!==2||x.filter(e=>e.category===`logic`).length!==2||x.some(e=>e.tests.length!==4||new Set(e.tests.map(e=>e.caseKey)).size!==4||e.hints.length!==3||e.tests.some(e=>e.expectedExitCode!==0)))throw Error(`BUG_REGISTRY_INVALID`);function w(e){return e.length===36&&x.every(t=>{let n=e.find(e=>C(e.ref,t.exerciseRef)),r=e.find(e=>C(e.ref,t.baseExerciseRef));return n&&r&&C(n.lessonRef,r.lessonRef)&&n.learningRevision===1&&n.acceptedPriorVersions.length===0&&n.caseKeys.length===4&&n.caseKeys.every((e,n)=>e===t.tests[n].caseKey)})}var T={registryVersion:`1.0.0`,registryRef:{id:`bug-catalog.cpp.memory-loop`,version:`1.0.0`},packageRef:{id:`content.c.p05`,version:`1.0.0`},questions:[{exerciseRef:{id:`exercise.cpp.bug-uninitialized-pointer`,version:`1.0.0`},programRef:{id:`program.cpp.bug-uninitialized-pointer`,version:`1.0.0`},lessonRef:{id:`lesson.c.scope-shadowing`,version:`1.0.0`},language:`cpp`,category:`pointer`,title:`指针还没有目标`,prompt:`让指针指向仍存活的输入变量，再实际解引用并输出输入及换行。`,goal:`indirect-read`,brokenSource:`#include <iostream>
int main() {
  int x;
  std::cin >> x;
  int *p;
  std::cout << *p << "\\n";
  return 0;
}
`,solutionSource:`#include <iostream>
int main() {
  int x;
  std::cin >> x;
  int *p = &x;
  std::cout << *p << "\\n";
  return 0;
}
`,alternativeSource:`#include <iostream>
int main() {
  int x;
  std::cin >> x;
  int *p = nullptr;
  p = &x;
  std::cout << *p << "\\n";
  return 0;
}
`,hints:[`先运行并走到真实错误位置，观察p的值。`,`尚未初始化与已经初始化为空不同；现在p还没有有效引用。`,`x仍在main内存活，可以让p保存x的地址。`],explanation:`声明int *p并没有让它指向对象。用目标变量的地址初始化p（这里是&x），再访问*p。nullptr只是已初始化的空指针，仍不能解引用；另一正确写法先设nullptr再赋&x。原错误位置来自Rust实际读取，而非预设行号。`,tests:[{caseKey:`negative`,input:[-9],expectedStdout:`-9
`},{caseKey:`zero`,input:[0],expectedStdout:`0
`},{caseKey:`positive`,input:[7],expectedStdout:`7
`},{caseKey:`boundary`,input:[999],expectedStdout:`999
`}]},{exerciseRef:{id:`exercise.cpp.bug-dangling-pointer`,version:`1.0.0`},programRef:{id:`program.cpp.bug-dangling-pointer`,version:`1.0.0`},lessonRef:{id:`lesson.c.scope-shadowing`,version:`1.0.0`},language:`cpp`,category:`pointer`,title:`离开作用域后还可访问吗`,prompt:`让目标对象的生命期覆盖指针访问，实际解引用后输出输入及换行。`,goal:`indirect-read`,brokenSource:`#include <iostream>
int main() {
  int x;
  std::cin >> x;
  int *p;
  {
    int value = x;
    p = &value;
  }
  std::cout << *p << "\\n";
  return 0;
}
`,solutionSource:`#include <iostream>
int main() {
  int x;
  std::cin >> x;
  int value = x;
  int *p = &value;
  std::cout << *p << "\\n";
  return 0;
}
`,alternativeSource:`#include <iostream>
int main() {
  int x;
  std::cin >> x;
  int *p = &x;
  std::cout << *p << "\\n";
  return 0;
}
`,hints:[`在内存视图前进到右花括号，观察value是否仍存活。`,`指针保存引用不会延长局部变量的生命期。`,`把value放到覆盖访问的作用域，或直接引用仍存活的x。`],explanation:`value离开内部块后成为死亡对象；p仍指向旧对象ID，不能被后来的对象替代。将value的声明移动到main作用域，或引用x，可保证访问时对象仍存活。后退可以恢复对象及旧值，但不会修复当前源码。`,tests:[{caseKey:`negative`,input:[-9],expectedStdout:`-9
`},{caseKey:`zero`,input:[0],expectedStdout:`0
`},{caseKey:`positive`,input:[7],expectedStdout:`7
`},{caseKey:`boundary`,input:[999],expectedStdout:`999
`}]},{exerciseRef:{id:`exercise.cpp.bug-missing-update`,version:`1.0.0`},programRef:{id:`program.cpp.bug-missing-update`,version:`1.0.0`},lessonRef:{id:`lesson.c.while-countdown`,version:`1.0.0`},language:`cpp`,category:`loop`,title:`计数器停在原地`,prompt:`通过真实循环累计0到n-1并输出总和及换行，n=0时不迭代。`,goal:`loop-iterations`,brokenSource:`#include <iostream>
int main() {
  int n;
  std::cin >> n;
  int i = 0;
  int sum = 0;
  while (i < n) {
    sum = sum + i;
  }
  std::cout << sum << "\\n";
  return 0;
}
`,solutionSource:`#include <iostream>
int main() {
  int n;
  std::cin >> n;
  int i = 0;
  int sum = 0;
  while (i < n) {
    sum = sum + i;
    i = i + 1;
  }
  std::cout << sum << "\\n";
  return 0;
}
`,alternativeSource:`#include <iostream>
int main() {
  int n;
  std::cin >> n;
  int sum = 0;
  for (int i = 0; i < n; i = i + 1) {
    sum = sum + i;
  }
  std::cout << sum << "\\n";
  return 0;
}
`,hints:[`先运行n=3，观察连续几轮中i是否变化。`,`sum改变不代表控制循环的i改变；检查继续条件。`,`每轮应让i增加1，使它最终达到n。`],explanation:`原稿的i一直为0，n>0时条件一直成立。Rust按原20,000步上限终止并保留真实前缀；这是预算终止，不是程序正常完成。加入i=i+1，或用for更新部分，可使循环实际累计并结束。n=0本来就是合法零轮组。`,tests:[{caseKey:`three`,input:[3],expectedStdout:`3
`},{caseKey:`empty`,input:[0],expectedStdout:`0
`},{caseKey:`single`,input:[1],expectedStdout:`0
`},{caseKey:`seven`,input:[7],expectedStdout:`21
`}]},{exerciseRef:{id:`exercise.cpp.bug-wrong-direction`,version:`1.0.0`},programRef:{id:`program.cpp.bug-wrong-direction`,version:`1.0.0`},lessonRef:{id:`lesson.c.while-countdown`,version:`1.0.0`},language:`cpp`,category:`loop`,title:`计数器走反了`,prompt:`通过真实循环累计1到n并输出总和及换行，n=0输出0。`,goal:`loop-iterations`,brokenSource:`#include <iostream>
int main() {
  int n;
  std::cin >> n;
  int i = n;
  int sum = 0;
  while (i > 0) {
    sum = sum + i;
    i = i + 1;
  }
  std::cout << sum << "\\n";
  return 0;
}
`,solutionSource:`#include <iostream>
int main() {
  int n;
  std::cin >> n;
  int i = n;
  int sum = 0;
  while (i > 0) {
    sum = sum + i;
    i = i - 1;
  }
  std::cout << sum << "\\n";
  return 0;
}
`,alternativeSource:`#include <iostream>
int main() {
  int n;
  std::cin >> n;
  int sum = 0;
  for (int i = 1; i <= n; i = i + 1) {
    sum = sum + i;
  }
  std::cout << sum << "\\n";
  return 0;
}
`,hints:[`前进几轮，对照i>0和i的变化方向。`,`i虽然变化，却越来越远离让条件为假的边界。`,`倒数循环每轮应减1；也可改为合法正向for累计。`],explanation:`从n向0倒数需要i=i-1。原稿增加i，在既定输入下先耗尽真实步骤预算；前缀可查看实际增长与累加。修复可以倒数或正向for，只要实际循环、读取输入、正常结束且每组输出正确，不比较参考源码文本。`,tests:[{caseKey:`three`,input:[3],expectedStdout:`6
`},{caseKey:`empty`,input:[0],expectedStdout:`0
`},{caseKey:`single`,input:[1],expectedStdout:`1
`},{caseKey:`seven`,input:[7],expectedStdout:`28
`}]}]};let E=(e,t)=>e.id===t.id&&e.version===t.version;function D(e){return e&&typeof e==`object`&&(Object.values(e).forEach(D),Object.freeze(e)),e}if(D(T),T.registryVersion!==`1.0.0`||T.questions.length!==4||T.questions.filter(e=>e.category===`pointer`).length!==2||T.questions.filter(e=>e.category===`loop`).length!==2||new Set(T.questions.map(e=>e.exerciseRef.id)).size!==4||T.questions.some(e=>e.language!==`cpp`||e.hints.length!==3||e.tests.length!==4||new Set(e.tests.map(e=>e.caseKey)).size!==4||e.tests.some(e=>e.input.length!==1||!e.input.every(e=>Number.isInteger(e)&&e>=-999&&e<=999))||(e.category===`pointer`?e.goal!==`indirect-read`:e.goal!==`loop-iterations`||e.tests.some(e=>e.input[0]<0))))throw Error(`MEMORY_BUG_REGISTRY`);let O=T,k=T.questions;function A(){return k.map(e=>({ref:e.exerciseRef,learningRevision:1,acceptedPriorVersions:[],lessonRef:e.lessonRef,caseKeys:e.tests.map(e=>e.caseKey)}))}function j(e){let t=new Set(k.map(e=>e.exerciseRef.id));return e.length===40&&w(e.filter(e=>!t.has(e.ref.id)))&&A().every(t=>{let n=e.find(e=>E(e.ref,t.ref));return n&&n.learningRevision===1&&n.acceptedPriorVersions.length===0&&E(n.lessonRef,t.lessonRef)&&n.caseKeys.length===4&&n.caseKeys.every((e,n)=>e===t.caseKeys[n])})}let M,N=null;function P(e){return e&&typeof e==`object`&&(Object.values(e).forEach(P),Object.freeze(e)),e}async function F(e){if(e.byteLength!==_.bytes)throw Error(`COURSE_BUNDLE_INTEGRITY`);let t=await crypto.subtle.digest(`SHA-256`,new Uint8Array(e).buffer);if(Array.from(new Uint8Array(t),e=>e.toString(16).padStart(2,`0`)).join(``)!==_.sha256)throw Error(`COURSE_BUNDLE_INTEGRITY`);let n=JSON.parse(new TextDecoder(`utf-8`,{fatal:!0}).decode(e)),r={id:`content.c.p05`,version:`1.0.0`},i=e=>e?.id===r.id&&e.version===r.version;if(![`1.0.0`,`1.1.0`,`1.2.0`].includes(n.bundleVersion)||n.registered!==_.registered||!i(n.reading?.packageRef)||!i(n.practice?.packageRef)||n.reading.lessons.length!==32||n.reading.chapters.length!==8||([`1.1.0`,`1.2.0`].includes(n.bundleVersion)?!n.bugSupplement||n.bugSupplement.registryRef.id!==S.id||n.bugSupplement.registryRef.version!==S.version||!/^[a-f0-9]{64}$/.test(n.bugSupplement.sourceSha256)||n.bugSupplement.sourceSha256!==_.bugSupplement.sourceSha256||!w(n.practice.exercises.map(e=>({ref:{id:e.id,version:e.version},learningRevision:e.learningRevision,acceptedPriorVersions:e.acceptedPriorVersions,lessonRef:e.lessonRef,caseKeys:e.tests.map(e=>e.caseKey)}))):n.practice.exercises.length!==32||n.bugSupplement)||n.cases.length!==7||!n.cases.every(e=>i(e.packageRef))||n.guidance.length!==32||n.reading.sourceSha256!==n.sourceSha256||n.practice.sourceSha256!==n.sourceSha256||(n.registered?!n.learning||!i(n.learning.packageRef):n.learning!==null))throw Error(`COURSE_BUNDLE_CONTENT`);if(n.bundleVersion===`1.2.0`){let e=n.memoryBugSupplement;if(!e||e.registryRef.id!==O.registryRef.id||e.registryRef.version!==O.registryRef.version||e.sourceSha256!==_.memoryBugSupplement.sourceSha256||JSON.stringify(e.questions)!==JSON.stringify(O.questions)||n.registered&&(!n.learning||!j(n.learning.exercises)))throw Error(`COURSE_BUNDLE_CONTENT`)}else if(n.memoryBugSupplement)throw Error(`COURSE_BUNDLE_CONTENT`);return P(n)}async function I(e=fetch,t=!1){return _.enabled?(t&&N&&(M=void 0),M||=(async()=>{let n=new AbortController,r,i=new Promise((e,t)=>n.signal.addEventListener(`abort`,()=>t(/* @__PURE__ */ Error(`COURSE_BUNDLE_TIMEOUT`)),{once:!0})),a=setTimeout(()=>n.abort(),1e4);try{let a=new URL(`/${_.file}`,location.href);if(a.origin!==location.origin||!a.pathname.includes(`/content/`))throw Error(`COURSE_BUNDLE_RESOURCE`);let o=async t=>{let o=await Promise.race([e(a,{signal:n.signal,credentials:`omit`,cache:t,redirect:`error`,referrerPolicy:`no-referrer`,headers:{Accept:`application/json`}}),i]);if(!o.ok||o.redirected||!o.body)throw Error(`COURSE_BUNDLE_UNAVAILABLE`);let s=o.headers.get(`content-length`);if(s&&(!/^\d+$/.test(s)||Number(s)>2097152))throw Error(`COURSE_BUNDLE_SIZE`);r=o.body.getReader();let c=[],l=0;for(;;){let e=await Promise.race([r.read(),i]);if(e.done)break;if(l+=e.value.length,l>2097152)throw Error(`COURSE_BUNDLE_SIZE`);c.push(e.value)}let u=new Uint8Array(l),d=0;for(let e of c)u.set(e,d),d+=e.length;return await F(u)},s;try{s=await o(t?`reload`:`force-cache`)}catch(e){if(t||!(e instanceof Error)||e.message!==`COURSE_BUNDLE_INTEGRITY`||n.signal.aborted)throw e;s=await o(`reload`)}return N=null,v(s.reading),s}catch(e){return N=e instanceof Error?e.message:`COURSE_BUNDLE_UNAVAILABLE`,v(null),null}finally{clearTimeout(a),n.abort(),r?.cancel().catch(()=>void 0)}})(),M):null}function L(e){return e&&typeof e==`object`&&(Object.values(e).forEach(L),Object.freeze(e)),e}async function R(e){if(e.byteLength!==g.bytes)throw Error(`PRACTICE_INTEGRITY`);let t=await crypto.subtle.digest(`SHA-256`,new Uint8Array(e).buffer);if(Array.from(new Uint8Array(t),e=>e.toString(16).padStart(2,`0`)).join(``)!==g.sha256)throw Error(`PRACTICE_INTEGRITY`);return L(JSON.parse(new TextDecoder(`utf-8`,{fatal:!0}).decode(e)))}async function z(e){let t=await I();if(e?.aborted)throw Error(`PRACTICE_ABORTED`);if(t)return t.practice;let n=new AbortController,r=()=>n.abort();e?.addEventListener(`abort`,r,{once:!0}),e?.aborted&&n.abort();let i=new Promise((e,t)=>{n.signal.addEventListener(`abort`,()=>t(/* @__PURE__ */ Error(`PRACTICE_ABORTED`)),{once:!0}),n.signal.aborted&&t(/* @__PURE__ */ Error(`PRACTICE_ABORTED`))}),a=setTimeout(r,1e4),o;try{let e=new URL(`/${g.file}`,location.href);if(e.origin!==location.origin)throw Error(`PRACTICE_RESOURCE`);let t=await Promise.race([fetch(e,{signal:n.signal,credentials:`omit`,cache:`no-store`,redirect:`error`,referrerPolicy:`no-referrer`,headers:{Accept:`application/json`}}),i]);if(!t.ok||t.redirected||!t.body)throw Error(`PRACTICE_UNAVAILABLE`);let r=t.headers.get(`content-length`);if(r&&(!/^\d+$/.test(r)||Number(r)>2097152))throw Error(`PRACTICE_SIZE`);o=t.body.getReader();let a=[],s=0;for(;;){let e=await Promise.race([o.read(),i]);if(e.done)break;if(s+=e.value.byteLength,s>2097152)throw Error(`PRACTICE_SIZE`);a.push(e.value)}let c=new Uint8Array(s),l=0;for(let e of a)c.set(e,l),l+=e.length;return await R(c)}finally{clearTimeout(a),e?.removeEventListener(`abort`,r),n.abort(),o?.cancel().catch(()=>void 0)}}function B(e,t){let n=e.exercises.find(e=>e.id===t),r=e.programs.find(e=>e.id===n?.programRef.id&&e.version===n.programRef.version),i=e.inputSpecs.find(e=>e.id===r?.inputRef.id&&e.version===r.inputRef.version),a=e.judgeProfiles.find(e=>e.id===n?.judgeRef.id&&e.version===n.judgeRef.version);if(!n||!r||!i||!a)throw Error(`PRACTICE_MISSING`);return{packageRef:e.packageRef,subject:n,program:r,inputSpec:i,judgeProfile:a}}var V=`{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:edit-ast-block-map-01:1.0.0",
  "title": "EDIT-SYNC-01 / AST-MAP-01 / BLOCK-MAP-01 1.0.0 (design baseline)",
  "$comment": "Structure only. exec_ definitions are byte-independent structural copies of frozen EXEC-01 definitions with local references, checked for equality. Normative graph, byte ranges, reserved names, int32 values, source/AST/mapping equivalence, binding protection, session snapshot ownership and current revision gates require the accompanying 13.1 contract. No runtime support is implied.",
  "oneOf": [
    {
      "$ref": "#/$defs/analysisRequest"
    },
    {
      "$ref": "#/$defs/analysisResult"
    },
    {
      "$ref": "#/$defs/analysisFailure"
    },
    {
      "$ref": "#/$defs/editDocument"
    }
  ],
  "$defs": {
    "id": {
      "$ref": "#/$defs/exec_opaqueId"
    },
    "nodeId": {
      "$ref": "#/$defs/exec_nodeId"
    },
    "range": {
      "$ref": "#/$defs/exec_byteRange"
    },
    "entityRef": {
      "$ref": "#/$defs/exec_ref"
    },
    "revision": {
      "$ref": "#/$defs/exec_positiveInt"
    },
    "sourceText": {
      "type": "string",
      "maxLength": 32768
    },
    "decimal": {
      "type": "string",
      "maxLength": 10,
      "pattern": "^(0|[1-9][0-9]*)$"
    },
    "positiveDecimal": {
      "type": "string",
      "maxLength": 10,
      "pattern": "^[1-9][0-9]*$"
    },
    "signedDecimal": {
      "type": "string",
      "maxLength": 11,
      "pattern": "^(0|-?[1-9][0-9]*)$"
    },
    "blockName": {
      "type": "string",
      "maxLength": 32768,
      "pattern": "^[A-Za-z][A-Za-z0-9_]*$"
    },
    "astName": {
      "type": "string",
      "maxLength": 32768,
      "pattern": "^[A-Za-z_][A-Za-z0-9_]*$"
    },
    "block_main": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "body"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "main"
        },
        "body": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/statement"
          }
        }
      }
    },
    "block_integer": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "value"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "integer"
        },
        "value": {
          "$ref": "#/$defs/decimal"
        }
      }
    },
    "block_variable": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "name"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "variable"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        }
      }
    },
    "block_unary": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "operator",
        "operand"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "unary"
        },
        "operator": {
          "enum": [
            "+",
            "-",
            "!"
          ]
        },
        "operand": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_arithmetic": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "operator",
        "left",
        "right"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "arithmetic"
        },
        "operator": {
          "enum": [
            "+",
            "-",
            "*",
            "/",
            "%"
          ]
        },
        "left": {
          "$ref": "#/$defs/expression"
        },
        "right": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_compare": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "operator",
        "left",
        "right"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "compare"
        },
        "operator": {
          "enum": [
            "<",
            "<=",
            ">",
            ">=",
            "==",
            "!="
          ]
        },
        "left": {
          "$ref": "#/$defs/expression"
        },
        "right": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_logic": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "operator",
        "left",
        "right"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "logic"
        },
        "operator": {
          "enum": [
            "&&",
            "||"
          ]
        },
        "left": {
          "$ref": "#/$defs/expression"
        },
        "right": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_array_read": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "name",
        "index"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "array_read"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        },
        "index": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_input": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "bindingKey",
        "name",
        "targetKind"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "input"
        },
        "bindingKey": {
          "$ref": "#/$defs/id"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        },
        "targetKind": {
          "enum": [
            "scalar",
            "array",
            "logical-length"
          ]
        }
      }
    },
    "block_declare": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "name",
        "initial"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "declare"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        },
        "initial": {
          "oneOf": [
            {
              "$ref": "#/$defs/expression"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "block_assign": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "name",
        "value"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "assign"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        },
        "value": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_if": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "condition",
        "then",
        "else"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "if"
        },
        "condition": {
          "$ref": "#/$defs/expression"
        },
        "then": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/statement"
          }
        },
        "else": {
          "oneOf": [
            {
              "type": "array",
              "maxItems": 32768,
              "items": {
                "$ref": "#/$defs/statement"
              }
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "block_while": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "condition",
        "body"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "while"
        },
        "condition": {
          "$ref": "#/$defs/expression"
        },
        "body": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/statement"
          }
        }
      }
    },
    "block_for": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "init",
        "condition",
        "update",
        "body"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "for"
        },
        "init": {
          "oneOf": [
            {
              "oneOf": [
                {
                  "$ref": "#/$defs/block_declare"
                },
                {
                  "$ref": "#/$defs/block_assign"
                }
              ]
            },
            {
              "type": "null"
            }
          ]
        },
        "condition": {
          "oneOf": [
            {
              "$ref": "#/$defs/expression"
            },
            {
              "type": "null"
            }
          ]
        },
        "update": {
          "oneOf": [
            {
              "$ref": "#/$defs/block_assign"
            },
            {
              "type": "null"
            }
          ]
        },
        "body": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/statement"
          }
        }
      }
    },
    "block_break": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "break"
        }
      }
    },
    "block_continue": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "continue"
        }
      }
    },
    "block_array_declare": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "name",
        "length",
        "values"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "array_declare"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        },
        "length": {
          "$ref": "#/$defs/positiveDecimal"
        },
        "values": {
          "oneOf": [
            {
              "type": "array",
              "maxItems": 32768,
              "items": {
                "$ref": "#/$defs/signedDecimal"
              },
              "minItems": 1
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "block_array_write": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "name",
        "index",
        "value"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "array_write"
        },
        "name": {
          "$ref": "#/$defs/blockName"
        },
        "index": {
          "$ref": "#/$defs/expression"
        },
        "value": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_print": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "format",
        "args"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "print"
        },
        "format": {
          "type": "string",
          "maxLength": 32768,
          "pattern": "^[^\\\\u0000-\\\\u0009\\\\u000b-\\\\u001f\\\\u007f]*$"
        },
        "args": {
          "type": "array",
          "maxItems": 16384,
          "items": {
            "$ref": "#/$defs/expression"
          }
        }
      }
    },
    "block_return": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "value"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "return"
        },
        "value": {
          "$ref": "#/$defs/expression"
        }
      }
    },
    "block_scope": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "kind",
        "body"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/id"
        },
        "kind": {
          "const": "scope"
        },
        "body": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/statement"
          }
        }
      }
    },
    "expression": {
      "oneOf": [
        {
          "$ref": "#/$defs/block_integer"
        },
        {
          "$ref": "#/$defs/block_variable"
        },
        {
          "$ref": "#/$defs/block_unary"
        },
        {
          "$ref": "#/$defs/block_arithmetic"
        },
        {
          "$ref": "#/$defs/block_compare"
        },
        {
          "$ref": "#/$defs/block_logic"
        },
        {
          "$ref": "#/$defs/block_array_read"
        }
      ]
    },
    "statement": {
      "oneOf": [
        {
          "$ref": "#/$defs/block_input"
        },
        {
          "$ref": "#/$defs/block_declare"
        },
        {
          "$ref": "#/$defs/block_assign"
        },
        {
          "$ref": "#/$defs/block_if"
        },
        {
          "$ref": "#/$defs/block_while"
        },
        {
          "$ref": "#/$defs/block_for"
        },
        {
          "$ref": "#/$defs/block_break"
        },
        {
          "$ref": "#/$defs/block_continue"
        },
        {
          "$ref": "#/$defs/block_array_declare"
        },
        {
          "$ref": "#/$defs/block_array_write"
        },
        {
          "$ref": "#/$defs/block_print"
        },
        {
          "$ref": "#/$defs/block_return"
        },
        {
          "$ref": "#/$defs/block_scope"
        }
      ]
    },
    "blockProgram": {
      "$ref": "#/$defs/block_main"
    },
    "initializer": {
      "oneOf": [
        {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "kind"
          ],
          "properties": {
            "kind": {
              "const": "none"
            }
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "kind",
            "expression"
          ],
          "properties": {
            "kind": {
              "const": "scalar"
            },
            "expression": {
              "$ref": "#/$defs/nodeId"
            }
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "kind",
            "elements"
          ],
          "properties": {
            "kind": {
              "const": "array"
            },
            "elements": {
              "type": "array",
              "maxItems": 32768,
              "items": {
                "$ref": "#/$defs/nodeId"
              },
              "minItems": 1
            }
          }
        }
      ]
    },
    "ast_function": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "body"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "function"
        },
        "body": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_block": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "statements"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "block"
        },
        "statements": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/nodeId"
          }
        }
      }
    },
    "ast_declaration": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "name",
        "nameRange",
        "arrayLength",
        "initializer"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "declaration"
        },
        "name": {
          "$ref": "#/$defs/astName"
        },
        "nameRange": {
          "$ref": "#/$defs/range"
        },
        "arrayLength": {
          "oneOf": [
            {
              "$ref": "#/$defs/positiveDecimal"
            },
            {
              "type": "null"
            }
          ]
        },
        "initializer": {
          "$ref": "#/$defs/initializer"
        }
      }
    },
    "ast_assignment": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "target",
        "value"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "assignment"
        },
        "target": {
          "$ref": "#/$defs/nodeId"
        },
        "value": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_if": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "condition",
        "thenBlock",
        "elseBlock"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "if"
        },
        "condition": {
          "$ref": "#/$defs/nodeId"
        },
        "thenBlock": {
          "$ref": "#/$defs/nodeId"
        },
        "elseBlock": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "ast_while": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "condition",
        "body"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "while"
        },
        "condition": {
          "$ref": "#/$defs/nodeId"
        },
        "body": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_for": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "init",
        "condition",
        "update",
        "body"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "for"
        },
        "init": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "condition": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "update": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "body": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_condition": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "expression"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "condition"
        },
        "expression": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_output": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "format",
        "formatRange",
        "arguments"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "output"
        },
        "format": {
          "type": "string",
          "maxLength": 32768
        },
        "formatRange": {
          "$ref": "#/$defs/range"
        },
        "arguments": {
          "type": "array",
          "maxItems": 16384,
          "items": {
            "$ref": "#/$defs/nodeId"
          }
        }
      }
    },
    "ast_return": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "value"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "return"
        },
        "value": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_break": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "break"
        }
      }
    },
    "ast_continue": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "continue"
        }
      }
    },
    "ast_empty": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "empty"
        }
      }
    },
    "ast_integer": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "value"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "integer"
        },
        "value": {
          "$ref": "#/$defs/decimal"
        }
      }
    },
    "ast_name": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "name",
        "resolvedDeclarationId"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "name"
        },
        "name": {
          "$ref": "#/$defs/astName"
        },
        "resolvedDeclarationId": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_index": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "array",
        "index"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "index"
        },
        "array": {
          "$ref": "#/$defs/nodeId"
        },
        "index": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_unary": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "operator",
        "operand"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "unary"
        },
        "operator": {
          "enum": [
            "+",
            "-",
            "!"
          ]
        },
        "operand": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "ast_binary": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "parentId",
        "byteRange",
        "kind",
        "operator",
        "left",
        "right"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/nodeId"
        },
        "parentId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/range"
        },
        "kind": {
          "const": "binary"
        },
        "operator": {
          "enum": [
            "+",
            "-",
            "*",
            "/",
            "%",
            "<",
            "<=",
            ">",
            ">=",
            "==",
            "!=",
            "&&",
            "||"
          ]
        },
        "left": {
          "$ref": "#/$defs/nodeId"
        },
        "right": {
          "$ref": "#/$defs/nodeId"
        }
      }
    },
    "astNode": {
      "oneOf": [
        {
          "$ref": "#/$defs/ast_function"
        },
        {
          "$ref": "#/$defs/ast_block"
        },
        {
          "$ref": "#/$defs/ast_declaration"
        },
        {
          "$ref": "#/$defs/ast_assignment"
        },
        {
          "$ref": "#/$defs/ast_if"
        },
        {
          "$ref": "#/$defs/ast_while"
        },
        {
          "$ref": "#/$defs/ast_for"
        },
        {
          "$ref": "#/$defs/ast_condition"
        },
        {
          "$ref": "#/$defs/ast_output"
        },
        {
          "$ref": "#/$defs/ast_return"
        },
        {
          "$ref": "#/$defs/ast_break"
        },
        {
          "$ref": "#/$defs/ast_continue"
        },
        {
          "$ref": "#/$defs/ast_empty"
        },
        {
          "$ref": "#/$defs/ast_integer"
        },
        {
          "$ref": "#/$defs/ast_name"
        },
        {
          "$ref": "#/$defs/ast_index"
        },
        {
          "$ref": "#/$defs/ast_unary"
        },
        {
          "$ref": "#/$defs/ast_binary"
        }
      ]
    },
    "checkedAst": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "rootId",
        "headerRange",
        "nodes"
      ],
      "properties": {
        "rootId": {
          "$ref": "#/$defs/nodeId"
        },
        "headerRange": {
          "oneOf": [
            {
              "$ref": "#/$defs/range"
            },
            {
              "type": "null"
            }
          ]
        },
        "nodes": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/astNode"
          },
          "minItems": 2
        }
      }
    },
    "identity": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "contextId",
        "contextRevision",
        "documentRevision",
        "editId",
        "operationId"
      ],
      "properties": {
        "contextId": {
          "$ref": "#/$defs/id"
        },
        "contextRevision": {
          "$ref": "#/$defs/revision"
        },
        "documentRevision": {
          "$ref": "#/$defs/revision"
        },
        "editId": {
          "$ref": "#/$defs/id"
        },
        "operationId": {
          "$ref": "#/$defs/id"
        }
      }
    },
    "refs": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "packageRef",
        "programRef",
        "subsetRef"
      ],
      "properties": {
        "packageRef": {
          "$ref": "#/$defs/entityRef"
        },
        "programRef": {
          "$ref": "#/$defs/entityRef"
        },
        "subsetRef": {
          "$ref": "#/$defs/entityRef"
        }
      }
    },
    "inputBinding": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "bindingKey",
        "inputKey",
        "targetName",
        "targetKind",
        "from",
        "emptyStorage"
      ],
      "properties": {
        "bindingKey": {
          "$ref": "#/$defs/id"
        },
        "inputKey": {
          "type": "string",
          "pattern": "^[A-Za-z_][A-Za-z0-9_]*$",
          "maxLength": 96
        },
        "targetName": {
          "$ref": "#/$defs/astName"
        },
        "targetKind": {
          "enum": [
            "scalar",
            "array",
            "logical-length"
          ]
        },
        "from": {
          "enum": [
            "field",
            "length-of"
          ]
        },
        "emptyStorage": {
          "oneOf": [
            {
              "const": "one-zero-placeholder"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "trivia": {
      "type": "array",
      "maxItems": 32768,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "kind",
          "byteRange"
        ],
        "properties": {
          "kind": {
            "enum": [
              "line-comment",
              "block-comment",
              "whitespace"
            ]
          },
          "byteRange": {
            "$ref": "#/$defs/range"
          }
        }
      }
    },
    "provenance": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "documentRevision",
        "generationMode",
        "trivia",
        "syntheticSegments"
      ],
      "properties": {
        "documentRevision": {
          "$ref": "#/$defs/revision"
        },
        "generationMode": {
          "enum": [
            "preserve",
            "canonical"
          ]
        },
        "trivia": {
          "$ref": "#/$defs/trivia"
        },
        "syntheticSegments": {
          "type": "array",
          "maxItems": 1,
          "items": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind",
              "nodeId",
              "byteRange"
            ],
            "properties": {
              "kind": {
                "const": "synthetic-tail-return"
              },
              "nodeId": {
                "$ref": "#/$defs/nodeId"
              },
              "byteRange": {
                "$ref": "#/$defs/range"
              }
            }
          }
        }
      }
    },
    "projection": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "documentRevision",
        "sourceText",
        "program",
        "blockMap",
        "bindingMap",
        "provenance"
      ],
      "properties": {
        "documentRevision": {
          "$ref": "#/$defs/revision"
        },
        "sourceText": {
          "$ref": "#/$defs/sourceText"
        },
        "program": {
          "$ref": "#/$defs/blockProgram"
        },
        "blockMap": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/exec_blockMapping"
          }
        },
        "bindingMap": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/exec_bindingMapping"
          }
        },
        "provenance": {
          "$ref": "#/$defs/provenance"
        }
      }
    },
    "issue": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "reason",
        "nodeId",
        "blockId",
        "byteRange"
      ],
      "properties": {
        "reason": {
          "enum": [
            "EMPTY_STATEMENT",
            "FOR_ARRAY_TARGET",
            "BLOCK_NAME",
            "BLOCK_FORMAT",
            "BLOCK_STRUCTURE",
            "INPUT_BINDING",
            "UNSUPPORTED_RANGE"
          ]
        },
        "nodeId": {
          "oneOf": [
            {
              "$ref": "#/$defs/nodeId"
            },
            {
              "type": "null"
            }
          ]
        },
        "blockId": {
          "oneOf": [
            {
              "$ref": "#/$defs/id"
            },
            {
              "type": "null"
            }
          ]
        },
        "byteRange": {
          "oneOf": [
            {
              "$ref": "#/$defs/range"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "analysisError": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "code"
      ],
      "properties": {
        "code": {
          "enum": [
            "module",
            "transport",
            "cancelled",
            "budget",
            "response",
            "version"
          ]
        }
      }
    },
    "analysisRequest": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind",
        "analysisVersion",
        "identity",
        "refs",
        "sourceText",
        "input"
      ],
      "properties": {
        "kind": {
          "const": "analysisRequest"
        },
        "analysisVersion": {
          "const": "1.0.0"
        },
        "identity": {
          "$ref": "#/$defs/identity"
        },
        "refs": {
          "$ref": "#/$defs/refs"
        },
        "sourceText": {
          "$ref": "#/$defs/sourceText"
        },
        "input": {
          "$ref": "#/$defs/exec_input"
        }
      }
    },
    "validResult": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind",
        "analysisVersion",
        "identity",
        "refs",
        "status",
        "checkedAst",
        "bindingMap",
        "nodeMap",
        "blockMap",
        "trivia",
        "diagnostics"
      ],
      "properties": {
        "kind": {
          "const": "analysisResult"
        },
        "analysisVersion": {
          "const": "1.0.0"
        },
        "identity": {
          "$ref": "#/$defs/identity"
        },
        "refs": {
          "$ref": "#/$defs/refs"
        },
        "status": {
          "const": "valid"
        },
        "checkedAst": {
          "$ref": "#/$defs/checkedAst"
        },
        "bindingMap": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/exec_bindingMapping"
          }
        },
        "nodeMap": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/exec_node"
          }
        },
        "blockMap": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/exec_blockMapping"
          }
        },
        "trivia": {
          "$ref": "#/$defs/trivia"
        },
        "diagnostics": {
          "$ref": "#/$defs/exec_diagnostics",
          "maxItems": 0
        }
      }
    },
    "invalidResult": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind",
        "analysisVersion",
        "identity",
        "refs",
        "status",
        "diagnostics"
      ],
      "properties": {
        "kind": {
          "const": "analysisResult"
        },
        "analysisVersion": {
          "const": "1.0.0"
        },
        "identity": {
          "$ref": "#/$defs/identity"
        },
        "refs": {
          "$ref": "#/$defs/refs"
        },
        "status": {
          "const": "invalid"
        },
        "diagnostics": {
          "$ref": "#/$defs/exec_diagnostics",
          "minItems": 1
        }
      }
    },
    "analysisResult": {
      "oneOf": [
        {
          "$ref": "#/$defs/validResult"
        },
        {
          "$ref": "#/$defs/invalidResult"
        }
      ]
    },
    "analysisFailure": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind",
        "analysisVersion",
        "identity",
        "refs",
        "error"
      ],
      "properties": {
        "kind": {
          "const": "analysisFailure"
        },
        "analysisVersion": {
          "const": "1.0.0"
        },
        "identity": {
          "$ref": "#/$defs/identity"
        },
        "refs": {
          "$ref": "#/$defs/refs"
        },
        "error": {
          "$ref": "#/$defs/analysisError"
        }
      }
    },
    "authoritativeDraft": {
      "oneOf": [
        {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "kind",
            "text"
          ],
          "properties": {
            "kind": {
              "const": "code"
            },
            "text": {
              "$ref": "#/$defs/sourceText"
            }
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "kind",
            "workspaceSnapshotId"
          ],
          "properties": {
            "kind": {
              "const": "blocks"
            },
            "workspaceSnapshotId": {
              "$ref": "#/$defs/id"
            }
          }
        }
      ]
    },
    "blockDraft": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "workspaceSnapshotId",
        "blocklyVersion",
        "program"
      ],
      "properties": {
        "workspaceSnapshotId": {
          "$ref": "#/$defs/id"
        },
        "blocklyVersion": {
          "const": "13.4.0"
        },
        "program": {
          "oneOf": [
            {
              "$ref": "#/$defs/blockProgram"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "editDocument": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind",
        "editVersion",
        "identity",
        "refs",
        "origin",
        "authoritativeDraft",
        "codeDraft",
        "blockDraft",
        "input",
        "inputBindings",
        "syncStatus",
        "analysisPending",
        "analysisError",
        "validatedDocumentRevision",
        "diagnostics",
        "issues",
        "lastSynced"
      ],
      "properties": {
        "kind": {
          "const": "editDocument"
        },
        "editVersion": {
          "const": "1.0.0"
        },
        "identity": {
          "$ref": "#/$defs/identity"
        },
        "refs": {
          "$ref": "#/$defs/refs"
        },
        "origin": {
          "enum": [
            "code",
            "blocks",
            "input"
          ]
        },
        "authoritativeDraft": {
          "$ref": "#/$defs/authoritativeDraft"
        },
        "codeDraft": {
          "$ref": "#/$defs/sourceText"
        },
        "blockDraft": {
          "$ref": "#/$defs/blockDraft"
        },
        "input": {
          "$ref": "#/$defs/exec_input"
        },
        "inputBindings": {
          "type": "array",
          "maxItems": 32768,
          "items": {
            "$ref": "#/$defs/inputBinding"
          }
        },
        "syncStatus": {
          "enum": [
            "synced",
            "invalid",
            "unmapped"
          ]
        },
        "analysisPending": {
          "type": "boolean"
        },
        "analysisError": {
          "oneOf": [
            {
              "$ref": "#/$defs/analysisError"
            },
            {
              "type": "null"
            }
          ]
        },
        "validatedDocumentRevision": {
          "oneOf": [
            {
              "$ref": "#/$defs/revision"
            },
            {
              "type": "null"
            }
          ]
        },
        "diagnostics": {
          "$ref": "#/$defs/exec_diagnostics"
        },
        "issues": {
          "type": "array",
          "maxItems": 16,
          "items": {
            "$ref": "#/$defs/issue"
          }
        },
        "lastSynced": {
          "oneOf": [
            {
              "$ref": "#/$defs/projection"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "exec_opaqueId": {
      "type": "string",
      "minLength": 1,
      "maxLength": 96,
      "pattern": "^[A-Za-z0-9][A-Za-z0-9._:-]*$"
    },
    "exec_nodeId": {
      "type": "string",
      "pattern": "^n[1-9][0-9]*$",
      "maxLength": 96
    },
    "exec_byteRange": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "start",
        "end"
      ],
      "properties": {
        "start": {
          "type": "integer",
          "minimum": 0,
          "maximum": 32768
        },
        "end": {
          "type": "integer",
          "minimum": 0,
          "maximum": 32768
        }
      }
    },
    "exec_entityId": {
      "type": "string",
      "minLength": 1,
      "maxLength": 96,
      "pattern": "^[a-z][a-z0-9]*(\\\\.[a-z0-9]+(?:-[a-z0-9]+)*)+$"
    },
    "exec_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version"
      ],
      "properties": {
        "id": {
          "$ref": "#/$defs/exec_entityId"
        },
        "version": {
          "type": "string",
          "pattern": "^(0|[1-9][0-9]*)\\\\.(0|[1-9][0-9]*)\\\\.(0|[1-9][0-9]*)$"
        }
      }
    },
    "exec_positiveInt": {
      "type": "integer",
      "minimum": 1,
      "maximum": 9007199254740991
    },
    "exec_blockMapping": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "blockId",
        "byteRange"
      ],
      "properties": {
        "blockId": {
          "$ref": "#/$defs/exec_opaqueId"
        },
        "byteRange": {
          "$ref": "#/$defs/exec_byteRange"
        }
      }
    },
    "exec_bindingMapping": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "bindingKey",
        "byteRange"
      ],
      "properties": {
        "bindingKey": {
          "$ref": "#/$defs/exec_opaqueId"
        },
        "byteRange": {
          "$ref": "#/$defs/exec_byteRange"
        }
      }
    },
    "exec_nullableRef": {
      "oneOf": [
        {
          "$ref": "#/$defs/exec_ref"
        },
        {
          "type": "null"
        }
      ]
    },
    "exec_int32": {
      "type": "integer",
      "minimum": -2147483648,
      "maximum": 2147483647
    },
    "exec_inputValues": {
      "type": "object",
      "propertyNames": {
        "type": "string",
        "pattern": "^[A-Za-z_][A-Za-z0-9_]*$",
        "maxLength": 96
      },
      "additionalProperties": {
        "oneOf": [
          {
            "$ref": "#/$defs/exec_int32"
          },
          {
            "type": "array",
            "maxItems": 30,
            "items": {
              "$ref": "#/$defs/exec_int32"
            }
          }
        ]
      }
    },
    "exec_random": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "generatorRef",
        "seed"
      ],
      "properties": {
        "generatorRef": {
          "$ref": "#/$defs/exec_ref"
        },
        "seed": {
          "type": "string",
          "minLength": 1,
          "maxLength": 128
        }
      }
    },
    "exec_input": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "specRef",
        "values",
        "random"
      ],
      "properties": {
        "specRef": {
          "$ref": "#/$defs/exec_nullableRef"
        },
        "values": {
          "$ref": "#/$defs/exec_inputValues"
        },
        "random": {
          "oneOf": [
            {
              "$ref": "#/$defs/exec_random"
            },
            {
              "type": "null"
            }
          ]
        }
      }
    },
    "exec_nullableNodeId": {
      "oneOf": [
        {
          "$ref": "#/$defs/exec_nodeId"
        },
        {
          "type": "null"
        }
      ]
    },
    "exec_node": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "nodeId",
        "kind",
        "parentId",
        "byteRange"
      ],
      "properties": {
        "nodeId": {
          "$ref": "#/$defs/exec_nodeId"
        },
        "kind": {
          "enum": [
            "function",
            "block",
            "declaration",
            "assignment",
            "expression",
            "condition",
            "output",
            "return",
            "break",
            "continue",
            "empty",
            "if",
            "while",
            "for"
          ]
        },
        "parentId": {
          "$ref": "#/$defs/exec_nullableNodeId"
        },
        "byteRange": {
          "$ref": "#/$defs/exec_byteRange"
        }
      }
    },
    "exec_diagnosticCode": {
      "enum": [
        "E_LEX_INVALID",
        "E_PARSE_INVALID",
        "E_UNSUPPORTED_SYNTAX",
        "E_NAME_INVALID",
        "E_TYPE_INVALID",
        "E_FORMAT_INVALID",
        "E_UNINITIALIZED",
        "E_INDEX_BOUNDS",
        "E_DIV_ZERO",
        "E_INT_OVERFLOW",
        "E_INPUT_INVALID",
        "E_INPUT_ORDER",
        "E_BINDING_INVALID",
        "E_CONTENT_MISMATCH",
        "E_PROTOCOL_VERSION",
        "E_PROTOCOL_INVALID",
        "E_TRACE_INVALID",
        "E_SOURCE_LIMIT",
        "E_REQUEST_LIMIT",
        "E_DEPTH_LIMIT",
        "E_FUEL_LIMIT",
        "E_STEP_LIMIT",
        "E_MEMORY_LIMIT",
        "E_OUTPUT_LIMIT",
        "E_RESULT_LIMIT",
        "E_DEADLINE",
        "E_CANCELLED",
        "E_MODULE_LOAD",
        "E_WORKER_FAILURE",
        "E_WASM_TRAP",
        "E_ENCODING_FAILURE",
        "J_STDOUT_MISMATCH",
        "J_EXIT_NONZERO",
        "J_TEACHING_TARGET",
        "J_BINDING_MISMATCH"
      ]
    },
    "exec_sourceLocation": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind"
      ],
      "properties": {
        "kind": {
          "const": "source"
        },
        "nodeId": {
          "$ref": "#/$defs/exec_nodeId"
        },
        "edge": {
          "enum": [
            "start",
            "whole",
            "end"
          ]
        },
        "byteRange": {
          "$ref": "#/$defs/exec_byteRange"
        }
      },
      "anyOf": [
        {
          "required": [
            "nodeId",
            "edge"
          ]
        },
        {
          "required": [
            "byteRange"
          ]
        }
      ],
      "dependentRequired": {
        "nodeId": [
          "edge"
        ],
        "edge": [
          "nodeId"
        ]
      }
    },
    "exec_syntheticLocation": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "kind",
        "reason"
      ],
      "properties": {
        "kind": {
          "const": "synthetic"
        },
        "reason": {
          "enum": [
            "initial-state",
            "implicit-return",
            "pre-execution",
            "adapter-cancel",
            "adapter-deadline",
            "module-load",
            "worker-failure",
            "protocol-validation",
            "encoding-failure"
          ]
        },
        "anchorNodeId": {
          "$ref": "#/$defs/exec_nodeId"
        }
      }
    },
    "exec_location": {
      "oneOf": [
        {
          "$ref": "#/$defs/exec_sourceLocation"
        },
        {
          "$ref": "#/$defs/exec_syntheticLocation"
        }
      ]
    },
    "exec_diagnosticValue": {
      "oneOf": [
        {
          "type": "integer",
          "minimum": -9007199254740991,
          "maximum": 9007199254740991
        },
        {
          "type": "string",
          "maxLength": 96
        }
      ]
    },
    "exec_uint": {
      "type": "integer",
      "minimum": 0,
      "maximum": 9007199254740991
    },
    "exec_diagnosticDetails": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "expected": {
          "$ref": "#/$defs/exec_diagnosticValue"
        },
        "actual": {
          "$ref": "#/$defs/exec_diagnosticValue"
        },
        "limit": {
          "$ref": "#/$defs/exec_uint"
        },
        "used": {
          "$ref": "#/$defs/exec_uint"
        },
        "attempted": {
          "$ref": "#/$defs/exec_uint"
        },
        "dimension": {
          "enum": [
            "sourceBytes",
            "requestBytes",
            "inputDomain",
            "inputLength",
            "syntaxDepth",
            "astDepth",
            "fuel",
            "steps",
            "liveBytes",
            "outputBytes",
            "resultBytes",
            "deadline",
            "jsonDepth"
          ]
        },
        "relatedNodeIds": {
          "type": "array",
          "maxItems": 32,
          "uniqueItems": true,
          "items": {
            "$ref": "#/$defs/exec_nodeId"
          }
        }
      }
    },
    "exec_diagnostic": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "code",
        "severity",
        "origin",
        "stage",
        "location",
        "details"
      ],
      "properties": {
        "code": {
          "$ref": "#/$defs/exec_diagnosticCode"
        },
        "severity": {
          "const": "error"
        },
        "origin": {
          "enum": [
            "rust",
            "adapter",
            "protocol",
            "judge"
          ]
        },
        "stage": {
          "enum": [
            "preflight",
            "load",
            "lex",
            "parse",
            "semantic",
            "execute",
            "encode",
            "receive",
            "judge"
          ]
        },
        "location": {
          "$ref": "#/$defs/exec_location"
        },
        "details": {
          "$ref": "#/$defs/exec_diagnosticDetails"
        }
      }
    },
    "exec_diagnostics": {
      "type": "array",
      "maxItems": 16,
      "items": {
        "$ref": "#/$defs/exec_diagnostic"
      }
    }
  }
}
`;new TextEncoder,new TextEncoder;let H=JSON.parse(V),U=new TextEncoder,W=new TextDecoder(`utf-8`,{fatal:!0}),G=e=>typeof e==`object`&&!!e&&!Array.isArray(e);var K=class extends Error{code;constructor(e=`E_PROTOCOL_INVALID`){super(e),this.code=e}};function q(e,t=`E_PROTOCOL_INVALID`){if(!e)throw new K(t)}let J=/* @__PURE__ */ new Map;function Y(e){let t=(e,n=/* @__PURE__ */ new Set)=>{if(!e.$ref)return e;if(!e.$ref.startsWith(`#/$defs/`)||n.has(e.$ref))return null;n.add(e.$ref);let r=H.$defs[e.$ref.slice(8)];return r?t(r,n):null},n=e.map(e=>t(e));if(!n.length||n.some(e=>e?.type!==`object`))return null;for(let e of n[0].required??[]){let t=n.map(t=>t?.properties?.[e]?.const);if(n.every(t=>t?.required?.includes(e))&&t.every(e=>typeof e==`string`)&&new Set(t).size===n.length)return{property:e,constants:t}}return null}function te(e){let t=e.length;for(let n=0;n<e.length;n++){let r=e.charCodeAt(n);if(r<55296||r>56319)continue;let i=e.charCodeAt(n+1);i>=56320&&i<=57343&&(t--,n++)}return t}function X(e){let t=J.get(e);if(t)return t;let n=()=>!1,r=(e,t)=>n(e,t);J.set(e,r);let i=e.$ref?H.$defs[e.$ref.slice(8)]:null;q(!e.$ref||e.$ref.startsWith(`#/$defs/`)&&i);let a=i?X(i):null,o=(e.oneOf??e.anyOf)?.map(X),s=e.oneOf?Y(e.oneOf):null,c=s?new Map(s.constants.map((e,t)=>[e,o[t]])):null,l=Object.fromEntries(Object.entries(e.properties??{}).map(([e,t])=>[e,X(t)])),u=typeof e.additionalProperties==`object`?X(e.additionalProperties):null,d=e.items?X(e.items):null,f=e.propertyNames?X(e.propertyNames):null,p=e.pattern?new RegExp(e.pattern,`u`):null;return n=(t,n)=>{if(n(),a&&!a(t,n)||Object.hasOwn(e,`const`)&&t!==e.const||e.enum&&!e.enum.includes(t)||e.type&&!(e.type===`null`?t===null:e.type===`array`?Array.isArray(t):e.type===`object`?G(t):e.type===`integer`?typeof t==`number`&&Number.isSafeInteger(t):typeof t===e.type)||typeof t==`number`&&(e.minimum!==void 0&&t<e.minimum||e.maximum!==void 0&&t>e.maximum))return!1;if(typeof t==`string`){let n=e.minLength!==void 0||e.maxLength!==void 0?te(t):0;if(e.minLength!==void 0&&n<e.minLength||e.maxLength!==void 0&&n>e.maxLength||p&&!p.test(t))return!1}if(Array.isArray(t)&&(e.minItems!==void 0&&t.length<e.minItems||e.maxItems!==void 0&&t.length>e.maxItems||e.uniqueItems&&new Set(t.map(e=>JSON.stringify(e))).size!==t.length||d&&!t.every(e=>d(e,n))))return!1;if(G(t)){if(e.required?.some(e=>!Object.hasOwn(t,e)))return!1;for(let[r,i]of Object.entries(t)){if(f&&!f(r,n))return!1;if(Object.hasOwn(l,r)){if(!l[r](i,n))return!1}else if(e.additionalProperties===!1||u&&!u(i,n))return!1}for(let[n,r]of Object.entries(e.dependentRequired??{}))if(Object.hasOwn(t,n)&&r.some(e=>!Object.hasOwn(t,e)))return!1}if(o){if(s&&c){let e=G(t)?c.get(t[s.property]):void 0;return e?e(t,n):!1}let r=0;for(let e of o)e(t,n)&&r++;if(e.oneOf?r!==1:r===0)return!1}return!0},r}let ne=X(H.$defs.analysisRequest);X(H.$defs.analysisResult),X(H.$defs.analysisFailure);function Z(e){return typeof e!=`object`||!e?(q(typeof e!=`number`||Number.isSafeInteger(e)),typeof e==`string`&&q(W.decode(U.encode(e))===e),JSON.stringify(e)):Array.isArray(e)?`[${e.map(Z).join(`,`)}]`:`{${Object.keys(e).sort().map(t=>`${JSON.stringify(t)}:${Z(e[t])}`).join(`,`)}}`}function re(e,t){q(e.analysisVersion===`1.0.0`,`E_PROTOCOL_VERSION`),q(ne(e,()=>{})),q(U.encode(e.sourceText).byteLength<=32768,`E_SOURCE_LIMIT`),t&&q(e.refs.packageRef.id===t.packageRef.id&&e.refs.packageRef.version===t.packageRef.version&&e.refs.programRef.id===t.program.id&&e.refs.programRef.version===t.program.version&&e.refs.subsetRef.id===t.program.subsetRef.id&&e.refs.subsetRef.version===t.program.subsetRef.version&&e.input.specRef?.id===t.program.inputRef.id&&e.input.specRef.version===t.program.inputRef.version,`E_CONTENT_MISMATCH`);let n=U.encode(Z(e));return q(n.byteLength<=65536,`E_REQUEST_LIMIT`),n}let Q=globalThis,$=!1;Q.onmessage=async({data:t})=>{if($||($=!0,!t||t.kind!==`analyze-code`||typeof t.operationId!=`string`))return;let n=performance.now(),r=new AbortController,i=setTimeout(()=>r.abort(),Math.max(0,Math.min(1e3,t.remainingMs))),a=()=>{if(r.signal.aborted||performance.now()-n>=t.remainingMs)throw Error(`E_DEADLINE`)};try{if(Object.keys(t).sort().join(`,`)!==`buffer,exerciseId,kind,module,operationId,remainingMs`||!(t.module instanceof WebAssembly.Module)||!(t.buffer instanceof ArrayBuffer)||t.buffer.byteLength>65536||typeof t.exerciseId!=`string`||!Number.isSafeInteger(t.remainingMs)||t.remainingMs<1||t.remainingMs>1e3)throw Error(`E_PROTOCOL_INVALID`);let i=await z(r.signal).catch(()=>{throw a(),Error(`E_MODULE_LOAD`)});a();let o=B(i,t.exerciseId),s=re(JSON.parse(new TextDecoder(`utf-8`,{fatal:!0}).decode(t.buffer)),o);if(s.byteLength!==t.buffer.byteLength||s.some((e,n)=>e!==new Uint8Array(t.buffer)[n]))throw Error(`E_PROTOCOL_INVALID`);a(),await ee({module_or_path:t.module}),a();let c=e(new TextDecoder(`utf-8`,{fatal:!0}).decode(s),JSON.stringify(o),Math.max(0,Math.floor(t.remainingMs-(performance.now()-n))));if(a(),!c.byteLength||c.byteLength>16777216)throw Error(`E_RESULT_LIMIT`);let l=c.slice().buffer;Q.postMessage({ok:!0,operationId:t.operationId,buffer:l},[l])}catch(e){let n=r.signal.aborted?`E_DEADLINE`:e instanceof WebAssembly.RuntimeError?`E_WASM_TRAP`:typeof e==`string`&&/^E_[A-Z_]+$/.test(e)?e:e instanceof Error&&/^E_[A-Z_]+$/.test(e.message)?e.message:`E_WORKER_FAILURE`;Q.postMessage({ok:!1,operationId:t.operationId,code:n})}finally{clearTimeout(i),r.abort()}}})();