var e={schemaVersion:`1.0.0`,id:`catalog.cpp.iterative-sorts`,version:`1.0.0`,cases:[{id:`case.cpp.insertion-sort`,version:`1.0.0`,programId:`program.cpp.insertion-sort`,programVersion:`1.0.0`,language:`cpp`,title:`插入排序`,description:`暂存一个数，将左侧较大的元素右移，再放回空位。`,objectives:[`沿真实步骤观察key、j与右移写入`,`分清逻辑输入长度与物理容量`,`后退恢复每一次赋值与当前输出`],min:-999,max:999,maxItems:30,defaultInput:[7,-3,0,5,-3,2,9],variant:`稳定直接插入；只移动严格大于key的项。`,complexity:`最好O(n)，最坏O(n²)；原计数包含循环判断、输入和初始化，不能只当元素比较次数。`,extraSpace:`原数组内移动，额外O(1)标量；values物理容量30个int。`,sourceFile:`content/algorithms/cpp/insertion-sort-1.0.0.cpp`,phases:[{id:`setup`,title:`准备存储`,explanation:`建立逻辑长度n和容量30的数组；零初始化不是已读入数据。`},{id:`input`,title:`读入原数据`,explanation:`cin按请求顺序写入values的前n项；画面直接显示实际状态。`},{id:`insert`,title:`取出待插入值`,explanation:`暂存values[i]为key，令j从它左侧开始检查。`},{id:`shift`,title:`比较并右移`,explanation:`先检查j>=0再读取values[j]；严格大于key才右移，相等项不越过。右移期间允许出现重复值，key仍单独保留。`},{id:`place`,title:`写回插入位置`,explanation:`把key写到j+1；这是实际赋值，包含值不变的写入。`},{id:`output`,title:`输出并结束`,explanation:`逐项输出实际数组。主函数结束后对象离开作用域，后退可以恢复。`}],boundarySamples:[[],[0],[2,2,-1,2],[-999,0,999],[5,4,3,2,1]]},{id:`case.cpp.shell-sort`,version:`1.0.0`,programId:`program.cpp.shell-sort`,programVersion:`1.0.0`,language:`cpp`,title:`希尔排序`,description:`按逐次减半的间隔做插入，最后以间隔1完成整理。`,objectives:[`观察gap的整数减半序列`,`核对j-gap与j两处真实槽位`,`理解它通常不稳定且不是另一种增量序列`],min:-999,max:999,maxItems:30,defaultInput:[7,-3,0,5,-3,2,9],variant:`gap从⌊n/2⌋起，每轮取⌊gap/2⌋，到0结束；一般不稳定。`,complexity:`此减半增量采用O(n²)最坏界，不套用其他增量序列结论；调速不影响计数。`,extraSpace:`原数组内分组插入，额外O(1)标量；values物理容量30个int。`,sourceFile:`content/algorithms/cpp/shell-sort-1.0.0.cpp`,phases:[{id:`setup`,title:`准备存储`,explanation:`创建n与物理容量30的values，逻辑长度仍为输入项数。`},{id:`input`,title:`读入原数据`,explanation:`cin只消费原n个输入整数，没有隐藏的排序结果。`},{id:`gap`,title:`选择本轮间隔`,explanation:`整数除法产生n/2、再减半的序列。0或1项时初始gap为0，不进入分组插入。`},{id:`insert`,title:`取出分组中的一项`,explanation:`暂存key，j从i开始，在同一余数组内向左移动。`},{id:`shift`,title:`按间隔移动`,explanation:`先确保j>=gap，再比较values[j-gap]；较大值写到values[j]，j减去gap。`},{id:`place`,title:`插入本组空位`,explanation:`将key写到最终j位置；相同值不保证跨不同gap轮的相对次序。`},{id:`output`,title:`输出并结束`,explanation:`间隔1完成后逐项输出；当前输出随游标变化，可完整回退。`}],boundarySamples:[[],[7],[3,3,-2,3],[-999,999],[9,7,5,3,1]]},{id:`case.cpp.counting-sort`,version:`1.0.0`,programId:`program.cpp.counting-sort`,programVersion:`1.0.0`,language:`cpp`,title:`计数排序`,description:`将−20～20映射到41个频率桶，再从小到大回填原数组。`,objectives:[`核对value+20的桶索引`,`观察原频率累积与回填时扣减`,`理解有限整数域及额外存储的代价`],min:-20,max:20,maxItems:30,defaultInput:[7,-3,0,5,-3,2,9],variant:`固定41桶的频次回填；不使用累计位置或第二结果数组，不演示带附加字段记录的稳定性。`,complexity:`O(n+41)，即O(n+k)且k固定为41；实际比较还包括循环条件，并非零比较。`,extraSpace:`counts[41]增加41个int槽=164教学字节，另有常数标量；values[30]为原数组，不把输入存储算作额外结果数组。`,sourceFile:`content/algorithms/cpp/counting-sort-1.0.0.cpp`,phases:[{id:`setup`,title:`准备原数组`,explanation:`原数组物理容量30，逻辑长度n为实际输入数。`},{id:`input`,title:`读入有限域整数`,explanation:`仅允许−20～20；越域输入不会进入该案例的执行。`},{id:`buckets`,title:`建立41个零桶`,explanation:`counts[0]对应−20，counts[40]对应20；真实零初始化也计数组写入。`},{id:`count`,title:`累加真实频率`,explanation:`bucket=values[i]+20，将对应counts[bucket]加1；重复值落入同一桶。`},{id:`rebuild`,title:`按桶回填`,explanation:`桶索引从0到40；非零时把bucket−20写入values[at]并扣减频率，at前进。此时桶内显示剩余次数，不能冒称仍是最初频率。`},{id:`output`,title:`输出并结束`,explanation:`回填完成后桶为0，逐项输出真实数组；末步对象结束，后退恢复原状态。`}],boundarySamples:[[],[0],[20,-20,20,-20],[-20,0,20],[5,4,3,2,1]]}]},t=`#include <iostream>
// @phase setup
int main() {
    int n = {{n}};
    int values[30] = {};
    // @phase input
    for (int i = 0; i < n; i = i + 1) {
        std::cin >> values[i];
    }
    // @phase insert
    for (int i = 1; i < n; i = i + 1) {
        int key = values[i];
        int j = i - 1;
        // @phase shift
        while (j >= 0 && values[j] > key) {
            values[j + 1] = values[j];
            j = j - 1;
        }
        // @phase place
        values[j + 1] = key;
    }
    // @phase output
    for (int i = 0; i < n; i = i + 1) {
        std::cout << values[i] << " ";
    }
    std::cout << "\\n";
    return 0;
}
`,n=`#include <iostream>
// @phase setup
int main() {
    int n = {{n}};
    int values[30] = {};
    // @phase input
    for (int i = 0; i < n; i = i + 1) {
        std::cin >> values[i];
    }
    // @phase gap
    for (int gap = n / 2; gap > 0; gap = gap / 2) {
        // @phase insert
        for (int i = gap; i < n; i = i + 1) {
            int key = values[i];
            int j = i;
            // @phase shift
            while (j >= gap && values[j - gap] > key) {
                values[j] = values[j - gap];
                j = j - gap;
            }
            // @phase place
            values[j] = key;
        }
    }
    // @phase output
    for (int i = 0; i < n; i = i + 1) {
        std::cout << values[i] << " ";
    }
    std::cout << "\\n";
    return 0;
}
`,r=`#include <iostream>
// @phase setup
int main() {
    int n = {{n}};
    int values[30] = {};
    // @phase input
    for (int i = 0; i < n; i = i + 1) {
        std::cin >> values[i];
    }
    // @phase buckets
    int counts[41] = {};
    // @phase count
    for (int i = 0; i < n; i = i + 1) {
        int bucket = values[i] + 20;
        counts[bucket] = counts[bucket] + 1;
    }
    // @phase rebuild
    int at = 0;
    for (int bucket = 0; bucket < 41; bucket = bucket + 1) {
        while (counts[bucket] > 0) {
            values[at] = bucket - 20;
            at = at + 1;
            counts[bucket] = counts[bucket] - 1;
        }
    }
    // @phase output
    for (int i = 0; i < n; i = i + 1) {
        std::cout << values[i] << " ";
    }
    std::cout << "\\n";
    return 0;
}
`,i={schemaVersion:`1.1.0`,id:`catalog.cpp.recursive-sorts`,version:`1.0.0`,cases:[{id:`case.cpp.merge-sort`,version:`1.0.0`,programId:`program.cpp.merge-sort`,programVersion:`1.0.0`,language:`cpp`,title:`归并排序`,description:`递归整理两个闭区间，借助同一个辅助数组合并，再写回原区间。`,objectives:[`辨认闭区间、mid和真实递归深度`,`追踪同一scratch对象的别名与合并写入`,`区分正在执行、返回后和调用者观察`],min:-999,max:999,maxItems:30,defaultInput:[7,-3,0,5,-3,2,9],variant:`闭区间二分；相等时先取左侧，稳定归并；scratch只在main分配一次，由各帧共享别名。`,complexity:`O(n log n)时间；空或单项立即返回。原始计数包含循环、边界判断及初始化，并非只统计元素比较。`,extraSpace:`逻辑额外O(n)数组与O(log n)调用栈；scratch[30]实际占120教学字节，values[30]为输入。`,sourceFile:`content/algorithms/cpp/merge-sort-1.0.0.cpp`,knowledgeConcepts:[`递归`,`数组`,`分治`,`排序`],sourceOrigin:`project-original`,phases:[{id:`split`,title:`拆分闭区间`,explanation:`left>=right立即返回；否则以mid划分两半，先左后右递归。`},{id:`merge`,title:`合并两段`,explanation:`两段已由真实递归整理；比较values[i]与values[j]，相等先取左侧，写入共享scratch。`},{id:`tails`,title:`接上剩余项`,explanation:`只复制尚未耗尽的那一段；at、i、j均为当前帧的真实局部变量。`},{id:`copy`,title:`写回原区间`,explanation:`将scratch的left..right逐项写回values；其他区间不参与本次合并。`},{id:`setup`,title:`准备物理存储`,explanation:`n为原输入项数；values容量30，归并另有一份容量30的scratch。`},{id:`input`,title:`读入原数据`,explanation:`cin只消费原n项，请求中没有排序结果或第二份隐藏程序。`},{id:`run`,title:`调用排序`,explanation:`用闭区间0..n-1调用当前显示的函数；空数组对应0..-1并立即返回。`},{id:`output`,title:`输出并结束`,explanation:`输出实际values；返回后局部对象离开作用域，后退恢复完整状态。`}],boundarySamples:[[],[0],[2,2,-1,2],[-999,0,999],[5,4,3,2,1]]},{id:`case.cpp.quick-sort`,version:`1.0.0`,programId:`program.cpp.quick-sort`,programVersion:`1.0.0`,language:`cpp`,title:`快速排序`,description:`以区间末项为枢轴分区，递归较小的一侧，在当前帧循环处理较大的一侧。`,objectives:[`核对末项枢轴和<=的分区规则`,`观察真实交换写入与跳过自交换`,`辨认较小段递归和较大段同帧循环`],min:-999,max:999,maxItems:30,defaultInput:[7,-3,0,5,-3,2,9],variant:`末项枢轴Lomuto；<=枢轴进入左段，跳过自交换；仅长度至少2的较小段递归，较大段用while处理。一般不稳定。`,complexity:`平均O(n log n)、最坏O(n²)时间；已排序、逆序和全相等仍可能退化。较小段递归保证O(log n)调用栈，不画不存在的全递归树。`,extraSpace:`原数组内分区，额外O(1)数组存储及O(log n)调用栈；values物理容量30个int。`,sourceFile:`content/algorithms/cpp/quick-sort-1.0.0.cpp`,knowledgeConcepts:[`递归`,`数组`,`分治`,`排序`],sourceOrigin:`project-original`,phases:[{id:`partition`,title:`取末项枢轴`,explanation:`pivotValue保存values[right]；small从left起，尚未扫描区间由i推进。`},{id:`scan`,title:`扫描与交换`,explanation:`<=枢轴的项进入左段；small!=i才执行两次数组赋值，不能把每次条件成立都称作交换。`},{id:`pivot`,title:`将枢轴放回分界`,explanation:`small!=right才交换枢轴；返回small作为分界，后续区间严格排除该位置。`},{id:`recurse`,title:`递归较小段`,explanation:`只对长度至少2的较小段建立真实调用帧；较大段在同一帧缩小left或right。排序和全相等输入也逐轮缩短区间。`},{id:`setup`,title:`准备物理存储`,explanation:`n为原输入项数；values容量30，归并另有一份容量30的scratch。`},{id:`input`,title:`读入原数据`,explanation:`cin只消费原n项，请求中没有排序结果或第二份隐藏程序。`},{id:`run`,title:`调用排序`,explanation:`用闭区间0..n-1调用当前显示的函数；空数组对应0..-1并立即返回。`},{id:`output`,title:`输出并结束`,explanation:`输出实际values；返回后局部对象离开作用域，后退恢复完整状态。`}],boundarySamples:[[],[0],[2,2,-1,2],[-999,0,999],[5,4,3,2,1]]}]},a=`#include <iostream>
// @phase split
void merge_sort(int values[], int scratch[], int left, int right) {
    if (left >= right) {
        return;
    }
    int mid = left + (right - left) / 2;
    merge_sort(values, scratch, left, mid);
    merge_sort(values, scratch, mid + 1, right);
    // @phase merge
    int i = left;
    int j = mid + 1;
    int at = left;
    while (i <= mid && j <= right) {
        if (values[i] <= values[j]) {
            scratch[at] = values[i];
            i = i + 1;
        } else {
            scratch[at] = values[j];
            j = j + 1;
        }
        at = at + 1;
    }
    // @phase tails
    while (i <= mid) {
        scratch[at] = values[i];
        i = i + 1;
        at = at + 1;
    }
    while (j <= right) {
        scratch[at] = values[j];
        j = j + 1;
        at = at + 1;
    }
    // @phase copy
    for (int k = left; k <= right; k = k + 1) {
        values[k] = scratch[k];
    }
    return;
}
// @phase setup
int main() {
    int n = {{n}};
    int values[30] = {};
    int scratch[30] = {};
    // @phase input
    for (int i = 0; i < n; i = i + 1) {
        std::cin >> values[i];
    }
    // @phase run
    merge_sort(values, scratch, 0, n - 1);
    // @phase output
    for (int i = 0; i < n; i = i + 1) {
        std::cout << values[i] << " ";
    }
    std::cout << "\\n";
    return 0;
}
`,o=`#include <iostream>
// @phase partition
int partition(int values[], int left, int right) {
    int pivotValue = values[right];
    int small = left;
    // @phase scan
    for (int i = left; i < right; i = i + 1) {
        if (values[i] <= pivotValue) {
            if (small != i) {
                int temp = values[small];
                values[small] = values[i];
                values[i] = temp;
            }
            small = small + 1;
        }
    }
    // @phase pivot
    if (small != right) {
        int temp = values[small];
        values[small] = values[right];
        values[right] = temp;
    }
    return small;
}
// @phase recurse
void quick_sort(int values[], int left, int right) {
    while (left < right) {
        int pivotIndex = partition(values, left, right);
        if (pivotIndex - left < right - pivotIndex) {
            if (left < pivotIndex - 1) {
                quick_sort(values, left, pivotIndex - 1);
            }
            left = pivotIndex + 1;
        } else {
            if (pivotIndex + 1 < right) {
                quick_sort(values, pivotIndex + 1, right);
            }
            right = pivotIndex - 1;
        }
    }
    return;
}
// @phase setup
int main() {
    int n = {{n}};
    int values[30] = {};
    // @phase input
    for (int i = 0; i < n; i = i + 1) {
        std::cin >> values[i];
    }
    // @phase run
    quick_sort(values, 0, n - 1);
    // @phase output
    for (int i = 0; i < n; i = i + 1) {
        std::cout << values[i] << " ";
    }
    std::cout << "\\n";
    return 0;
}
`,s={schemaVersion:`1.2.0`,id:`catalog.cpp.bucket-sort`,version:`1.0.0`,cases:[{id:`case.cpp.bucket-sort`,version:`1.0.0`,programId:`program.cpp.bucket-sort`,programVersion:`1.0.0`,language:`cpp`,title:`桶排序`,description:`将有限域整数依序放入五个桶，在桶内插入排序，再按桶序写回原数组。`,objectives:[`核对加20后整除10的真实桶映射`,`区分物理30槽、逻辑数量和写后尚未计数的原子步骤`,`观察桶内移动、按桶合并及完整状态回退`],min:-20,max:29,maxItems:30,defaultInput:[7,-3,0,5,-3,2,9],variant:`固定五个宽10闭区间桶；依序追加，每桶30槽；严格大于key才右移，稳定桶内插入；按桶序回填，桶数据保留至main结束。`,complexity:`O(n+B+Σmᵦ²)，B=5；最坏所有项同桶为O(n²+B)，不承诺任意分布线性。原计数含循环、输入和初始化。`,extraSpace:`bucketData[150]与bucketSizes[5]共155个int=620教学字节，另有常数标量；values[30]原输入另占120字节。每桶30槽独立，不借空桶容量。`,sourceFile:`content/algorithms/cpp/bucket-sort-1.0.0.cpp`,knowledgeConcepts:[`数组`,`整数区间映射`,`桶排序`,`插入排序`,`辅助空间`],sourceOrigin:`project-original`,bucketLayout:{bucketCount:5,bucketCapacity:30,width:10,ranges:[[-20,-11],[-10,-1],[0,9],[10,19],[20,29]],dataObject:`bucketData`,sizesObject:`bucketSizes`},phases:[{id:`setup`,title:`准备原数组`,explanation:`n等于真实输入项数，values物理容量30；零初始化不代表已有输入。`},{id:`input`,title:`读入有限域整数`,explanation:`cin只读取原n项；允许−20～29，域外或超过30项在执行前提示。`},{id:`buckets`,title:`建立五桶物理存储`,explanation:`未初始化的bucketData[150]分成五段，每段30槽；bucketSizes[5]单独清零，保存真实逻辑数量，辅助数组共620教学字节。未用槽不是输入零。`},{id:`scatter`,title:`分配到真实桶`,explanation:`bucket=(values[i]+20)/10，域内分子0..49，结果0..4；写入bucket×30+当前数量后，再单独递增数量。两步之间显示已写但尚未计数的槽。`},{id:`sort`,title:`选择桶并取出key`,explanation:`依桶0..4逐桶处理；base=桶号×30，暂存桶内一项为key，j从其左侧开始。空桶和单项无需移动。`},{id:`shift`,title:`桶内比较并右移`,explanation:`先检查j>=0，再读取本桶base+j；严格大于key才右移。槽值重复与暂存key是实际中间态，不提前显示排序答案。`},{id:`place`,title:`将key写回本桶`,explanation:`把key写到base+j+1；同值写入也计数组写。相等项不会被严格大于条件越过。`},{id:`merge`,title:`按桶顺序合并`,explanation:`按桶0..4和各桶实际数量读取，逐项写回values；bucketData和bucketSizes继续保留，不称作剩余数量。`},{id:`output`,title:`输出并结束`,explanation:`输出真实values。main返回时自动对象离开作用域；后退恢复桶、计数、原数组及完整分配状态。`}],boundarySamples:[[],[29],[-20,29],[-20,-11,-10,-1,0,9,10,19,20,29],[5,5,-15,-15],[29,19,9,-1,-11,-20]]}]},c=`#include <iostream>
// @phase setup
int main() {
    int n = {{n}};
    int values[30] = {};
    // @phase input
    for (int i = 0; i < n; i = i + 1) {
        std::cin >> values[i];
    }
    // @phase buckets
    int bucketData[150];
    int bucketSizes[5] = {};
    // @phase scatter
    for (int i = 0; i < n; i = i + 1) {
        int bucket = (values[i] + 20) / 10;
        int slot = bucket * 30 + bucketSizes[bucket];
        bucketData[slot] = values[i];
        bucketSizes[bucket] = bucketSizes[bucket] + 1;
    }
    // @phase sort
    for (int bucket = 0; bucket < 5; bucket = bucket + 1) {
        int base = bucket * 30;
        for (int i = 1; i < bucketSizes[bucket]; i = i + 1) {
            int key = bucketData[base + i];
            int j = i - 1;
            // @phase shift
            while (j >= 0 && bucketData[base + j] > key) {
                bucketData[base + j + 1] = bucketData[base + j];
                j = j - 1;
            }
            // @phase place
            bucketData[base + j + 1] = key;
        }
    }
    // @phase merge
    int at = 0;
    for (int bucket = 0; bucket < 5; bucket = bucket + 1) {
        for (int i = 0; i < bucketSizes[bucket]; i = i + 1) {
            values[at] = bucketData[bucket * 30 + i];
            at = at + 1;
        }
    }
    // @phase output
    for (int i = 0; i < n; i = i + 1) {
        std::cout << values[i] << " ";
    }
    std::cout << "\\n";
    return 0;
}
`,l=e.cases,u={id:e.id,version:e.version},d=i.cases,f=s.cases,p=[...l,...d,...f];function m(e){return d.some(t=>t.id===e.id)}function h(e){return f.some(t=>t.id===e.id)?{id:s.id,version:s.version}:m(e)?{id:i.id,version:i.version}:u}var g={"case.cpp.insertion-sort":t,"case.cpp.shell-sort":n,"case.cpp.counting-sort":r,"case.cpp.merge-sort":a,"case.cpp.quick-sort":o,"case.cpp.bucket-sort":c};function _(e){return p.find(t=>t.id===e)}function v(e,t){return t.length<=e.maxItems&&t.every(t=>Number.isInteger(t)&&t>=e.min&&t<=e.max)}function y(e,t){let n=t.trim(),r=n===`[]`?[]:n.split(/[\s,，]+/).map(Number),i=n.length>0&&n.length<=1024&&(n===`[]`||n.split(/[\s,，]+/).every(e=>/^[+-]?\d+$/.test(e)))&&v(e,r);return{valid:i,values:i?r:[],issue:i?``:`请输入0～${e.maxItems}个${e.min}～${e.max}的十进制整数，以空格或逗号分隔；空数组写[]。`}}function b(e,t){if(!_(e.id)||!v(e,t))throw Error(`E_INPUT_INVALID`);let n=g[e.id];if(!n||n.split(`{{n}}`).length!==2)throw Error(`E_CONTENT_MISMATCH`);let r=n.replace(`{{n}}`,String(t.length)),i=[...r.matchAll(/^[ \t]*\/\/ @phase ([a-z]+)\r?$/gm)].map(t=>{let n=e.phases.find(e=>e.id===t[1]);if(!n)throw Error(`E_CONTENT_MISMATCH`);return{...n,start:new TextEncoder().encode(r.slice(0,t.index)).length}});if(i.length!==e.phases.length)throw Error(`E_CONTENT_MISMATCH`);return{source:r,input:[...t],phases:i}}export{b as a,l as c,y as i,h as l,f as n,d as o,m as r,_ as s,p as t};