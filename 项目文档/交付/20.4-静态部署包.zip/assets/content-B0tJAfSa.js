var e={schemaVersion:`1.0.0`,id:`catalog.cpp.classics`,version:`1.0.0`,maxDraftChars:128,cases:[{id:`case.cpp.hanoi`,version:`1.0.0`,programId:`program.cpp.hanoi`,programVersion:`1.0.0`,language:`cpp`,kind:`hanoi`,title:`汉诺塔`,description:`读取真实盘位置数组，逐步核对递归调用、合法移动与同游标回退。`,inputArity:1,min:0,max:5,defaultInput:[3],inputHelp:`一个0～5的整数盘数；0盘合法，最多31次移动。`,variant:`递归移动n−1盘/当前盘/n−1盘；柱号0/1/2，positions记录真实盘位置。`,complexity:`移动2^n−1次，时间O(2^n)、递归辅助O(n)；轨迹/编码/校验与回放开销另计。`,extraSpace:`positions[5]+moveState[4]共36教学字节，另有真实参数/局部；最多6辅助帧加main共7帧。`,knowledgeConcepts:[`递归`,`数组别名`,`汉诺塔`,`调用栈`],objectives:[`核对原文、真实输入与当前步骤`,`区分原子中间态和完整结果`,`同游标查看内存/栈并完整回退`],sourceFile:`content/algorithms/cpp/hanoi-1.0.0.cpp`,sourceOrigin:`project-original`,boundarySamples:[{id:`n0`,title:`0盘`,input:[0]},{id:`n1`,title:`1盘`,input:[1]},{id:`n2`,title:`2盘`,input:[2]},{id:`n3`,title:`3盘`,input:[3]},{id:`n4`,title:`4盘`,input:[4]},{id:`n5`,title:`5盘`,input:[5]}],phases:[{id:`recurse`,title:`递归分解左半程`,explanation:`n=0实际返回；否则先移动n−1盘。形参和数组别名属于当前真实帧。`},{id:`prepare`,title:`记录当前候选移动`,explanation:`from/to/盘索引分别写入moveState，尚未改变positions或次数，不称作已完成移动。`},{id:`move`,title:`实际改变盘位置并计数`,explanation:`positions更新、移动次数和cout是各自真实步骤；盘图只读当前positions，不提前补齐计数。`},{id:`resume`,title:`递归完成右半程`,explanation:`移动后递归处理剩余n−1盘，返回时恢复实际调用者。`},{id:`input`,title:`读取实际输入`,explanation:`cin按源码逐项读取固定参数，未初始化变量不当作0。`},{id:`domain`,title:`检查教学输入域`,explanation:`实际C++保留DOMAIN非零返回保护；GUI只发送已通过固定域/个数检查的输入。`},{id:`setup`,title:`初始化真实存储`,explanation:`标量/数组逐个初始化，尚未声明或未初始化的槽不补齐。`},{id:`finish`,title:`输出结果并返回`,explanation:`cout为真实程序结果，正常结束不表示素数/回文分类为真；main返回后自动对象死亡，后退恢复。`}]},{id:`case.cpp.euclidean-gcd`,version:`1.0.0`,programId:`program.cpp.euclidean-gcd`,programVersion:`1.0.0`,language:`cpp`,kind:`gcd`,title:`辗转相除法求GCD`,description:`逐步观察符号归一、余数和a/b的真实变化，明确零参数约定。`,inputArity:2,min:-999,max:999,defaultInput:[84,-30],inputHelp:`两个−999～999整数；结果非负，本例约定gcd(0,0)=0。`,variant:`分别取绝对值，再迭代a%b、a=b、b=余数；b=0结束。`,complexity:`欧几里得循环次数O(log max(|a|,|b|))，常数辅助空间；两零直接返回约定0。`,extraSpace:`常数int32标量，不递归、不分配heap；±999域避开INT_MIN取负。`,knowledgeConcepts:[`取模`,`循环`,`最大公约数`,`符号与零`],objectives:[`核对原文、真实输入与当前步骤`,`区分原子中间态和完整结果`,`同游标查看内存/栈并完整回退`],sourceFile:`content/algorithms/cpp/euclidean-gcd-1.0.0.cpp`,sourceOrigin:`project-original`,boundarySamples:[{id:`both-zero`,title:`两零`,input:[0,0]},{id:`left-zero`,title:`左零与负数`,input:[0,-999]},{id:`right-zero`,title:`右零`,input:[999,0]},{id:`negative`,title:`双负数`,input:[-84,-30]},{id:`fib`,title:`较长余数链`,input:[987,610]},{id:`coprime`,title:`较大互质数`,input:[997,991]}],phases:[{id:`input`,title:`读取实际输入`,explanation:`cin按源码逐项读取固定参数，未初始化变量不当作0。`},{id:`domain`,title:`检查教学输入域`,explanation:`实际C++保留DOMAIN非零返回保护；GUI只发送已通过固定域/个数检查的输入。`},{id:`normalize`,title:`将两个值归为非负`,explanation:`输入域±999保证取负安全；零保持0，gcd(0,0)本例约定0。`},{id:`remainder`,title:`计算当前余数`,explanation:`只有b非0才执行a%b，随后a和b依次更新，中间态仍按原值显示。`},{id:`advance`,title:`更新当前循环状态`,explanation:`这是实际赋值/循环进展，不把下一步结果提前显示。`},{id:`finish`,title:`输出结果并返回`,explanation:`cout为真实程序结果，正常结束不表示素数/回文分类为真；main返回后自动对象死亡，后退恢复。`}]},{id:`case.cpp.trial-division-prime`,version:`1.0.0`,programId:`program.cpp.trial-division-prime`,programVersion:`1.0.0`,language:`cpp`,kind:`prime`,title:`朴素素数判断`,description:`从2逐个尝试实际因子，观察判断、早停及0/1/负数边界。`,inputArity:1,min:-999,max:999,defaultInput:[97],inputHelp:`一个−999～999整数；低于2都不是素数。`,variant:`逐整数试除至d<=n/d，发现首个整除因子即停；不是筛法。`,complexity:`最坏O(sqrt(n))试除、常数空间；负数/0/1直接分类为否。`,extraSpace:`常数int32标量；d从2开始，n/d避开d*d溢出。`,knowledgeConcepts:[`素数`,`试除`,`短路条件`,`整数边界`],objectives:[`核对原文、真实输入与当前步骤`,`区分原子中间态和完整结果`,`同游标查看内存/栈并完整回退`],sourceFile:`content/algorithms/cpp/trial-division-prime-1.0.0.cpp`,sourceOrigin:`project-original`,boundarySamples:[{id:`negative`,title:`负数`,input:[-999]},{id:`zero`,title:`零`,input:[0]},{id:`one`,title:`一`,input:[1]},{id:`two`,title:`最小素数`,input:[2]},{id:`square`,title:`平方合数`,input:[961]},{id:`large-prime`,title:`较大素数`,input:[997]},{id:`max`,title:`上界合数`,input:[999]}],phases:[{id:`input`,title:`读取实际输入`,explanation:`cin按源码逐项读取固定参数，未初始化变量不当作0。`},{id:`domain`,title:`检查教学输入域`,explanation:`实际C++保留DOMAIN非零返回保护；GUI只发送已通过固定域/个数检查的输入。`},{id:`setup`,title:`初始化真实存储`,explanation:`标量/数组逐个初始化，尚未声明或未初始化的槽不补齐。`},{id:`classify`,title:`按源码处理边界`,explanation:`素数n<2为否；回文负数为否，非负才反转。结果0是正常分类，不是运行错误。`},{id:`trial`,title:`逐整数尝试因子`,explanation:`从2逐个试除，d<=n/d避免平方溢出；首次整除记录实际divisor，0表示尚未发现。`},{id:`advance`,title:`更新当前循环状态`,explanation:`这是实际赋值/循环进展，不把下一步结果提前显示。`},{id:`finish`,title:`输出结果并返回`,explanation:`cout为真实程序结果，正常结束不表示素数/回文分类为真；main返回后自动对象死亡，后退恢复。`}]},{id:`case.cpp.palindrome-number`,version:`1.0.0`,programId:`program.cpp.palindrome-number`,programVersion:`1.0.0`,language:`cpp`,kind:`palindrome`,title:`回文数`,description:`读取真实拆位和完整反转过程，核对负号、零和尾零规则。`,inputArity:1,min:-999,max:999,defaultInput:[121],inputHelp:`一个−999～999整数；负数判否，非负数完整反转比较。`,variant:`负数直接否；逐次取末位/反转累积/除10，再与原值比较，不保留前导零。`,complexity:`十进制位数k下O(k)时间、常数空间；本例最多3位。`,extraSpace:`常数int32标量；所有反转及中间乘加≤999，由输入域排除溢出。`,knowledgeConcepts:[`十进制拆位`,`循环`,`回文`,`溢出边界`],objectives:[`核对原文、真实输入与当前步骤`,`区分原子中间态和完整结果`,`同游标查看内存/栈并完整回退`],sourceFile:`content/algorithms/cpp/palindrome-number-1.0.0.cpp`,sourceOrigin:`project-original`,boundarySamples:[{id:`negative`,title:`负数`,input:[-121]},{id:`zero`,title:`零`,input:[0]},{id:`single`,title:`个位`,input:[9]},{id:`tail-zero`,title:`尾零`,input:[100]},{id:`symmetric`,title:`内部零回文`,input:[101]},{id:`not-palindrome`,title:`非回文`,input:[123]},{id:`max`,title:`上界`,input:[999]}],phases:[{id:`input`,title:`读取实际输入`,explanation:`cin按源码逐项读取固定参数，未初始化变量不当作0。`},{id:`domain`,title:`检查教学输入域`,explanation:`实际C++保留DOMAIN非零返回保护；GUI只发送已通过固定域/个数检查的输入。`},{id:`setup`,title:`初始化真实存储`,explanation:`标量/数组逐个初始化，尚未声明或未初始化的槽不补齐。`},{id:`classify`,title:`按源码处理边界`,explanation:`素数n<2为否；回文负数为否，非负才反转。结果0是正常分类，不是运行错误。`},{id:`extract`,title:`拆末位并反转`,explanation:`digit/反转累积/剩余数各自赋值；最多三位，乘加中间值≤999。`},{id:`compare`,title:`与原值比较`,explanation:`只由C++比较真实reversed和original设置palindrome，0反转为0，尾零不保留。`},{id:`finish`,title:`输出结果并返回`,explanation:`cout为真实程序结果，正常结束不表示素数/回文分类为真；main返回后自动对象死亡，后退恢复。`}]}]},t=`#include <iostream>
// @phase recurse
void hanoi(int n, int from, int spare, int to, int positions[], int moveState[]) {
    if (n == 0) { return; }
    hanoi(n - 1, from, to, spare, positions, moveState);
    // @phase prepare
    moveState[1] = from;
    moveState[2] = to;
    moveState[3] = n - 1;
    // @phase move
    positions[n - 1] = to;
    moveState[0] = moveState[0] + 1;
    std::cout << "MOVE " << n << " " << from << " " << to << "\\n";
    // @phase resume
    hanoi(n - 1, spare, from, to, positions, moveState);
}
// @phase input
int main() {
    int n;
    std::cin >> n;
    // @phase domain
    if (n < 0 || n > 5) {
        std::cout << "DOMAIN\\n";
        return 1;
    }
    // @phase setup
    int positions[5] = {};
    int moveState[4] = {};
    hanoi(n, 0, 1, 2, positions, moveState);
    // @phase finish
    std::cout << "MOVES " << moveState[0] << "\\n";
    return 0;
}
`,n=`#include <iostream>
// @phase input
int main() {
    int first;
    int second;
    std::cin >> first >> second;
    // @phase domain
    if (first < -999 || first > 999 || second < -999 || second > 999) {
        std::cout << "DOMAIN\\n";
        return 1;
    }
    // @phase normalize
    int a = first;
    int b = second;
    if (a < 0) { a = 0 - a; }
    if (b < 0) { b = 0 - b; }
    // @phase remainder
    while (b != 0) {
        int remainder = a % b;
        // @phase advance
        a = b;
        b = remainder;
    }
    // @phase finish
    std::cout << "GCD " << a << "\\n";
    return 0;
}
`,r=`#include <iostream>
// @phase input
int main() {
    int n;
    std::cin >> n;
    // @phase domain
    if (n < -999 || n > 999) {
        std::cout << "DOMAIN\\n";
        return 1;
    }
    // @phase setup
    int isPrime = 0;
    int divisor = 0;
    int d = 2;
    // @phase classify
    if (n >= 2) {
        isPrime = 1;
        // @phase trial
        while (d <= n / d && isPrime == 1) {
            if (n % d == 0) {
                isPrime = 0;
                divisor = d;
            }
            // @phase advance
            d = d + 1;
        }
    }
    // @phase finish
    std::cout << "PRIME " << isPrime << "\\n";
    return 0;
}
`,i=`#include <iostream>
// @phase input
int main() {
    int original;
    std::cin >> original;
    // @phase domain
    if (original < -999 || original > 999) {
        std::cout << "DOMAIN\\n";
        return 1;
    }
    // @phase setup
    int working = original;
    int reversed = 0;
    int digit = 0;
    int palindrome = 0;
    // @phase classify
    if (original >= 0) {
        while (working > 0) {
            // @phase extract
            digit = working % 10;
            reversed = reversed * 10 + digit;
            working = working / 10;
        }
        // @phase compare
        if (reversed == original) { palindrome = 1; }
    }
    // @phase finish
    std::cout << "PALINDROME " << palindrome << "\\n";
    return 0;
}
`,a=e.cases,o={id:e.id,version:e.version},s=e=>a.find(t=>t.id===e),c={"case.cpp.hanoi":t,"case.cpp.euclidean-gcd":n,"case.cpp.trial-division-prime":r,"case.cpp.palindrome-number":i};function l(t,n){let r=n.trim().split(/[\s,，]+/),i=r.map(Number),a=n.length<=e.maxDraftChars&&r.length===t.inputArity&&r.every(e=>/^[+-]?\d+$/.test(e))&&i.every(e=>Number.isInteger(e)&&e>=t.min&&e<=t.max);return{valid:a,values:a?i.map(e=>e===0?0:e):[],issue:`${t.inputHelp}请用空格或逗号分隔，恰${t.inputArity}项，最多128字符。`}}function u(e,t){let n=l(e,t),r=c[e.id];if(!s(e.id)||!n.valid)throw Error(`E_INPUT_INVALID`);if(!r)throw Error(`E_CONTENT_MISMATCH`);let i=[...r.matchAll(/^[ \t]*\/\/ @phase ([a-z]+)\r?$/gm)].map(t=>{let n=e.phases.find(e=>e.id===t[1]);if(!n)throw Error(`E_CONTENT_MISMATCH`);return{...n,start:new TextEncoder().encode(r.slice(0,t.index)).length}});if(i.length!==e.phases.length)throw Error(`E_CONTENT_MISMATCH`);return{source:r,input:[...n.values],phases:i}}export{u as a,l as i,a as n,o as r,s as t};