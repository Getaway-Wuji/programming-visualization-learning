import{a as e,n as t,t as n}from"./jsx-runtime-BVQXJMCF.js";import{m as r,n as i,p as a,s as o,t as s}from"./Ui-DUyl9t38.js";import{G as c}from"./index-Fqu0rJTh.js";import{r as l,t as u}from"./advanced-client-CdFjHu49.js";import{n as d,t as f}from"./custom-code-D6y0X4ha.js";/* empty css                        *//* empty css                 */import{a as p,c as m,n as h,o as g,r as _,s as v,t as y}from"./content-CHKfAgde.js";import{t as b}from"./SortSource-BQ9nEhP7.js";var x=e(t(),1),S={schemaVersion:`1.0.0`,id:`catalog.advanced.multi-solutions`,version:`1.0.0`,examples:[{exampleRef:{id:`example.cpp.two-sum`,version:`1.0.0`},solutions:[{solutionRef:{id:`solution.cpp.two-sum-enumeration`,version:`1.0.0`},programRef:{id:`program.cpp.example-two-sum-enumeration`,version:`1.0.0`},sourceFile:`content/advanced/example-two-sum-1.0.0.cpp`,title:`双重枚举`,strategy:`外层确定第一个位置i，内层从i+1开始。这样既不会把同一位置用两次，也不会同时检查(i,j)和(j,i)。`,time:`最坏 O(n²)，已含唯一性检查`,space:`额外 O(1)，只保存计数与两个答案下标`,derivation:`对所有i<j访问n(n−1)/2个下标对；为核验恰好一组解，命中后仍继续枚举。输入读取O(n)，由二次枚举主导。values是输入存储，不作为辅助空间。`,suitable:`小输入、直接核对不同下标对、希望少用辅助存储。`,cautions:`不能使用同一下标两次，也不能命中即返回而漏掉多解。渐进二次不代表当前12项规模必然比排序慢。`},{solutionRef:{id:`solution.cpp.two-sum-merge-pointers`,version:`1.0.0`},programRef:{id:`program.cpp.example-two-sum-merge-pointers`,version:`1.0.0`},sourceFile:`content/advanced/example-two-sum-merge-pointers-1.0.0.cpp`,title:`归并索引后双指针`,strategy:`先排原下标，再从两端缩小候选区间；对相等值成段计数。`,time:`最坏 O(n log n)，已含唯一性检查与输入读取`,space:`额外 O(n)；order与scratch各12槽，共96教学字节，另有常数标量`,derivation:`自底向上归并有⌈log₂n⌉轮，每轮合并和拷回至多n个下标；双指针每次使边界向内，重复值也只按段扫描一次。总O(n log n)+O(n)。原values保持原顺序，两个索引数组形成O(n)辅助空间，无递归栈。`,suitable:`需要保留原下标、理解排序预处理与线性扫描的组合，或n较大时比较渐进增长。`,cautions:`排序只改order，不改原values；命中不能立即返回，要累计所有下标对。两端相同值m项有m(m−1)/2对，异值段为两段长度乘积。小规模下排序与辅助写入可能比枚举更多。`}],supplementalSamples:[{key:`all-equal-ambiguous`,values:[3,3,3],target:6,expectedStdout:`INVALID_INPUT
`,expectedReturn:1},{key:`disjoint-pairs`,values:[1,2,3,4],target:5,expectedStdout:`INVALID_INPUT
`,expectedReturn:1},{key:`original-endpoints`,values:[999,0,-999],target:0,expectedStdout:`0 2
`,expectedReturn:0}]},{exampleRef:{id:`example.cpp.move-zeroes`,version:`1.0.0`},solutions:[{solutionRef:{id:`solution.cpp.move-zeroes-compact`,version:`1.0.0`},programRef:{id:`program.cpp.example-move-zeroes-compact`,version:`1.0.0`},sourceFile:`content/advanced/example-move-zeroes-1.0.0.cpp`,title:`稳定压缩后补零`,strategy:`read扫描每个输入位置，write指向下一个应放非零值的位置。遇到非零时写到values[write]，再推进write；遇到零只推进扫描。`,time:`最坏 O(n)，完整读取与输出也是O(n)`,space:`额外 O(1)，常数个读写游标，无完整数组副本`,derivation:`第一轮按原顺序写所有非零，第二轮补齐剩余零。算法核心总n次数组写（含同位置/同值写）；输入读取另外计入真实状态计数。两轮合计O(n)，额外空间O(1)。`,suitable:`想直接用已处理前缀推导稳定性，或希望算法核心写入次数固定为n。`,cautions:`write只在非零分支递增；压缩后必须把尾部补零。辅助空间排除输入本身，不能拿物理固定容量推断任意规模O(1)存储。`},{solutionRef:{id:`solution.cpp.move-zeroes-swap`,version:`1.0.0`},programRef:{id:`program.cpp.example-move-zeroes-swap`,version:`1.0.0`},sourceFile:`content/advanced/example-move-zeroes-swap-1.0.0.cpp`,title:`非零前移并原地交换`,strategy:`write前保持已确认非零前缀；read遇非零时与前方零槽交换，同位置跳过。`,time:`最坏 O(n)，完整读取与输出也是O(n)`,space:`额外 O(1)，仅write/read/temp等常数标量，无完整数组副本`,derivation:`read访问n项，write只随非零递增，因此一次扫描O(n)。write<read时，write槽必为0，交换不会打乱已写非零顺序；每次实际交换有两次数组写。同位置不写，无零或全零时算法核心可零次数组写。`,suitable:`希望一次扫描完成，或无零/前方没有空洞时避免无意义写入；同时观察稳定性不变量。`,cautions:`只有非零且write!=read才交换。两次写入是一组算法交换，但当前引擎交换指标未标注，显示其真实0；应查看数组写计数。交错零时可能比压缩补零写得更多。`}],supplementalSamples:[{key:`leading-zeroes`,values:[0,0,5,-1],expectedStdout:`5 -1 0 0
`,expectedReturn:0},{key:`alternating-equal`,values:[4,0,4,0],expectedStdout:`4 4 0 0
`,expectedReturn:0},{key:`extreme-zeroes`,values:[-999,0,999,0],expectedStdout:`-999 999 0 0
`,expectedReturn:0}]},{exampleRef:{id:`example.cpp.search-insert`,version:`1.0.0`},solutions:[{solutionRef:{id:`solution.cpp.search-insert-binary`,version:`1.0.0`},programRef:{id:`program.cpp.example-search-insert-binary`,version:`1.0.0`},sourceFile:`content/advanced/example-search-insert-1.0.0.cpp`,title:`半开区间二分`,strategy:`初始候选区间为[left,right)=[0,n)。left之前的元素都小于target；right及之后的位置已无需继续检查。`,time:`搜索核心最坏 O(log n)；完整stdin演示 O(n)`,space:`额外 O(1)，只有left/right/middle等常数标量`,derivation:`始终保留半开候选[left,right)，right从n开始；每轮缩到一半，left==right时即插入位置。搜索O(log n)，输入读取O(n)；没有辅助数组。`,suitable:`习惯半开区间与数组长度n，想让未命中和尾插自然统一在left。`,cautions:`right=n不可直接索引；循环必须left<right，右缩为middle。不能把闭区间的right=middle−1混进本方案。`},{solutionRef:{id:`solution.cpp.search-insert-closed`,version:`1.0.0`},programRef:{id:`program.cpp.example-search-insert-closed`,version:`1.0.0`},sourceFile:`content/advanced/example-search-insert-closed-1.0.0.cpp`,title:`闭区间二分与候选位置`,strategy:`在[left,right]内找第一个不小于target的位置，answer初始为n。`,time:`搜索核心最坏 O(log n)；完整stdin演示 O(n)`,space:`额外 O(1)，只有left/right/middle/answer等常数标量`,derivation:`每轮舍弃至少中点所在的一半候选，left<=right终止前最多O(log n)次；命中或更大值都记录answer并继续向左。输入n项需O(n)，不包含在核心搜索复杂度中；没有辅助数组。`,suitable:`习惯闭区间语义，或要明确记录目前最靠左的可行候选；与半开区间对照检查边界。`,cautions:`right必须初始化为n−1；右缩到middle−1而非middle，否则可能死循环。未找到候选时answer=n；半开区间方案则最终返回left。两者都要求原数组严格递增。`}],supplementalSamples:[{key:`first-hit`,values:[-999,0,999],target:-999,expectedStdout:`0
`,expectedReturn:0},{key:`last-hit`,values:[-999,0,999],target:999,expectedStdout:`2
`,expectedReturn:0},{key:`single-hit`,values:[0],target:0,expectedStdout:`0
`,expectedReturn:0}]}]},C=`#include <iostream>
int main() {
  int n = {{n}};
  int values[12];
  int order[12];
  int scratch[12];
  for (int i = 0; i < n; i = i + 1) {
    std::cin >> values[i];
    order[i] = i;
  }
  int target;
  std::cin >> target;
  // Merge original indices, leaving values in its original order.
  for (int width = 1; width < n; width = width * 2) {
    for (int start = 0; start < n; start = start + width * 2) {
      int middle = start + width;
      if (middle > n) { middle = n; }
      int end = start + width * 2;
      if (end > n) { end = n; }
      int left = start;
      int right = middle;
      int write = start;
      while (left < middle && right < end) {
        if (values[order[left]] <= values[order[right]]) {
          scratch[write] = order[left];
          left = left + 1;
        } else {
          scratch[write] = order[right];
          right = right + 1;
        }
        write = write + 1;
      }
      while (left < middle) {
        scratch[write] = order[left];
        left = left + 1;
        write = write + 1;
      }
      while (right < end) {
        scratch[write] = order[right];
        right = right + 1;
        write = write + 1;
      }
      for (int i = start; i < end; i = i + 1) { order[i] = scratch[i]; }
    }
  }
  int left = 0;
  int right = n - 1;
  int pairs = 0;
  int answerLeft = -1;
  int answerRight = -1;
  while (left < right) {
    int sum = values[order[left]] + values[order[right]];
    if (sum < target) {
      left = left + 1;
    } else {
      if (sum > target) {
        right = right - 1;
      } else {
        if (pairs == 0) {
          answerLeft = order[left];
          answerRight = order[right];
          if (answerLeft > answerRight) {
            int temp = answerLeft;
            answerLeft = answerRight;
            answerRight = temp;
          }
        }
        int leftValue = values[order[left]];
        int rightValue = values[order[right]];
        if (leftValue == rightValue) {
          int count = right - left + 1;
          pairs = pairs + count * (count - 1) / 2;
          break;
        }
        int leftCount = 0;
        int rightCount = 0;
        while (left <= right && values[order[left]] == leftValue) {
          leftCount = leftCount + 1;
          left = left + 1;
        }
        while (left <= right && values[order[right]] == rightValue) {
          rightCount = rightCount + 1;
          right = right - 1;
        }
        pairs = pairs + leftCount * rightCount;
      }
    }
  }
  if (pairs != 1) { std::cout << "INVALID_INPUT\\n"; return 1; }
  std::cout << answerLeft << " " << answerRight << "\\n";
  return 0;
}
`,w=`#include <iostream>
int main() {
  int n = {{n}};
  int values[12];
  for (int i = 0; i < n; i = i + 1) { std::cin >> values[i]; }
  int write = 0;
  for (int read = 0; read < n; read = read + 1) {
    if (values[read] != 0) {
      if (write != read) {
        int temp = values[write];
        values[write] = values[read];
        values[read] = temp;
      }
      write = write + 1;
    }
  }
  for (int i = 0; i < n; i = i + 1) {
    if (i > 0) { std::cout << " "; }
    std::cout << values[i];
  }
  std::cout << "\\n";
  return 0;
}
`,T=`#include <iostream>
int main() {
  int n = {{n}};
  int values[12];
  for (int i = 0; i < n; i = i + 1) { std::cin >> values[i]; }
  int target;
  std::cin >> target;
  int left = 0;
  int right = n - 1;
  int answer = n;
  while (left <= right) {
    int middle = left + (right - left) / 2;
    if (values[middle] >= target) {
      answer = middle;
      right = middle - 1;
    } else {
      left = middle + 1;
    }
  }
  std::cout << answer << "\\n";
  return 0;
}
`,E=S.examples;function D(e){return E.find(t=>t.exampleRef.id===e.id&&t.exampleRef.version===e.version)?.solutions??[]}function O(e){return[...e.samples,...E.find(t=>t.exampleRef.id===e.id)?.supplementalSamples??[]]}var k={[y[0].sourceFile]:m,"content/advanced/example-two-sum-merge-pointers-1.0.0.cpp":C,[y[1].sourceFile]:v,"content/advanced/example-move-zeroes-swap-1.0.0.cpp":w,[y[2].sourceFile]:g,"content/advanced/example-search-insert-closed-1.0.0.cpp":T};function A(e,t,n){if(!p(e,n))throw Error(`E_INPUT_INVALID`);let r=D(e).find(e=>e.solutionRef.id===t.solutionRef.id&&e.solutionRef.version===t.solutionRef.version);if(!r||r.sourceFile!==t.sourceFile)throw Error(`E_CONTENT_MISMATCH`);let i=k[r.sourceFile];if(!i||i.split(`{{n}}`).length!==2)throw Error(`E_CONTENT_MISMATCH`);return{source:i.replace(`{{n}}`,String(n.values.length)),input:[...n.values,...e.hasTarget?[n.target]:[]],logicalLength:n.values.length}}function j(e,t,n){if(n.length!==2||n.some(e=>!e?.trace||e.terminal.status!==`completed`))return`unavailable`;let r=n.map(e=>({code:e.terminal.returnValue,output:e.trace.steps.flatMap(e=>e.changes.filter(e=>e.op===`output`).map(e=>e.append)).join(``)}));if(r.every(e=>e.code===1&&e.output===`INVALID_INPUT
`))return`rejected`;if(r.some(e=>e.code!==0))return`different`;let i=r.map(n=>{if(!/^-?\d+(?: -?\d+)*\n$/.test(n.output))return null;let r=n.output.trim().split(` `).map(Number);return r.some(e=>!Number.isSafeInteger(e))?null:e.id===`example.cpp.two-sum`?r.length!==2||r[0]===r[1]||r.some(e=>e<0||e>=t)?null:[Math.min(...r),Math.max(...r)]:e.id===`example.cpp.move-zeroes`?r.length===t?r:null:r.length===1&&r[0]>=0&&r[0]<=t?r:null});return i.every(Boolean)&&JSON.stringify(i[0])===JSON.stringify(i[1])?`equal`:`different`}function M(e){return e&&typeof e==`object`&&(Object.values(e).forEach(M),Object.freeze(e)),e}var N=class{example;clients;models=[new d,new d];listeners=new Set;now;generation=0;schedule=0;timer=null;phase=`idle`;lanes=[];outcome=`unavailable`;cursor=0;playing=!1;rate=1;groupId=``;error=``;current;constructor(e,t={}){this.example=e,this.clients=t.clients??[new u,new u],this.now=t.now??(()=>performance.now()),this.lanes=D(e).map(e=>({spec:e,prepared:null,request:null,result:null,phase:`idle`,error:``})),this.current=this.snapshot()}snapshot(){return{phase:this.phase,outcome:this.outcome,cursor:this.cursor,length:Math.max(...this.models.map(e=>e.snapshot().length)),playing:this.playing,rate:this.rate,groupId:this.groupId,error:this.error,lanes:this.lanes.map((e,t)=>({...e,view:this.models[t].snapshot()}))}}getSnapshot=()=>this.current;subscribe=e=>(this.listeners.add(e),()=>{this.listeners.delete(e)});publish(){this.current=this.snapshot(),this.listeners.forEach(e=>e())}stop(){this.schedule++,this.timer!==null&&clearTimeout(this.timer),this.timer=null,this.playing=!1}invalidate=()=>{this.generation++,this.stop(),this.clients.forEach(e=>e.invalidate()),this.models.forEach(e=>e.invalidate()),this.lanes=this.lanes.map(({spec:e})=>({spec:e,prepared:null,request:null,result:null,phase:`idle`,error:``})),this.cursor=0,this.groupId=``,this.error=``,this.phase=`idle`,this.outcome=`unavailable`,this.publish()};prepare(e,t=!1){this.invalidate();try{let n=D(this.example),r=t?[...n].reverse():n;this.lanes=r.map(t=>({spec:t,prepared:M(A(this.example,t,structuredClone(e))),request:null,result:null,phase:`ready`,error:``})),this.phase=`ready`}catch(e){this.phase=`failed`,this.error=e instanceof Error?e.message:`E_INPUT_INVALID`}this.publish()}async execute(){if(![`ready`,`settled`,`cancelled`].includes(this.phase)||this.lanes.some(e=>!e.prepared))return;let e=this.now(),t=++this.generation;this.stop(),this.clients.forEach(e=>e.invalidate()),this.models.forEach(e=>e.invalidate()),this.groupId=crypto.randomUUID(),this.cursor=0,this.phase=`running`,this.outcome=`unavailable`,this.error=``,this.lanes=this.lanes.map(e=>({...e,result:null,request:null,phase:`ready`,error:``})),this.publish();for(let n=0;n<2;n++){if(t!==this.generation)return;let r=this.lanes[n],i=r.prepared,a=M(l(i.source,`cpp`,{kind:`integers`,values:[...i.input]}));r.request=a,r.phase=`running`,this.publish();try{if(t!==this.generation)return;if(this.now()-e>=1e3)throw Error(`E_DEADLINE`);let i=await this.clients[n].execute(a,{started:e});if(t!==this.generation)return;if(this.now()-e>=1e3||(this.models[n].accept(i),this.now()-e>=1e3))throw Error(`E_DEADLINE`);r.result=i,r.phase=`accepted`}catch(e){if(t!==this.generation)return;this.models[n].invalidate(),r.result=null,r.phase=`failed`,r.error=e instanceof Error&&/^E_[A-Z_]+$/.test(e.message)?e.message:`E_EXECUTION_FAILURE`}if(this.publish(),t!==this.generation)return;r.phase===`accepted`&&this.now()-e>=1e3&&(this.models[n].invalidate(),r.result=null,r.phase=`failed`,r.error=`E_DEADLINE`,this.publish())}if(t===this.generation){if(this.outcome=j(this.example,this.lanes[0].prepared.logicalLength,this.lanes.map(e=>e.result)),this.now()-e>=1e3&&this.lanes[1].phase===`accepted`&&(this.models[1].invalidate(),this.lanes[1].result=null,this.lanes[1].phase=`failed`,this.lanes[1].error=`E_DEADLINE`,this.outcome=`unavailable`),this.phase=`settled`,this.publish(),t!==this.generation)return;this.now()-e>=1e3&&this.lanes[1].phase===`accepted`&&(this.models[1].invalidate(),this.lanes[1].result=null,this.lanes[1].phase=`failed`,this.lanes[1].error=`E_DEADLINE`,this.outcome=`unavailable`,this.publish())}}cancel(){this.phase===`running`&&(this.generation++,this.stop(),this.clients.forEach(e=>e.invalidate()),this.lanes.forEach((e,t)=>{e.phase!==`accepted`&&(this.models[t].invalidate(),e.result=null,e.phase=`cancelled`)}),this.phase=`cancelled`,this.publish())}pause=()=>{this.stop(),this.publish()};move(e){this.cursor=e,this.models.forEach((t,n)=>{this.lanes[n].phase===`accepted`&&this.lanes[n].result?.trace&&t.seek(Math.min(e,t.snapshot().length))})}seek(e){![`settled`,`cancelled`].includes(this.phase)||!Number.isInteger(e)||e<0||e>this.current.length||(this.stop(),this.move(e),this.publish())}step(e){this.seek(Math.min(this.current.length,Math.max(0,this.cursor+e)))}setRate(e){if(![.25,.5,1,1.5,2,4].includes(e))return;let t=this.playing;this.stop(),this.rate=e,this.publish(),t&&this.play()}play=()=>{if(this.playing||![`settled`,`cancelled`].includes(this.phase)||!this.current.length||this.cursor>=this.current.length)return;this.playing=!0,this.publish();let e=this.generation,t=this.schedule,n=()=>{e===this.generation&&t===this.schedule&&this.playing&&(this.move(Math.min(this.current.length,this.cursor+1)),this.cursor>=this.current.length&&this.stop(),this.publish(),this.playing&&(this.timer=setTimeout(n,500/this.rate)))};this.timer=setTimeout(n,500/this.rate)}},P=n();function F({state:e,n:t}){return(0,P.jsx)(`div`,{className:`solution-arrays`,children:e.objects.filter(e=>e.alive&&[`values`,`order`,`scratch`].includes(e.name)&&e.typeName===`int`).map(e=>(0,P.jsxs)(`section`,{"data-testid":`solution-array`,"data-name":e.name,"aria-label":e.name+`数组`,children:[(0,P.jsxs)(`h3`,{children:[e.name,` · 前`,t,`项`]}),(0,P.jsx)(`ol`,{children:Array.from({length:t},(t,n)=>(0,P.jsxs)(`li`,{children:[(0,P.jsxs)(`small`,{children:[`[`,n,`]`]}),(0,P.jsx)(`strong`,{children:String(e.cells.find(e=>e.byteOffset===n*4)?.value??(e.zeroInitialized?0:`未初始化`))})]},n))})]},e.id))})}function I({spec:e}){let{service:t}=c(),n=a(),[r]=(0,x.useState)(()=>new N(e)),i=(0,x.useSyncExternalStore)(r.subscribe,r.getSnapshot),[l,u]=(0,x.useState)(e.defaults.values.join(` `)),[d,p]=(0,x.useState)(e.defaults.target===void 0?``:String(e.defaults.target)),[m,h]=(0,x.useState)(!1),[g,v]=(0,x.useState)(``),[S,C]=(0,x.useState)([`basic`,`basic`]),w=(0,x.useMemo)(()=>_(e,l,d),[e,l,d]);(0,x.useEffect)(()=>{let e=t.subscribeSessionInvalidation(r.invalidate),n=()=>{document.visibilityState!==`visible`&&r.pause()};return document.addEventListener(`visibilitychange`,n),()=>{e(),document.removeEventListener(`visibilitychange`,n),r.invalidate()}},[r,t]);let T=i.phase===`running`,E=!T&&i.length>0,k=(e,t,n=``)=>{r.invalidate(),u(e),p(t),v(n)},A=D(e),j={equal:`两份程序的最终答案一致。`,rejected:`两份程序均拒绝了不满足唯一解承诺的输入。`,different:`两份程序的终态结果不一致，请检查实际输出。`,unavailable:`尚无两份完整结果，暂不能判断答案是否一致。`}[i.outcome];return(0,P.jsxs)(`div`,{className:`advanced-course example-page solution-page`,"data-testid":`example-comparison`,"data-example":e.id,"data-phase":i.phase,"data-group-id":i.groupId,"data-cursor":i.cursor,"data-length":i.length,children:[(0,P.jsx)(s,{items:[{label:`进阶课程`,to:`/advanced`},{label:`经典例题`,to:`/advanced/examples`},{label:e.topic+` · 同题两解`}]}),(0,P.jsxs)(`header`,{className:`advanced-heading`,children:[(0,P.jsxs)(`h1`,{tabIndex:-1,children:[e.title.split(`：`)[0],`：同题两解`]}),(0,P.jsx)(`p`,{children:`同一原始输入，两份独立C++程序。比较答案、真实写入与不同边界处理。`})]}),(0,P.jsxs)(`form`,{className:`example-input`,onSubmit:e=>{e.preventDefault(),w.valid&&!T&&(r.prepare(w.input,m),r.execute())},children:[(0,P.jsxs)(`label`,{children:[`共同整数数组`,(0,P.jsx)(`input`,{"data-testid":`solutions-values`,value:l,maxLength:1024,"aria-invalid":!w.valid,"aria-describedby":`solutions-help`,onChange:e=>k(e.target.value,d)})]}),e.hasTarget&&(0,P.jsxs)(`label`,{children:[`共同目标`,(0,P.jsx)(`input`,{"data-testid":`solutions-target`,value:d,maxLength:16,inputMode:`numeric`,"aria-invalid":!w.valid,onChange:e=>k(l,e.target.value)})]}),(0,P.jsxs)(`div`,{className:`inline-actions`,children:[(0,P.jsx)(`button`,{className:`button button-primary`,type:`submit`,disabled:!w.valid||T,children:`运行两份C++方案`}),(0,P.jsx)(`button`,{className:`button`,type:`button`,onClick:()=>{r.invalidate(),h(!m)},children:`交换左右方案`}),T&&(0,P.jsx)(`button`,{className:`button`,type:`button`,onClick:()=>r.cancel(),children:`取消本组运行`})]}),(0,P.jsxs)(`label`,{children:[`例题`,(0,P.jsx)(`select`,{"aria-label":`对比例题`,value:e.id,onChange:e=>{r.invalidate(),n(`/advanced/examples/`+e.target.value+`/compare`)},children:y.map(e=>(0,P.jsx)(`option`,{value:e.id,children:e.title.split(`：`)[0]},e.id))})]}),(0,P.jsxs)(`label`,{children:[`共同边界样例`,(0,P.jsxs)(`select`,{"aria-label":`同题边界样例`,value:g,onChange:t=>{let n=O(e).find(e=>e.key===t.target.value);n&&k(n.values.join(` `),n.target===void 0?``:String(n.target),n.key)},children:[(0,P.jsx)(`option`,{value:``,children:`选择一组输入`}),O(e).map(e=>(0,P.jsxs)(`option`,{value:e.key,children:[e.key,` · `,e.values.join(`, `),e.target===void 0?``:` → ${e.target}`,e.expectedReturn?`（输入承诺反例）`:``]},e.key))]})]}),(0,P.jsx)(`p`,{id:`solutions-help`,role:w.valid?void 0:`alert`,children:w.valid?e.platformConstraints:w.issue})]}),(0,P.jsxs)(`section`,{className:`solution-controls`,"aria-label":`同题统一回放`,tabIndex:0,onKeyDown:e=>{e.target.closest(`button,input,select,textarea,a`)||e.ctrlKey||e.altKey||e.metaKey||(e.code===`Space`?(e.preventDefault(),i.playing?r.pause():r.play()):(e.key===`ArrowLeft`||e.key===`ArrowRight`)&&(e.preventDefault(),r.step(e.key===`ArrowLeft`?-1:1)))},children:[(0,P.jsx)(`h2`,{children:`统一回放`}),(0,P.jsx)(`p`,{role:`status`,"data-testid":`solutions-status`,children:T?`正在顺序执行并检查两份真实轨迹……`:i.phase===`cancelled`?`本组已取消；可回放此前已接收侧。`:i.phase===`failed`?`输入准备失败。`:i.phase===`settled`?`本组运行已结束，可从初态观察。`:`输入就绪后运行两份方案。`}),(0,P.jsxs)(`p`,{"data-testid":`solutions-outcome`,"data-outcome":i.outcome,children:[`终态核验：`,j]}),i.error&&(0,P.jsx)(`p`,{role:`alert`,children:i.error}),(0,P.jsxs)(`div`,{className:`inline-actions`,children:[(0,P.jsx)(`button`,{className:`button button-small`,disabled:!E,onClick:()=>r.seek(0),children:`回到初态`}),(0,P.jsx)(`button`,{className:`button button-small`,disabled:!E||i.cursor===0,onClick:()=>r.step(-1),children:`统一后退`}),(0,P.jsx)(`button`,{className:`button button-small`,disabled:!E||i.cursor===i.length,onClick:()=>i.playing?r.pause():r.play(),children:i.playing?`暂停对比`:`播放对比`}),(0,P.jsx)(`button`,{className:`button button-small`,disabled:!E||i.cursor===i.length,onClick:()=>r.step(1),children:`统一前进`}),(0,P.jsx)(`button`,{className:`button button-small`,disabled:!E,onClick:()=>r.seek(i.length),children:`查看两侧末步`}),(0,P.jsxs)(`label`,{children:[`速度`,` `,(0,P.jsx)(`select`,{"aria-label":`同题播放速度`,value:i.rate,onChange:e=>r.setRate(Number(e.target.value)),children:[.25,.5,1,1.5,2,4].map(e=>(0,P.jsxs)(`option`,{value:e,children:[e,`×`]},e))})]})]}),(0,P.jsxs)(`label`,{className:`custom-cursor`,children:[`统一步骤 `,i.cursor,` / `,i.length,(0,P.jsx)(`input`,{type:`range`,"aria-label":`同题统一步骤`,min:0,max:i.length||1,value:i.cursor,disabled:!E,onChange:e=>r.seek(Number(e.target.value))})]}),(0,P.jsx)(`p`,{className:`muted`,children:`两份运行共用1秒截止，顺序占用单执行槽，不自动重试。统一步号不代表相同算法阶段；短侧保持真实末态。播放速度与动画时长不代表算法效率。`})]}),(0,P.jsx)(`div`,{className:`solution-lanes`,children:i.lanes.map((t,n)=>{let r=D(e)[m?1-n:n],{view:i,result:a}=t,o=t.request?.source??t.prepared?.source;return(0,P.jsxs)(`section`,{className:`solution-lane`,"data-testid":`solution-lane-${n}`,"data-phase":t.phase,"data-cursor":i.cursor,"data-length":i.length,"data-run-id":i.identity?.runId??``,"data-solution":r.solutionRef.id,children:[(0,P.jsxs)(`header`,{children:[(0,P.jsxs)(`h2`,{children:[n===0?`左侧`:`右侧`,` · `,r.title]}),(0,P.jsx)(`p`,{children:r.strategy}),(0,P.jsx)(`p`,{children:r.time}),(0,P.jsx)(`p`,{children:r.space})]}),(0,P.jsx)(`p`,{"data-testid":`solution-lane-status`,children:t.phase===`accepted`?a?.trace?`${a.terminal.status} · ${i.cursor===i.length?`已到末尾，保持末态`:`轨迹可回放`}`:`没有轨迹 · ${a?.terminal.code}`:t.phase===`running`?`本侧正在真实执行`:t.phase===`failed`?`本侧未接收：${t.error}`:t.phase===`cancelled`?`本侧已取消`:`等待本组运行`}),t.prepared&&(0,P.jsxs)(`p`,{"data-testid":`solution-input`,children:[`输入副本：`,JSON.stringify(t.prepared.input)]}),(0,P.jsx)(`dl`,{className:`solution-counters`,"data-testid":`solution-counters`,children:[`comparisons`,`arrayWrites`,`scalarWrites`,`swaps`].map(e=>(0,P.jsxs)(`div`,{children:[(0,P.jsx)(`dt`,{children:{comparisons:`比较`,arrayWrites:`数组写入`,scalarWrites:`变量写入`,swaps:`交换标注`}[e]}),(0,P.jsx)(`dd`,{"data-counter":e,children:i.state?.counters[e]??`—`})]},e))}),(0,P.jsxs)(`label`,{children:[`观察视图`,` `,(0,P.jsxs)(`select`,{"aria-label":`本侧观察视图`,value:S[n],onChange:e=>C(S.map((t,r)=>r===n?e.target.value:t)),children:[(0,P.jsx)(`option`,{value:`basic`,children:`变量与数组`}),(0,P.jsx)(`option`,{value:`memory`,children:`内存`}),(0,P.jsx)(`option`,{value:`stack`,children:`调用栈`})]})]}),(0,P.jsx)(`div`,{className:`solution-observation`,"data-ui":!0,children:i.state&&a?(0,P.jsxs)(P.Fragment,{children:[(0,P.jsxs)(`p`,{children:[`本侧步骤 `,i.cursor,` / `,i.length,` · `,i.stepKind??`初态`]}),(0,P.jsx)(F,{state:i.state,n:t.prepared.logicalLength}),(0,P.jsx)(f,{state:i.state,result:a,mode:S[n]},i.identity?.runId)]}):(0,P.jsx)(`p`,{children:`运行后呈现该侧同一游标的数组、变量、输出、内存或栈。`})}),(0,P.jsxs)(`details`,{className:`solution-code`,children:[(0,P.jsx)(`summary`,{children:`本侧实际源码与高亮`}),o?(0,P.jsx)(b,{source:o,range:i.byteRange}):(0,P.jsx)(`p`,{children:`运行本组后展示该侧实际请求源码。`})]}),a&&i.cursor===i.length&&(0,P.jsxs)(`p`,{"data-testid":`solution-terminal`,children:[`终态：`,a.terminal.status,` · 返回值`,a.terminal.returnValue??`无`]})]},n)})}),(0,P.jsxs)(`section`,{className:`solution-reasoning`,children:[(0,P.jsx)(`h2`,{children:`复杂度与适用场景`}),(0,P.jsx)(`p`,{children:`当前计数来自真实步骤，包含输入、初始化、循环及同值写；交换标注未由引擎标记时保持真实0，不由前端推测。渐进复杂度按输入规模n推导，不能只凭本次计数判断所有输入。`}),(0,P.jsx)(`div`,{className:`custom-table-scroll`,children:(0,P.jsxs)(`table`,{children:[(0,P.jsx)(`thead`,{children:(0,P.jsxs)(`tr`,{children:[(0,P.jsx)(`th`,{children:`比较点`}),A.map(e=>(0,P.jsx)(`th`,{children:e.title},e.solutionRef.id))]})}),(0,P.jsx)(`tbody`,{children:[`time`,`space`,`derivation`,`suitable`,`cautions`].map(e=>(0,P.jsxs)(`tr`,{children:[(0,P.jsx)(`th`,{children:{time:`时间`,space:`额外空间`,derivation:`推导`,suitable:`适用场景`,cautions:`边界与取舍`}[e]}),A.map(t=>(0,P.jsx)(`td`,{children:t[e]},t.solutionRef.id))]},e))})]})})]}),(0,P.jsxs)(`p`,{children:[`来源：`,(0,P.jsxs)(`a`,{href:e.source.url,target:`_blank`,rel:`noreferrer noopener`,children:[`力扣 `,e.source.problemNumber,` · `,e.source.title]}),`。`,e.originalConstraints,` `,`平台采用原创讲解与代码，授权未确认；原题范围与本页有界演示分开。`]}),(0,P.jsxs)(`p`,{children:[`本页不保存输入或轨迹，不计题目通过或积分。`,(0,P.jsx)(o,{to:`/advanced/examples/${e.id}`,children:`查看原例题讲解、来源与基础复习`})]}),(0,P.jsxs)(`nav`,{className:`advanced-bottom`,"aria-label":`同题对比导航`,children:[(0,P.jsx)(o,{to:`/advanced/examples`,children:`返回经典例题`}),(0,P.jsx)(o,{to:`/advanced`,children:`返回进阶课程`})]})]})}function L(){let{exampleId:e}=r(),t=h(e);return t?(0,P.jsx)(I,{spec:t},t.id):(0,P.jsx)(i,{title:`找不到这个同题对比`,backTo:`/advanced/examples`,backLabel:`返回经典例题`})}export{L as default};