# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: case-set.spec.ts >> minimal case set uses genuine Rust, exact input and reversible playback: case.c.selection-sort
- Location: tests\browser\case-set.spec.ts:647:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 0
+ Received  + 1

@@ -2,10 +2,11 @@
    "achievements",
    "aliases",
    "appearance",
    "appearanceAssets",
    "avatar",
+   "customDrafts",
    "dailyFacts",
    "editHistory",
    "goals",
    "knowledgeMarks",
    "ledger",
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - button "进入专注模式" [ref=e68] [cursor=pointer]:
          - generic [ref=e71]: 专注
        - generic [ref=e72]: 本地学习
        - link "本地数据" [ref=e73] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e77] [cursor=pointer]
    - main [ref=e80]:
      - generic [ref=e81]:
        - navigation "当前位置" [ref=e82]:
          - list [ref=e83]:
            - listitem [ref=e84]:
              - link "算法与演示" [ref=e85] [cursor=pointer]:
                - /url: "#/cases"
            - listitem [ref=e86]:
              - generic [ref=e89]: 选择排序
        - generic [ref=e90]:
          - paragraph [ref=e91]: 算法案例 · 可视化工作区
          - heading "选择排序" [level=1] [ref=e92]
          - paragraph [ref=e93]: 寻找最小值，逐步整理数组。
        - generic [ref=e95]:
          - paragraph [ref=e97]: 尚无已保存的学习记录
          - generic [ref=e98]:
            - paragraph [ref=e99]: 已审核案例 · 独立观看
            - paragraph [ref=e100]: 内容版本 1.0.0 · 讲解与运行使用同一份已审核案例。 完整观看真实运行后，还需主动确认才记录观看奖励。
            - heading "案例讲解" [level=2] [ref=e101]
            - generic [ref=e102]:
              - heading "学习目标" [level=3] [ref=e103]
              - list [ref=e104]:
                - listitem [ref=e105]: 观察剩余区最小下标和非自交换
              - heading "讲解与示例" [level=3] [ref=e106]
              - paragraph [ref=e107]: 每轮先记住剩余区第一个下标，扫描发现严格更小的值才更新最小下标；最后仅在位置不同时交换。默认[7,-3,0,5,-3,2,9]成为[-3,-3,0,2,5,7,9]。同值保留首次最小下标，但远距离交换可能改变相等元素的相对次序，因此不承诺稳定。空数组只输出换行。
              - generic [ref=e108]:
                - heading "选择排序参考 · 参考源码" [level=4] [ref=e109]
                - paragraph [ref=e110]: 这里是讲解用的参考源码；本次是否运行及实际代码，以执行区域为准。
                - generic "选择排序参考参考源码" [ref=e111]: "#include <stdio.h> int main(void) { int n = 7; int values[7] = {7, -3, 0, 5, -3, 2, 9}; for (int i = 0; i < n - 1; i = i + 1) { int minIndex = i; for (int j = i + 1; j < n; j = j + 1) { if (values[j] < values[minIndex]) { minIndex = j; } } if (minIndex != i) { int temp = values[i]; values[i] = values[minIndex]; values[minIndex] = temp; } } for (int k = 0; k < n; k = k + 1) { if (k > 0) { printf(\" \"); } printf(\"%d\", values[k]); } printf(\"\\n\"); return 0; }"
              - heading "常见错误" [level=3] [ref=e112]
              - list [ref=e113]:
                - listitem [ref=e114]: 宣称稳定排序
                - listitem [ref=e115]: 自交换计为真实交换
              - heading "范围与边界" [level=3] [ref=e116]
              - list [ref=e117]:
                - listitem [ref=e118]: 空、单项、已序、逆序、重复、负数；n最多30
                - listitem [ref=e119]: 输出规范与冒泡相同
              - paragraph [ref=e120]: 样例来源：content/c/p0/README.md · case.c.selection-sort；项目原创；沿用08.4已验证程序
          - generic [ref=e121]:
            - heading "执行模块连接" [level=2] [ref=e122]
            - status [ref=e123]: 检查浏览器能否加载执行模块。构建检查不执行 C；案例页可运行内容样例。
            - button "检查执行模块" [ref=e125] [cursor=pointer]
        - generic [ref=e126]:
          - heading "运行内容样例" [level=2] [ref=e127]
          - paragraph [ref=e128]: 逐步看完真实运行后，主动确认可获得案例首次观看奖励。浏览、运行和重播本身不会发放奖励。
          - paragraph [ref=e129]: 程序由此浏览器中的 Rust 解释器执行。代码、输入和轨迹不会上传到执行服务器；网页和课程资源加载需要网络。
          - status [ref=e131]:
            - generic [ref=e135]:
              - heading "本地档案已读取" [level=2] [ref=e136]
              - paragraph [ref=e137]: 正在显示当前浏览器中已保存的记录与设置。
          - region "案例输入设置" [ref=e138]:
            - heading "案例输入" [level=2] [ref=e139]
            - paragraph [ref=e140]: 修改输入会立即清除旧源码与运行结果。应用输入后，查看 Rust 生成的完整源码再运行。
            - generic [ref=e142]:
              - generic [ref=e143]: 数组 values
              - textbox "数组 values" [ref=e144]: 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1
              - paragraph [ref=e145]: 整数范围 -999～999；长度 0～30。用逗号或空格分隔；空数组请写 []，空白不是有效输入。
              - button "使用空数组" [ref=e146] [cursor=pointer]
            - paragraph [ref=e147]: 数组的逻辑长度 n 根据实际项数生成，无需重复填写。
            - generic [ref=e148]:
              - generic [ref=e149]:
                - generic [ref=e150]: 随机种子
                - textbox "随机种子" [ref=e151]: 73cf63db-8f5e-4900-a0cc-1e380c5898b3
                - paragraph [ref=e152]: 1～128 个 Unicode 字符（组合表情可能计为多个字符），原样区分大小写和空格。同一版本、输入约束、种子与长度可复现同一组数据；只保留在本页内存。
              - generic [ref=e153]:
                - generic [ref=e154]: 随机数组长度
                - textbox "随机数组长度" [ref=e155]: "7"
                - paragraph [ref=e156]: 范围 0～30；先选择长度，再生成。
            - generic [ref=e157]:
              - button "生成随机数据" [ref=e158] [cursor=pointer]
              - button "按种子复现" [ref=e159] [cursor=pointer]
              - button "恢复示例输入" [ref=e160] [cursor=pointer]
              - button "应用输入并准备" [ref=e161] [cursor=pointer]
          - generic [ref=e162]:
            - paragraph [ref=e163]:
              - text: 本次输入：
              - code [ref=e164]: "{\"values\":[30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1]}"
            - paragraph [ref=e165]: 手动或示例输入
          - generic [ref=e166]:
            - button "运行示例" [ref=e167] [cursor=pointer]
            - button "取消运行" [disabled] [ref=e168]
          - generic "执行播放工作区" [ref=e169]:
            - generic [ref=e170]:
              - generic [ref=e171]:
                - generic [ref=e172]: 拖动中间分隔条调整宽度
                - button "恢复默认比例" [disabled] [ref=e173] [cursor=pointer]
              - generic [ref=e174]:
                - region "代码" [ref=e175]:
                  - generic [ref=e176]:
                    - generic [ref=e177]: 代码
                    - button "展开代码" [ref=e178] [cursor=pointer]:
                      - generic [ref=e181]: 展开
                  - region "执行代码区域" [ref=e183]:
                    - generic [ref=e184]:
                      - heading "本次执行的 C 代码" [level=3] [ref=e185]
                      - generic [ref=e186]: 只读
                    - paragraph [ref=e187]: 初始状态，尚未完成源码步骤。
                    - generic [ref=e188]:
                      - generic [aria-hidden]:
                        - code: "#include <stdio.h> int main(void) { int n = 30; int values[30] = {30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1}; for (int i = 0; i < n - 1; i = i + 1) { int minIndex = i; for (int j = i + 1; j < n; j = j + 1) { if (values[j] < values[minIndex]) { minIndex = j; } } if (minIndex != i) { int temp = values[i]; values[i] = values[minIndex]; values[minIndex] = temp; } } for (int k = 0; k < n; k = k + 1) { if (k > 0) { printf(\" \"); } printf(\"%d\", values[k]); } printf(\"\\n\"); return 0; }"
                      - textbox "当前执行的 C 代码" [ref=e189]: "#include <stdio.h> int main(void) { int n = 30; int values[30] = {30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1}; for (int i = 0; i < n - 1; i = i + 1) { int minIndex = i; for (int j = i + 1; j < n; j = j + 1) { if (values[j] < values[minIndex]) { minIndex = j; } } if (minIndex != i) { int temp = values[i]; values[i] = values[minIndex]; values[minIndex] = temp; } } for (int k = 0; k < n; k = k + 1) { if (k > 0) { printf(\" \"); } printf(\"%d\", values[k]); } printf(\"\\n\"); return 0; }"
                - separator "调整面板宽度" [ref=e190]
                - region "运行画面" [ref=e192]:
                  - generic [ref=e193]:
                    - generic [ref=e194]: 运行画面
                    - button "展开运行画面" [ref=e195] [cursor=pointer]:
                      - generic [ref=e198]: 展开
                  - region "运行结果" [ref=e200]:
                    - heading "当前步骤画面" [level=3] [ref=e202]
                    - generic "播放控制" [ref=e203]:
                      - generic [ref=e204]:
                        - button "后退" [disabled] [ref=e205]
                        - button "播放" [ref=e206] [cursor=pointer]
                        - button "前进" [ref=e207] [cursor=pointer]
                        - button "重播" [ref=e208] [cursor=pointer]
                      - generic [ref=e209]:
                        - text: 速度
                        - combobox "播放速度" [ref=e210]:
                          - option "0.25×"
                          - option "0.5×"
                          - option "1×" [selected]
                          - option "1.5×"
                          - option "2×"
                          - option "4×"
                      - generic [ref=e211]:
                        - text: 显示
                        - combobox "步骤显示" [ref=e212]:
                          - option "关键步骤" [selected]
                          - option "全部步骤"
                      - generic [ref=e213]:
                        - generic [ref=e214]: 关键步骤 0 / 1412
                        - status [ref=e215]: 已回到初始状态
                      - paragraph [ref=e216]: 聚焦播放工作区后，空格播放或暂停，左右方向键单步查看。重播从初始状态开始播放。
                    - generic [ref=e217]:
                      - paragraph [ref=e218]: 初始状态：尚未执行任何步骤
                      - generic [ref=e219]:
                        - generic [ref=e220]:
                          - text: 比较
                          - strong [ref=e221]: "0"
                        - generic [ref=e222]:
                          - text: 变量写入
                          - strong [ref=e223]: "0"
                        - generic [ref=e224]:
                          - text: 数组写入
                          - strong [ref=e225]: "0"
                        - generic [ref=e226]:
                          - text: 交换
                          - strong [ref=e227]: "0"
                      - region "当前变量" [ref=e228]:
                        - heading "变量" [level=4] [ref=e229]
                        - paragraph [ref=e230]: 当前没有存活变量。
                      - region "当前数组" [ref=e231]:
                        - heading "数组" [level=4] [ref=e232]
                        - paragraph [ref=e233]: 当前没有存活数组。
                      - group [ref=e234]:
                        - generic "查看本步读写与比较" [ref=e235] [cursor=pointer]
                      - region "当前步骤输出" [ref=e236]:
                        - heading "截至当前步骤的输出" [level=4] [ref=e237]
                        - generic [ref=e238]: （无输出）
                    - region "当前快照导出" [ref=e239]:
                      - generic [ref=e240]:
                        - heading "保存当前快照" [level=4] [ref=e241]
                        - generic [ref=e242]: 仅下载到你的设备
                      - paragraph [ref=e243]: 文件包含当前源码、输入和完整运行状态，请自行管理。PNG也附带同一状态数据，分享前请确认。
                      - generic [ref=e244]:
                        - button "下载状态文件（JSON）" [ref=e245] [cursor=pointer]
                        - button "下载快照图片（PNG）" [ref=e246] [cursor=pointer]
                      - group [ref=e247]:
                        - generic "文件包含范围" [ref=e248] [cursor=pointer]
                    - region "步骤讲解与挑战" [ref=e249]:
                      - generic [ref=e250]:
                        - heading "步骤学习" [level=4] [ref=e251]
                        - group "学习模式" [ref=e252]:
                          - button "教学讲解" [pressed] [ref=e253] [cursor=pointer]
                          - button "预测挑战" [ref=e254] [cursor=pointer]
                      - generic [ref=e255]:
                        - paragraph [ref=e256]:
                          - strong [ref=e257]: 当前为执行前的初始状态
                        - paragraph [ref=e258]: 下一步（关键步骤）：写入声明时的初值 · 第 3 行，第 5 列至第 3 行，第 16 列（末端不含）。
                    - generic [ref=e259]:
                      - heading "本次完整运行结果" [level=4] [ref=e260]
                      - status [ref=e261]: 程序正常结束
                      - paragraph [ref=e262]: 有效轨迹：3572 步
                      - paragraph [ref=e263]: 返回值：0
                      - generic "程序完整输出" [ref=e264]: 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
                      - paragraph [ref=e265]: 此处是完整运行结果；上方画面对应当前播放步骤。
          - region [ref=e266]:
            - heading "确认本次观看" [level=3] [ref=e267]
            - paragraph [ref=e268]: 已查看 0 / 1412 个关键步骤。请从初始状态逐步前进或播放至结束。
            - paragraph [ref=e269]: 请让当前变量或数组画面保持可见。首次确认获得 5 分。按顺序看完关键步骤即可确认；全部步骤可查看中间细节。暂停和后退保留覆盖；更换输入、重新运行或刷新需重新观看。
            - button "确认已观看" [disabled] [ref=e270]
        - generic [ref=e271]:
          - link "返回案例目录" [ref=e272] [cursor=pointer]:
            - /url: "#/cases"
          - link "关联小节：综合练习" [ref=e273] [cursor=pointer]:
            - /url: "#/lessons/lesson.c.array-sum"
```

# Test source

```ts
  463 |     forwardCursors.push(frame.cursor);
  464 |     // The return destroys locals; inspect the final live array immediately before it.
  465 |     if (sample.finalArray && cursor === length - 1) {
  466 |       const array = frame.arrays.find((array) => array.name === 'values');
  467 |       expect(array).toBeDefined();
  468 |       finalArrayObserved = array!.cells.map((cell) => Number(cell.value));
  469 |       expect(finalArrayObserved).toEqual(sample.finalArray);
  470 |     }
  471 |     if (cursor === length - 1) {
  472 |       const target = join(captureRoot, testInfo.project.name, sample.key);
  473 |       await mkdir(target, { recursive: true });
  474 |       await page
  475 |         .getByTestId('player-workspace')
  476 |         .screenshot({ path: join(target, 'screenshot.png') });
  477 |     }
  478 |   }
  479 |   await expect(button(page, '前进')).toBeDisabled();
  480 |   for (let cursor = length - 1; cursor >= 0; cursor--) {
  481 |     await page.keyboard.press('ArrowLeft');
  482 |     const frame = await readFrame(page);
  483 |     assertFrame(run, frame, cursor);
  484 |     reverseCursors.push(frame.cursor);
  485 |   }
  486 |   // Status reflects manual pause, while every restored program field is identical.
  487 |   expect({ ...(await readFrame(page)), status: run.initialView.status }).toEqual(run.initialView);
  488 |   return {
  489 |     forwardCursors,
  490 |     reverseCursors,
  491 |     finalArrayObserved,
  492 |     allStatesChecked: true,
  493 |     sourceRangesChecked: true,
  494 |   };
  495 | }
  496 | 
  497 | async function playAtAllRates(page: Page, run: Run) {
  498 |   // All genuine executions for this case finished first. Never fake execution's deadline clock.
  499 |   const time = Date.now();
  500 |   await page.clock.install({ time });
  501 |   await page.clock.pauseAt(time + 1000);
  502 |   const rates = [];
  503 |   const length = run.result.trace!.steps.length;
  504 |   for (const rate of [0.25, 0.5, 1, 1.5, 2, 4]) {
  505 |     await controls(page)
  506 |       .getByRole('combobox', { name: '播放速度', exact: true })
  507 |       .selectOption(String(rate));
  508 |     await button(page, '重播').click();
  509 |     const initial = await readFrame(page);
  510 |     assertFrame(run, initial, 0);
  511 |     expect(initial.status).toBe('playing');
  512 |     await page.evaluate(() => {
  513 |       const audit = window.__caseSetAudit;
  514 |       audit.observer?.disconnect();
  515 |       audit.frames = [audit.read()];
  516 |       audit.observer = new MutationObserver(() => {
  517 |         const frame = audit.read();
  518 |         if (frame.cursor !== audit.frames.at(-1)?.cursor) audit.frames.push(frame);
  519 |       });
  520 |       audit.observer.observe(document.querySelector('[data-testid="player-workspace"]')!, {
  521 |         subtree: true,
  522 |         attributes: true,
  523 |         childList: true,
  524 |         characterData: true,
  525 |       });
  526 |     });
  527 |     const periodMs = Math.ceil(500 / rate);
  528 |     await page.clock.runFor(periodMs * length + 20);
  529 |     const frames = await page.evaluate(() => {
  530 |       window.__caseSetAudit.observer?.disconnect();
  531 |       return window.__caseSetAudit.frames;
  532 |     });
  533 |     expect(frames.map((frame) => frame.cursor)).toEqual(
  534 |       Array.from({ length: length + 1 }, (_, cursor) => cursor),
  535 |     );
  536 |     for (const frame of frames) assertFrame(run, frame, frame.cursor);
  537 |     const end = await readFrame(page);
  538 |     expect(end.status).toBe('ended');
  539 |     expect(end.output).toBe(run.finalOutput);
  540 |     rates.push({
  541 |       rate,
  542 |       periodMs,
  543 |       cursors: frames.map((frame) => frame.cursor),
  544 |       endCursor: end.cursor,
  545 |       endStatus: end.status,
  546 |       stdout: end.output,
  547 |       allStatesChecked: true,
  548 |     });
  549 |   }
  550 |   return rates;
  551 | }
  552 | 
  553 | async function saveCapture(
  554 |   page: Page,
  555 |   run: Run,
  556 |   sample: CaseSetSample,
  557 |   testInfo: TestInfo,
  558 |   before: Awaited<ReturnType<typeof storageSnapshot>>,
  559 |   walk: Awaited<ReturnType<typeof walkAndRecover>> | null,
  560 |   rates: Awaited<ReturnType<typeof playAtAllRates>>,
  561 | ) {
  562 |   const after = await storageSnapshot(page);
> 563 |   expect(Object.keys(before.stores).sort()).toEqual([
      |                                             ^ Error: expect(received).toEqual(expected) // deep equality
  564 |     'achievements',
  565 |     'aliases',
  566 |     'appearance',
  567 |     'appearanceAssets',
  568 |     'avatar',
  569 |     'dailyFacts',
  570 |     'editHistory',
  571 |     'goals',
  572 |     'knowledgeMarks',
  573 |     'ledger',
  574 |     'meta',
  575 |     'progress',
  576 |     'receipts',
  577 |     'reviewCards',
  578 |     'settings',
  579 |   ]);
  580 |   expect(after).toEqual(before);
  581 |   const requestBytes = Buffer.from(run.worker.requestBytes!);
  582 |   const resultBytes = Buffer.from(run.worker.responseBytes!);
  583 |   const displayedSource = await source(page).inputValue();
  584 |   const values = JSON.parse(
  585 |     (await page.getByTestId('execution-input').locator('code').first().textContent())!,
  586 |   ) as InputValues;
  587 |   const steps = Number(
  588 |     (await page.getByTestId('execution-steps').textContent())?.match(/有效轨迹：(\d+)\s*步/u)?.[1],
  589 |   );
  590 |   expect(values).toEqual(sample.values);
  591 |   expect(steps).toBe(run.result.trace!.steps.length);
  592 |   const ui = {
  593 |     captureVersion: '08.4-browser-capture@1',
  594 |     evidenceLevel: 'production-ui-real-worker',
  595 |     key: sample.key,
  596 |     caseId: sample.caseId,
  597 |     project: testInfo.project.name,
  598 |     browserVersion: page.context().browser()?.version(),
  599 |     route: new URL(page.url()).hash,
  600 |     displayedSource,
  601 |     readOnly: await source(page).evaluate((element) => (element as HTMLTextAreaElement).readOnly),
  602 |     values,
  603 |     stdout: await page.getByTestId('execution-output').textContent(),
  604 |     terminal: await panel(page).getAttribute('data-state'),
  605 |     steps,
  606 |     identity: run.request.identity,
  607 |     sourceKind: 'public-content-original',
  608 |     initialCursor: run.initialView.cursor,
  609 |     initialView: run.initialView,
  610 |     walk,
  611 |     rates,
  612 |     replay: walk ? { cycles: rates.length, initialRestored: true, noNewExecution: true } : null,
  613 |     storage: {
  614 |       storeNames: Object.keys(before.stores),
  615 |       beforeSha256: sha256(JSON.stringify(before)),
  616 |       afterSha256: sha256(JSON.stringify(after)),
  617 |       unchanged: true,
  618 |       scope: 'native-fifteen-stores+localStorage+sessionStorage',
  619 |     },
  620 |     worker: {
  621 |       kind: run.worker.kind,
  622 |       moduleSeen: run.worker.moduleSeen,
  623 |       responseOk: run.worker.responseOk,
  624 |       terminated: run.worker.terminated,
  625 |       operationId: run.worker.operationId,
  626 |       responseOperationId: run.worker.responseOperationId,
  627 |       url: run.worker.url,
  628 |     },
  629 |     requestByteLength: requestBytes.length,
  630 |     resultByteLength: resultBytes.length,
  631 |     requestSha256: sha256(requestBytes),
  632 |     resultSha256: sha256(resultBytes),
  633 |     catalogSha256: sha256(run.worker.catalogJson!),
  634 |     sourceSha256: sha256(displayedSource),
  635 |   };
  636 |   const target = join(captureRoot, testInfo.project.name, sample.key);
  637 |   await mkdir(target, { recursive: true });
  638 |   await writeFile(join(target, 'request.json'), requestBytes);
  639 |   await writeFile(join(target, 'result.json'), resultBytes);
  640 |   await writeFile(join(target, 'catalog.json'), run.worker.catalogJson!);
  641 |   await writeFile(join(target, 'source.c'), displayedSource);
  642 |   await writeFile(join(target, 'ui.json'), JSON.stringify(ui, null, 2) + '\n');
  643 |   await testInfo.attach(sample.key, { body: JSON.stringify(ui), contentType: 'application/json' });
  644 | }
  645 | 
  646 | for (const caseId of caseSetIds) {
  647 |   test(`minimal case set uses genuine Rust, exact input and reversible playback: ${caseId}`, async ({
  648 |     page,
  649 |   }, testInfo) => {
  650 |     test.setTimeout(120_000);
  651 |     await observeCaseSetExecution(page);
  652 |     await observeViews(page);
  653 |     await openCase(page, caseId);
  654 |     const before = await storageSnapshot(page);
  655 |     const samples = caseSetSamples
  656 |       .filter((sample) => sample.caseId === caseId)
  657 |       .toSorted((left, right) => {
  658 |         const priority = (sample: CaseSetSample) =>
  659 |           sample.key.endsWith('-maximum') ? -1 : sample.walk ? 1 : 0;
  660 |         return priority(left) - priority(right);
  661 |       });
  662 |     expect(samples.filter((sample) => sample.walk)).toHaveLength(1);
  663 |     let executeCount = 0;
```