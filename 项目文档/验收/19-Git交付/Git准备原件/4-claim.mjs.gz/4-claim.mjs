import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
for(const p of ['README.md','项目守则.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md']){
 let s=readFileSync(p,'utf8');assert.ok(!s.includes('第19当前范围Git领取（2026-11-01）'));const prefix=p.includes('/')?'./':'./项目文档/';const text=`第19当前范围Git领取（2026-11-01）：协调已实核19.5与第19调整范围质量/交接，仅派发19-Git-20261101-send1。按§8.1选择性核归属、暂存blob及全部待推链，排除17外属，作者/提交者仅本仓库Getaway-Wuji，备注“完成19部分”；起点main/HEAD/origin123eccf713cafe9a42453017da49e4b2461ead32、空暂存0/0，实际推送与CI结果另据记录，不提前称成功。[覆盖精度补充](${prefix}交付/19-Git交付范围与覆盖精度补充.md)明确30组460域全部独立预期，表达式/循环20组另用C解法，条件10组用referenceSource及独立预期；原51QA/九快照/最终复核及原说明保持。本次第19范围5/5、当前原84/88/主84/98/P2 15/19，与原全量3/5、82/88/82/98/P2 13/19分列；真实AI后置未验、官方0次，不挡本次交付或后续20。见[Git交接](${prefix}交接/19-Git交付-交接.md)。本轮不创建或进入20/21，不索取Key、不补真实AI、不重试旧进程切换；第20当前范围交付后停止/不进入21要求保持。`;
 const blank=/\r?\n\r?\n/.exec(s);assert.ok(blank);const at=blank.index+blank[0].length;writeFileSync(p,s.slice(0,at)+text+blank[0]+s.slice(at));
}
console.log('Git-only claim and precise coverage supplement recorded.');
