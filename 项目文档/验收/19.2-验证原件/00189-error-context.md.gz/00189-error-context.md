# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: generated-practice.spec.ts >> 19.2 formal empty evidence and whole keyed DB stay unchanged by transient practice
- Location: tests\browser\generated-practice.spec.ts:262:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByTestId('learning-save-status')
Expected: "ready"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" getByTestId('learning-save-status') with timeout 5000ms
  - waiting for getByTestId('learning-save-status')

```

```yaml
- link "跳到主要内容":
  - /url: "#main-content"
- complementary:
  - button "收起侧栏" [expanded]
  - link "编程可视化教学平台 · 学习首页":
    - /url: "#/"
    - text: "{ } 一步一懂 编程可视化教学平台"
  - paragraph: 从代码，到理解。
  - navigation "主导航":
    - link "学习首页":
      - /url: "#/"
    - link "C 语言课程":
      - /url: "#/courses"
    - link "进阶课程":
      - /url: "#/advanced"
    - link "算法与演示":
      - /url: "#/cases"
    - link "C 代码工作台":
      - /url: "#/custom-code"
    - link "编译流程":
      - /url: "#/compilation"
    - link "错题与陌生点":
      - /url: "#/notebook"
    - link "今日复习":
      - /url: "#/reviews"
    - link "学习成就":
      - /url: "#/achievements"
    - link "本地设置":
      - /url: "#/settings"
  - strong: 按自己的节奏学习
  - paragraph: 学习记录将保存在当前浏览器，不跨设备同步。
  - link "了解本地数据":
    - /url: "#/settings?panel=data"
- banner:
  - text: C 语言 · 从零开始 本地学习
  - link "本地数据":
    - /url: "#/settings?panel=data"
  - button "切换为深色"
- main:
  - paragraph: 规则生成 · C 基础
  - heading "换一道，再练一次" [level=1]
  - paragraph: 选择知识与难度，用固定种子得到一道可复现的题。参考解和你的提交都由浏览器内的 Rust 解释器真实执行。
  - paragraph: 临时加练 · 不计分，不改变课程进度或薄弱点记录 · 草稿与结果刷新后丢弃。保留种子可重新生成同一道题。
  - region "本地复习建议":
    - paragraph: 暂无待复习的本地依据，可从表达式基础题开始；这不代表已掌握其他知识。
    - link "核对学习依据 →":
      - /url: "#/weaknesses"
    - link "复习队列 →":
      - /url: "#/reviews"
    - link "原课程：语句顺序与当前值 →":
      - /url: "#/lessons/lesson.c.statement-order"
  - region "01 / 选一道题":
    - heading "01 / 选一道题" [level=2]
    - text: 3类题型 · 各2档难度 知识
    - combobox "知识":
      - option "表达式" [selected]
      - option "变量"
      - option "输出"
      - option "输入"
      - option "条件判断"
      - option "循环"
    - text: 难度
    - combobox "难度":
      - option "1 · 基础" [selected]
      - option "2 · 变化"
    - text: 种子
    - textbox "种子": "42"
    - button "生成题目"
    - button "清空本次加练"
    - status: 生成后显示题目、输入范围与起始代码。
```

# Test source

```ts
  1   | import { readFileSync } from 'node:fs';
  2   | import { mkdir, writeFile } from 'node:fs/promises';
  3   | import { gzipSync } from 'node:zlib';
  4   | import { expect, test, type Page } from '@playwright/test';
  5   | import type { ContentPackage } from '../../web/src/content/types';
  6   | import type { StorageSnapshot } from '../../web/src/storage/model';
  7   | import { initSync, prepare_input } from '../../web/src/generated/c_viz_wasm';
  8   | import { observeCaseSetExecution, observedCaseSetExecute } from './case-set-observation';
  9   | import { p05CourseRelease } from '../../web/src/content/p05-course-release.generated';
  10  | 
  11  | const course = JSON.parse(
  12  |   readFileSync('content/c/p05/course-1.0.0.json', 'utf8'),
  13  | ) as ContentPackage;
  14  | const solutions = JSON.parse(
  15  |   readFileSync('tests/fixtures/p05-reference-solutions.json', 'utf8'),
  16  | ) as { solutions: { exerciseRef: { id: string }; source: string }[] };
  17  | const folder = `.artifacts/15.2/browser/${process.env.TASK_EVIDENCE_LABEL ?? 'local'}`;
  18  | const panel = (page: Page) => page.getByTestId('practice-execution');
  19  | const code = (page: Page) => page.getByRole('textbox', { name: '编辑 C 代码', exact: true });
  20  | const ready = (page: Page) =>
> 21  |   expect(page.getByTestId('learning-save-status')).toHaveAttribute(
      |                                                    ^ Error: expect(locator).toHaveAttribute(expected) failed
  22  |     'data-save-status',
  23  |     p05CourseRelease.registered ? 'ready' : /^(ready|unsaved)$/,
  24  |   );
  25  | async function archive(page: Page): Promise<StorageSnapshot> {
  26  |   return page.evaluate(async () => {
  27  |     const db = await new Promise<IDBDatabase>((resolve, reject) => {
  28  |       const req = indexedDB.open('c-viz-learning');
  29  |       req.onsuccess = () => resolve(req.result);
  30  |       req.onerror = () => reject(req.error);
  31  |     });
  32  |     try {
  33  |       const names = Array.from(db.objectStoreNames);
  34  |       const tx = db.transaction(names, 'readonly');
  35  |       const done = new Promise<void>((resolve, reject) => {
  36  |         tx.oncomplete = () => resolve();
  37  |         tx.onabort = () => reject(tx.error);
  38  |       });
  39  |       const entries = await Promise.all(
  40  |         names.map(async (name) => [
  41  |           name,
  42  |           await new Promise<unknown>((resolve, reject) => {
  43  |             const store = tx.objectStore(name);
  44  |             const req = ['meta', 'settings', 'avatar', 'appearance'].includes(name)
  45  |               ? store.get('current')
  46  |               : store.getAll();
  47  |             req.onsuccess = () => resolve(req.result);
  48  |             req.onerror = () => reject(req.error);
  49  |           }),
  50  |         ]),
  51  |       );
  52  |       await done;
  53  |       return Object.fromEntries(entries) as unknown as StorageSnapshot;
  54  |     } finally {
  55  |       db.close();
  56  |     }
  57  |   });
  58  | }
  59  | async function confirm(page: Page, id: string) {
  60  |   await page.goto(`/#/lessons/${id}`);
  61  |   await expect(page.getByTestId('lesson-reading')).toHaveAttribute('data-state', 'ready');
  62  |   await ready(page);
  63  |   const start = page.getByRole('button', { name: '开始本节学习', exact: true });
  64  |   if (await start.isEnabled()) {
  65  |     await start.click();
  66  |     await ready(page);
  67  |   }
  68  |   await page.getByRole('button', { name: /^(确认已学习|确认今日复习)$/ }).click();
  69  |   await ready(page);
  70  |   await expect(page.getByTestId('lesson-confirmation-check')).toHaveAttribute('data-saved', 'yes');
  71  | }
  72  | async function openAnswer(page: Page, exerciseId: string) {
  73  |   const subject = course.exercises.find((item) => item.id === exerciseId)!;
  74  |   const program = course.programs.find((item) => item.id === subject.programRef.id)!;
  75  |   const input = Object.fromEntries(
  76  |     Object.entries(subject.tests[0].input).sort(([a], [b]) => a.localeCompare(b)),
  77  |   );
  78  |   const source = JSON.parse(
  79  |     new TextDecoder().decode(
  80  |       prepare_input(
  81  |         JSON.stringify({
  82  |           packageRef: { id: course.packageId, version: course.packageVersion },
  83  |           subject,
  84  |           program: {
  85  |             ...program,
  86  |             sourceExample: solutions.solutions.find((item) => item.exerciseRef.id === exerciseId)!
  87  |               .source,
  88  |           },
  89  |           inputSpec: course.inputSpecs.find((item) => item.id === program.inputRef.id)!,
  90  |           judgeProfile: course.judgeProfiles.find((item) => item.id === subject.judgeRef.id)!,
  91  |         }),
  92  |         new TextEncoder().encode(JSON.stringify(input)),
  93  |         1000,
  94  |       ),
  95  |     ),
  96  |   ) as { source: { text: string } };
  97  |   await page.goto(`/#/practice/${exerciseId}`);
  98  |   await expect(panel(page)).toHaveAttribute('data-state', 'ready');
  99  |   await ready(page);
  100 |   await expect.poll(async () => (await archive(page)).settings.goalTemplate).not.toBeNull();
  101 |   // The normal auto preference can reveal code between checking and clicking
  102 |   // its expander. Select the public code-only view before editing instead.
  103 |   await page
  104 |     .getByTestId('block-workspace-preference')
  105 |     .getByRole('combobox', { name: '积木显示', exact: true })
  106 |     .selectOption('hide');
  107 |   const preference = page.getByTestId('block-workspace-preference');
  108 |   const preferenceStatus = page.getByTestId('block-preference-save-status');
  109 |   await expect(preferenceStatus).toHaveAttribute('data-save-state', /^(saved|temporary)$/);
  110 |   if ((await preferenceStatus.getAttribute('data-save-state')) === 'temporary') {
  111 |     await expect(preferenceStatus).toContainText('其他页面已更新档案');
  112 |     test.info().annotations.push({
  113 |       type: 'setup-recovery',
  114 |       description:
  115 |         'Display preference CAS conflicted with source reconciliation; explicitly re-read and save once through the public control.',
  116 |     });
  117 |     await preference.getByRole('button', { name: '重新读取并保存选择', exact: true }).click();
  118 |     await expect(preferenceStatus).toHaveAttribute('data-save-state', 'saved');
  119 |   }
  120 |   await expect(page.getByTestId('practice-editor-layout')).toHaveAttribute(
  121 |     'data-blocks-visible',
```