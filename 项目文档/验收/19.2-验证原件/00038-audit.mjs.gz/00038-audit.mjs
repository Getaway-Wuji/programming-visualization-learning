import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const read=p=>readFileSync(p),json=p=>JSON.parse(read(p).toString().replace(/^\uFEFF/,'')),sha=b=>createHash('sha256').update(b).digest('hex');
const base=json('.artifacts/19.2/baseline.json'),changed=[],missing=[];
for(const e of base.files){if(!existsSync(e.path)){missing.push(e.path);continue;}const hash=sha(read(e.path));if(hash!==e.sha256)changed.push({path:e.path,before:e.sha256,after:hash});}
assert.deepEqual(missing,[]);
const allowed=['Cargo.toml','Cargo.lock','README.md','scripts/build.mjs','scripts/build-p05-course.mjs','scripts/restore-release-evidence.mjs','web/src/App.tsx','web/src/content/p05-course-release.generated.ts','web/src/weaknesses/WeaknessPage.tsx','项目守则.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md'];
allowed.push('web/public/content/course/manifest.json');
for(const e of changed)assert.ok(allowed.includes(e.path),'Unexpected owner change: '+e.path);
const owner=base.files.filter(e=>/2026-10-31-(?:CI|GitHub-Actions)/.test(e.path)||e.path==='.taste-skill/direction.json');
for(const e of owner)assert.equal(sha(read(e.path)),e.sha256,'Other owner '+e.path);
let archives=0,sourcePaths=0;
const protectedSets=[];
for(const path of ['项目文档/验收/19.1-验证原件/index.json','项目文档/验收/18-整块质量-修改前/index.json','项目文档/验收/18-整块质量原件/index.json','项目文档/验收/18.6-验证原件/index.json','项目文档/验收/18.5-验证原件/index.json','项目文档/验收/18.4-验证原件/index.json','项目文档/验收/18.3-验证原件/index.json','项目文档/验收/18.2-验证原件/index.json','项目文档/验收/18.1-验证原件/index.json']){
 if(!existsSync(path))continue;const index=json(path),folder=path.slice(0,path.lastIndexOf('/'));let n=0;
 for(const e of index.files){const stored=read(folder+'/'+e.file);assert.equal(sha(stored),e.archiveSha256);assert.equal(sha(e.encoding==='gzip'?gunzipSync(stored):stored),e.sha256);archives++;if(e.source?.startsWith('.artifacts/')){assert.equal(existsSync(e.source),true,'Protected raw missing '+e.source);assert.equal(sha(read(e.source)),e.sha256,'Protected raw '+e.source);sourcePaths++;}n++;}protectedSets.push({index:path,files:n});
}
const git=a=>execFileSync('git',a,{encoding:'utf8',maxBuffer:64*1024*1024}).trim();
const report={at:new Date().toISOString(),baselineFiles:base.files.length,missing,changed,otherOwnerProtected:owner.length,protectedSets,archives,sourcePaths,head:git(['rev-parse','HEAD']),origin:git(['rev-parse','origin/main']),stage:git(['diff','--cached','--name-only']),aheadBehind:git(['rev-list','--left-right','--count','HEAD...origin/main'])};
assert.equal(report.head,base.head);assert.equal(report.origin,base.head);assert.equal(report.stage,'');assert.equal(report.aheadBehind,'0\t0');
writeFileSync('.artifacts/19.2/audit-current.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,changed:changed.map(e=>e.path)}));
