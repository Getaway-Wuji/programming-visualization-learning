# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: generated-practice.spec.ts >> 19.2 candidate actual Rust 表达式 difficulty 2 all inputs, wrong repair and reverse
- Location: tests\browser\generated-practice.spec.ts:119:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByLabel('知识', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - generic [ref=e68]: 本地学习
        - link "本地数据" [ref=e69] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e73] [cursor=pointer]
    - main [ref=e76]:
      - generic [ref=e77]:
        - generic [ref=e78]:
          - paragraph [ref=e79]: 规则生成 · C 基础
          - heading "换一道，再练一次" [level=1] [ref=e80]
          - paragraph [ref=e81]: 选择知识与难度，用固定种子得到一道可复现的题。参考解和你的提交都由浏览器内的 Rust 解释器真实执行。
        - paragraph [ref=e82]: 临时加练 · 不计分，不改变课程进度或薄弱点记录 · 草稿与结果刷新后丢弃。保留种子可重新生成同一道题。
        - region "本地复习建议" [ref=e83]:
          - paragraph [ref=e84]: 本地学习依据暂未确认；可自行选择基础题继续加练。
          - generic [ref=e85]:
            - link "核对学习依据 →" [ref=e86] [cursor=pointer]:
              - /url: "#/weaknesses"
            - link "复习队列 →" [ref=e87] [cursor=pointer]:
              - /url: "#/reviews"
            - link "原课程：语句顺序与当前值 →" [ref=e88] [cursor=pointer]:
              - /url: "#/lessons/lesson.c.statement-order"
        - region [ref=e89]:
          - generic [ref=e90]:
            - heading "01 / 选一道题" [level=2] [ref=e91]
            - generic [ref=e92]: 3类题型 · 各2档难度
          - generic [ref=e93]:
            - generic [ref=e94]:
              - text: 知识
              - combobox "知识" [ref=e95]:
                - option "表达式" [selected]
                - option "变量"
                - option "输出"
                - option "输入"
                - option "条件判断"
                - option "循环"
            - generic [ref=e96]:
              - text: 难度
              - combobox "难度" [ref=e97]:
                - option "1 · 基础" [selected]
                - option "2 · 变化"
            - generic [ref=e98]:
              - text: 种子
              - textbox "种子" [ref=e99]: "42"
            - button "生成题目" [ref=e100] [cursor=pointer]
            - button "清空本次加练" [ref=e101] [cursor=pointer]
          - status [ref=e102]: 生成后显示题目、输入范围与起始代码。
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { mkdir, writeFile } from 'node:fs/promises';
  3   | import { gzipSync } from 'node:zlib';
  4   | import { ready } from './notebook-helpers';
  5   | declare global {
  6   |   interface Window {
  7   |     practiceQA: { requests: unknown[]; responses: unknown[]; timings: number[] };
  8   |   }
  9   | }
  10  | const folder = `.artifacts/19.2/browser/${process.env.TASK_EVIDENCE_LABEL ?? 'local'}`;
  11  | const root = (p: Page) => p.getByTestId('generated-practice'),
  12  |   editor = (p: Page) => p.getByTestId('generated-source'),
  13  |   result = (p: Page) => p.getByTestId('generated-assessment');
  14  | test.beforeAll(() => mkdir(folder, { recursive: true }));
  15  | test.beforeEach(async ({ page }) => {
  16  |   await page.addInitScript(() => {
  17  |     const Original = window.Worker;
  18  |     window.practiceQA = { requests: [], responses: [], timings: [] };
  19  |     window.Worker = class extends Original {
  20  |       started = 0;
  21  |       constructor(url: string | URL, options?: WorkerOptions) {
  22  |         super(url, options);
  23  |         if (String(url).includes('practice-worker'))
  24  |           this.addEventListener('message', (e) => {
  25  |             if (e.data?.buffer instanceof ArrayBuffer) {
  26  |               window.practiceQA.responses.push(JSON.parse(new TextDecoder().decode(e.data.buffer)));
  27  |               window.practiceQA.timings.push(performance.now() - this.started);
  28  |             }
  29  |           });
  30  |       }
  31  |       override postMessage(
  32  |         message: unknown,
  33  |         options?: Transferable[] | StructuredSerializeOptions,
  34  |       ) {
  35  |         const m = message as { buffer?: ArrayBuffer; buildId?: string };
  36  |         if (m.buffer && m.buildId) {
  37  |           try {
  38  |             const wire = JSON.parse(new TextDecoder().decode(m.buffer));
  39  |             if (wire.generatorVersion) {
  40  |               window.practiceQA.requests.push(wire);
  41  |               this.started = performance.now();
  42  |             }
  43  |           } catch {
  44  |             /* Other engine packet. */
  45  |           }
  46  |         }
  47  |         if (Array.isArray(options)) super.postMessage(message, options);
  48  |         else super.postMessage(message, options);
  49  |       }
  50  |     };
  51  |   });
  52  | });
  53  | async function open(p: Page) {
  54  |   await p.goto('/#/generated-practice');
  55  |   await expect(root(p)).toBeVisible();
  56  |   await expect(p.getByTestId('generated-recommendation')).toHaveAttribute(
  57  |     'data-state',
  58  |     /^(ready|failed)$/,
  59  |   );
  60  | }
  61  | async function gen(p: Page, knowledge = 'knowledge.c.expressions', difficulty = '1', seed = '42') {
> 62  |   await p.getByLabel('知识', { exact: true }).selectOption(knowledge);
      |                                             ^ Error: locator.selectOption: Test timeout of 30000ms exceeded.
  63  |   await p.getByLabel('难度', { exact: true }).selectOption(difficulty);
  64  |   await p.getByLabel('种子', { exact: true }).fill(seed);
  65  |   await p.getByRole('button', { name: '生成题目', exact: true }).click();
  66  |   await expect(root(p)).toHaveAttribute('data-status', 'generated');
  67  | }
  68  | async function reference(p: Page) {
  69  |   await p.getByText('查看已验证的参考解', { exact: true }).click();
  70  |   await p.getByRole('button', { name: '用参考解替换当前草稿', exact: true }).click();
  71  | }
  72  | async function capture(p: Page, name: string) {
  73  |   await writeFile(
  74  |     `${folder}/${name}.json.gz`,
  75  |     gzipSync(JSON.stringify(await p.evaluate(() => window.practiceQA))),
  76  |     { flag: 'wx' },
  77  |   );
  78  | }
  79  | async function stores(p: Page) {
  80  |   return p.evaluate(async () => {
  81  |     const db = await new Promise<IDBDatabase>((resolve, reject) => {
  82  |       const r = indexedDB.open('c-viz-learning');
  83  |       r.onsuccess = () => resolve(r.result);
  84  |       r.onerror = () => reject(r.error);
  85  |     });
  86  |     const names = Array.from(db.objectStoreNames),
  87  |       tx = db.transaction(names, 'readonly'),
  88  |       done = new Promise<void>((resolve, reject) => {
  89  |         tx.oncomplete = () => resolve();
  90  |         tx.onabort = () => reject(tx.error);
  91  |       });
  92  |     const rows = await Promise.all(
  93  |       names.map(async (n) => {
  94  |         const s = tx.objectStore(n);
  95  |         const a = s.getAllKeys(),
  96  |           b = s.getAll();
  97  |         return [
  98  |           n,
  99  |           await new Promise((resolve) => {
  100 |             a.onsuccess = () => resolve(a.result);
  101 |           }),
  102 |           await new Promise((resolve) => {
  103 |             b.onsuccess = () => resolve(b.result);
  104 |           }),
  105 |         ];
  106 |       }),
  107 |     );
  108 |     await done;
  109 |     db.close();
  110 |     return rows;
  111 |   });
  112 | }
  113 | for (const [knowledge, name] of [
  114 |   ['knowledge.c.expressions', '表达式'],
  115 |   ['knowledge.c.conditions', '条件'],
  116 |   ['knowledge.c.loops', '循环'],
  117 | ])
  118 |   for (const difficulty of ['1', '2'])
  119 |     test(`19.2 candidate actual Rust ${name} difficulty ${difficulty} all inputs, wrong repair and reverse`, async ({
  120 |       page,
  121 |     }) => {
  122 |       await open(page);
  123 |       await gen(page, knowledge, difficulty, difficulty === '1' ? '0' : '4294967295');
  124 |       await editor(page).fill('#include <stdio.h>\nint main(){printf("999\\n");return 0;}');
  125 |       await page.getByRole('button', { name: '提交全部输入', exact: true }).click();
  126 |       await expect(result(page)).toHaveAttribute('data-verdict', 'unmet');
  127 |       await reference(page);
  128 |       await expect(result(page)).toHaveCount(0);
  129 |       await page.getByRole('button', { name: '提交全部输入', exact: true }).click();
  130 |       await expect(result(page)).toHaveAttribute('data-verdict', 'passed');
  131 |       await expect(result(page)).toHaveAttribute('data-complete', 'true');
  132 |       const initial = await page.getByTestId('generated-state').getAttribute('data-state');
  133 |       const slider = page.getByRole('slider', { name: '执行位置' });
  134 |       await slider.fill((await slider.getAttribute('max')) ?? '0');
  135 |       await expect(root(page)).not.toHaveAttribute('data-cursor', '0');
  136 |       await slider.fill('0');
  137 |       expect(await page.getByTestId('generated-state').getAttribute('data-state')).toBe(initial);
  138 |       await page.getByLabel('观察视图').selectOption('memory');
  139 |       await page.getByLabel('观察视图').selectOption('stack');
  140 |       const qa = await page.evaluate(() => window.practiceQA);
  141 |       expect(qa.requests).toHaveLength(3);
  142 |       expect(qa.responses).toHaveLength(3);
  143 |       expect(Math.max(...qa.timings)).toBeLessThan(1000);
  144 |       for (const req of qa.requests as Record<string, unknown>[]) {
  145 |         expect(Object.keys(req).sort()).toEqual(
  146 |           (req.operation === 'generate'
  147 |             ? ['generatorVersion', 'requestId', 'operation', 'knowledgeId', 'difficulty', 'seed']
  148 |             : [
  149 |                 'generatorVersion',
  150 |                 'requestId',
  151 |                 'operation',
  152 |                 'knowledgeId',
  153 |                 'difficulty',
  154 |                 'seed',
  155 |                 'problemId',
  156 |                 'attemptId',
  157 |                 'sourceRevision',
  158 |                 'source',
  159 |               ]
  160 |           ).sort(),
  161 |         );
  162 |       }
```