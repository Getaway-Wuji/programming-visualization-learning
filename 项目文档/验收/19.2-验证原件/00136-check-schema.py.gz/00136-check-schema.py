import json,gzip,pathlib
from jsonschema import Draft202012Validator
root=pathlib.Path.cwd()
s=json.loads((root/'项目文档/契约/19.2-规则生成1.0.0.schema.json').read_text(encoding='utf8'))
Draft202012Validator.check_schema(s)
v=Draft202012Validator(s)
count=0
for f in sorted((root/'.artifacts/19.2/browser/candidate-r3').glob('*.json.gz')):
    packets=json.loads(gzip.decompress(f.read_bytes()))
    for packet in packets['requests']+packets['responses']:
        # Requests that intentionally exercise semantic input/seed rejection retain the same closed wire shape.
        v.validate(packet)
        count+=1
assert count>=36,count
result={'schemaValid':True,'actualWorkerPacketsValidated':count,'source':'browser/candidate-r3','note':'Structural schema plus strict application semantic, identity and inverse trace checks; no response fabrication.'}
(root/'.artifacts/19.2/schema-packets-r1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
