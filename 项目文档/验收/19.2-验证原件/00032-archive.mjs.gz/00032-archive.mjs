import {readFileSync,writeFileSync,readdirSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const sha=b=>createHash('sha256').update(b).digest('hex');
const target='项目文档/验收/19.2-验证原件';mkdirSync(target,{recursive:true});
function walk(dir){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(dir+'/'+e.name):[dir+'/'+e.name]);}
const paths=[...walk('.artifacts').filter(p=>p.startsWith('.artifacts/19.2/')||/\/formal64-r[1-4](?:[/.\-]|$)/.test(p)),...walk('tests/.artifacts/19.2')].sort();
const files=paths.map((source,i)=>{const bytes=readFileSync(source),binary=/\.(?:png|jpg|jpeg|wasm|zip|gz)$/i.test(source),name=source.slice(source.lastIndexOf('/')+1).replace(/[^a-zA-Z0-9_.-]/g,'_'),file=String(i+1).padStart(5,'0')+'-'+name+(binary?'':'.gz'),stored=binary?bytes:gzipSync(bytes);writeFileSync(target+'/'+file,stored,{flag:'wx'});assert.equal(sha(binary?stored:gunzipSync(stored)),sha(bytes));return {source,file,bytes:bytes.length,sha256:sha(bytes),archiveBytes:stored.length,archiveSha256:sha(stored),encoding:binary?'identity':'gzip'};});
const index={version:'1.0.0',task:'19.2',at:new Date().toISOString(),scope:'All task QA rounds including failures and before-fix test sources,420 byte-frozen64 sources,actual generator/native/Worker packets,full keyed DB9 before-after snapshot,visual/quality/build/startup/ownership and verification scripts. Original source paths preserved.',files};
writeFileSync(target+'/index.json',JSON.stringify(index,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({archived:files.length,bytes:files.reduce((n,f)=>n+f.archiveBytes,0),index:target+'/index.json'}));
