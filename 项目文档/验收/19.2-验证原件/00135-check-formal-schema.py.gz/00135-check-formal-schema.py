import json,gzip,pathlib
from jsonschema import Draft202012Validator
root=pathlib.Path.cwd()
s=json.loads((root/'项目文档/契约/19.2-规则生成1.0.0.schema.json').read_text(encoding='utf8'))
Draft202012Validator.check_schema(s)
v=Draft202012Validator(s)
count=0
for f in sorted([* (root/'.artifacts/19.2/browser/formal64-r2').glob('*.json.gz'),* (root/'.artifacts/19.2/browser/formal64-r4').glob('*.json.gz')]):
    packets=json.loads(gzip.decompress(f.read_bytes()))
    for packet in packets['requests']+packets['responses']:
        v.validate(packet)
        count+=1
assert count>=40,count
result={'schemaValid':True,'actualWorkerPacketsValidated':count,'source':'browser/formal64-r2+r4','note':'Real immutable64 browser Worker packets, strict runtime decoder also checked identities, original STEP inverse and deadlines.'}
(root/'.artifacts/19.2/schema-packets-formal.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
