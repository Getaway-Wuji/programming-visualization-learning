import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
function edit(file,fn){const old=readFileSync(file,'utf8'),next=fn(old);assert.notEqual(next,old);writeFileSync(file,next);}
edit('scripts/build-p05-course.mjs',old=>old.replace("import { weaknessPaths } from './weakness-release-inputs.mjs';", "import { weaknessPaths } from './weakness-release-inputs.mjs';\nimport { generatedPracticePaths } from './generated-practice-release-inputs.mjs';")
 .replace("const releaseVersion = existsSync('content/c/p0/blockly-release-1.0.63.json')", "const releaseVersion = existsSync('content/c/p0/blockly-release-1.0.64.json') ? '1.0.64' : existsSync('content/c/p0/blockly-release-1.0.63.json')")
 .replace("    ['1.0.60', '1.0.61', '1.0.62', '1.0.63'].includes(releaseVersion)","    releaseVersion === '1.0.64' ? generatedPracticePaths : ['1.0.60', '1.0.61', '1.0.62', '1.0.63'].includes(releaseVersion)")
 .replaceAll("      '1.0.63',\n", "      '1.0.63',\n      '1.0.64',\n")
 .replace('  registered = true;',`  if (releaseVersion === '1.0.64') {
    assert.equal(registration.generatorEngine.wasmSha256, sha(read('web/src/generated/practice/c_viz_practice_bg.wasm')));
    assert.equal(registration.advancedEngine.wasmSha256, sha(read('web/src/generated/advanced/c_viz_advanced_bg.wasm')));
  }
  registered = true;`));
edit('scripts/restore-release-evidence.mjs',old=>old.replace("  '1.0.63',\n])", "  '1.0.63',\n  '1.0.64',\n])")
 .replace("  const task = ['1.0.60'", "  const task = release === '1.0.64' ? '19.2' : ['1.0.60'")
 .replace("      '1.0.63',\n", "      '1.0.63',\n      '1.0.64',\n"));
