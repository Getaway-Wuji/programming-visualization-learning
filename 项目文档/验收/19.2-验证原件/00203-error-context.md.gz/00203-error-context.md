# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: generated-practice.spec.ts >> 19.2 formal actual exercise failure supplies explainable recommendation without sending history
- Location: tests\browser\generated-practice.spec.ts:308:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByTestId('practice-execution').getByRole('button', { name: '提交练习', exact: true })
    - locator resolved to <button disabled class="button button-primary">提交练习</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
      - waiting 100ms
    54 × waiting for element to be visible, enabled and stable
       - element is not enabled
     - retrying click action
       - waiting 500ms
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - button "进入专注模式" [ref=e68] [cursor=pointer]:
          - generic [ref=e71]: 专注
        - generic [ref=e72]: 本地学习
        - link "本地数据" [ref=e73] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e77] [cursor=pointer]
    - main [ref=e80]:
      - generic [ref=e81]:
        - navigation "当前位置" [ref=e82]:
          - list [ref=e83]:
            - listitem [ref=e84]:
              - link "C 语言课程" [ref=e85] [cursor=pointer]:
                - /url: "#/courses"
            - listitem [ref=e86]:
              - link "变量和输出" [ref=e89] [cursor=pointer]:
                - /url: "#/lessons/lesson.c.variables-output"
            - listitem [ref=e90]:
              - generic [ref=e93]: 输出输入变量
        - generic [ref=e94]:
          - paragraph [ref=e95]: 动手练习 · 程序与输入
          - heading "输出输入变量" [level=1] [ref=e96]
          - paragraph [ref=e97]: 用 C 代码或积木解答，提交后逐步复盘真实执行。
        - paragraph [ref=e101]: 尚无已保存的学习记录
        - generic [ref=e102]:
          - generic [ref=e104]:
            - heading "题目与答题区" [level=2] [ref=e105]
            - paragraph [ref=e106]: 保留输入源变量x（-999到999），用输出积木读取x，输出它的十进制整数和一个换行，不要加提示文字。例：x=7输出7并换行，x=0输出0，x=-9输出-9。必须实际声明、读取输入变量，不能打印固定答案。所有测试正常结束且main返回0。思路：先找到输入声明，再把变量读取放进printf的%d参数。
            - paragraph [ref=e107]: 教学目标：真实声明并读取x，输出依赖输入，不打印固定答案。
            - group [ref=e108]:
              - generic "练习与保存说明" [ref=e109] [cursor=pointer]
          - generic [ref=e110]:
            - generic [ref=e111]:
              - generic "练习起点" [ref=e112]:
                - button "独立练习" [pressed] [ref=e113] [cursor=pointer]
                - button "改错练习" [ref=e114] [cursor=pointer]
                - button "拆积木练习" [ref=e115] [cursor=pointer]
              - link "查看课程示例" [ref=e116] [cursor=pointer]:
                - /url: "#/lessons/lesson.c.variables-output"
            - paragraph [ref=e117]: 从零搭建解答。已保留本题输入声明，请在 main 中加入你的程序。各模式草稿独立保留，切换会清除本次结果；已保存的编辑历史可在离题或刷新后选择恢复，未保存内容可能丢失。示例在新标签页打开。
            - generic [ref=e119]:
              - strong [ref=e120]: 需要一点帮助？
              - button "查看第 1 层提示" [ref=e121] [cursor=pointer]
          - generic [ref=e122]:
            - button "运行本组" [disabled] [ref=e123]
            - button "准备代码" [disabled] [ref=e124]
            - button "提交练习" [disabled] [ref=e125]
            - button "取消提交" [disabled] [ref=e126]
            - link "查看本次复盘" [ref=e127] [cursor=pointer]:
              - /url: "#/practice/exercise.c.echo/review"
          - paragraph [ref=e128]: 运行本组只检查第一组输入，不记录通过或积分；提交练习才检查全部3 组与教学目标。准备代码只生成源码。 修改积木或代码会立即使旧判定和轨迹失效；已保存的历史通过仍保留。
          - generic [ref=e129]:
            - generic [ref=e130]:
              - generic [ref=e131]: 积木显示
              - combobox "积木显示" [ref=e132]:
                - option "自动（按课程推荐）"
                - option "始终显示"
                - option "隐藏" [selected]
            - paragraph [ref=e133]: 本节推荐代码作答。隐藏积木后仍可写代码、运行和提交；切换显示不会修改解答。
            - status [ref=e134]: 积木显示偏好已保存到当前浏览器。
          - group [ref=e135]:
            - generic "积木权限：已永久解锁 0 / 20 · 本节临时开放 8 类" [ref=e136] [cursor=pointer]
          - group [ref=e137]:
            - generic "编辑历史 · 3 条已保存" [ref=e138] [cursor=pointer]
          - alert [ref=e139]: 当前程序含未解锁积木：算术运算。草稿已保留；请展开“积木权限”学习相应小节，或修改当前程序。
          - region "编辑代码" [ref=e143]:
            - complementary "代码与积木联动" [ref=e147]:
              - generic [ref=e148]:
                - generic [ref=e149]:
                  - heading "编辑 C 代码" [level=3] [ref=e150]
                  - generic [ref=e151]: 当前草稿
                - status [ref=e152]: 代码与积木已同步。
                - generic [ref=e153]:
                  - generic [aria-hidden]:
                    - code: "#include <stdio.h> int main(void) { int x = 7; printf(\"%d\\n\", x + 1); return 0; }"
                  - textbox "编辑 C 代码" [active] [ref=e154]: "#include <stdio.h> int main(void) { int x = 7; printf(\"%d\\n\", x + 1); return 0; }"
                - paragraph [ref=e155]:
                  - text: 编辑稿使用本题第一组输入：
                  - code [ref=e156]: "{\"x\":7}"
                  - text: 。已保存的编辑历史可在刷新后选择恢复，未保存内容仅在本次页面保留；选择代码或积木可查看对应位置。
          - heading "本次提交与反馈" [level=3] [ref=e158]
          - status [ref=e160]:
            - generic [ref=e164]:
              - heading "已保存" [level=2] [ref=e165]
              - paragraph [ref=e166]: 这次更改已保存到当前浏览器。
          - region "小节完成清单" [ref=e167]:
            - generic [ref=e168]:
              - heading "小节完成清单" [level=3] [ref=e169]
              - generic [ref=e170]: 1/2 项已保存
            - list [ref=e171]:
              - listitem [ref=e172]:
                - generic [ref=e173]: 阅读并主动确认学习
                - strong [ref=e174]: 已保存
              - listitem [ref=e175]:
                - generic [ref=e176]: 输出输入变量
                - strong [ref=e177]: 待通过并保存
            - paragraph [ref=e178]: 小节尚未完成
            - link "继续搭建并提交全部测试" [ref=e179] [cursor=pointer]:
              - /url: "#/practice/exercise.c.echo#practice-answer"
          - paragraph [ref=e180]: 当前源码对应测试组：positive。此处为将实际执行的完整代码。
          - paragraph [ref=e181]:
            - text: 本组输入：
            - code [ref=e182]: "{\"x\":7}"
          - generic "执行播放工作区" [ref=e183]:
            - region "运行结果" [ref=e184]:
              - heading "当前步骤画面" [level=3] [ref=e186]
              - generic "播放控制" [ref=e187]:
                - generic [ref=e188]:
                  - button "后退" [disabled] [ref=e189]
                  - button "播放" [disabled] [ref=e190]
                  - button "前进" [disabled] [ref=e191]
                  - button "重播" [disabled] [ref=e192]
                - generic [ref=e193]:
                  - text: 速度
                  - combobox "播放速度" [disabled] [ref=e194]:
                    - option "0.25×"
                    - option "0.5×"
                    - option "1×" [selected]
                    - option "1.5×"
                    - option "2×"
                    - option "4×"
                - generic [ref=e195]:
                  - generic [ref=e196]: 步骤 — / 0
                  - status [ref=e197]: 等待运行轨迹
                - paragraph [ref=e198]: 聚焦播放工作区后，空格播放或暂停，左右方向键单步查看。重播从初始状态开始播放。
              - paragraph [ref=e200]: 尚无当前步骤画面。运行后从初始状态开始查看。
        - paragraph [ref=e201]: 积木只生成受支持的 C 程序。返回本节可查看已保存的历史进度。
        - link "返回本节学习" [ref=e202] [cursor=pointer]:
          - /url: "#/lessons/lesson.c.variables-output"
```

# Test source

```ts
  219 |   await expect(editor(page)).toHaveCount(0);
  220 |   mode = 'ok';
  221 |   await gen(page);
  222 |   await page.getByRole('button', { name: '清空本次加练', exact: true }).click();
  223 |   await expect(editor(page)).toHaveCount(0);
  224 |   await expect(result(page)).toHaveCount(0);
  225 |   await gen(page);
  226 |   await capture(page, 'module-recovery');
  227 | });
  228 | test('19.2 candidate responsive widths and representative minimal theme keep controls usable', async ({
  229 |   page,
  230 | }) => {
  231 |   await open(page);
  232 |   await gen(page, 'knowledge.c.loops', '2');
  233 |   for (const width of [1440, 768, 390]) {
  234 |     await page.setViewportSize({ width, height: 900 });
  235 |     await expect(page.getByRole('button', { name: '生成题目', exact: true })).toBeVisible();
  236 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  237 |       true,
  238 |     );
  239 |     await page.screenshot({ path: `${folder}/generated-${width}.png`, fullPage: true });
  240 |   }
  241 |   await page.setViewportSize({ width: 1440, height: 900 });
  242 |   await page.goto('/#/settings');
  243 |   await expect(page.locator('html')).toHaveAttribute('data-appearance', 'minimal');
  244 |   await page.goto('/#/generated-practice');
  245 |   await gen(page);
  246 |   await page.screenshot({ path: `${folder}/minimal-1440.png`, fullPage: true });
  247 |   await reference(page);
  248 |   await page.getByRole('button', { name: '提交全部输入', exact: true }).click();
  249 |   await expect(result(page)).toHaveAttribute('data-verdict', 'passed');
  250 |   await page.getByRole('slider', { name: '执行位置' }).fill('4');
  251 |   for (const width of [1440, 768, 390]) {
  252 |     await page.setViewportSize({ width, height: 900 });
  253 |     for (const mode of ['basic', 'memory', 'stack']) {
  254 |       await page.getByLabel('观察视图').selectOption(mode);
  255 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  256 |         true,
  257 |       );
  258 |     }
  259 |     await page.screenshot({ path: `${folder}/result-${width}.png`, fullPage: true });
  260 |   }
  261 | });
  262 | test('19.2 formal empty evidence and whole keyed DB stay unchanged by transient practice', async ({
  263 |   page,
  264 | }) => {
  265 |   await page.goto('/#/courses');
  266 |   await ready(page);
  267 |   await open(page);
  268 |   await expect(page.getByTestId('generated-recommendation')).toHaveAttribute('data-state', 'ready');
  269 |   await expect(page.getByTestId('generated-recommendation')).toContainText('暂无待复习');
  270 |   const before = await stores(page);
  271 |   expect(before).toHaveLength(17);
  272 |   await gen(page);
  273 |   await reference(page);
  274 |   await page.getByRole('button', { name: '提交全部输入', exact: true }).click();
  275 |   await expect(result(page)).toHaveAttribute('data-verdict', 'passed');
  276 |   await page.getByRole('button', { name: '清空本次加练', exact: true }).click();
  277 |   expect(await stores(page)).toEqual(before);
  278 |   await writeFile(
  279 |     `${folder}/keyed-db-unchanged.json`,
  280 |     JSON.stringify({ before, after: await stores(page) }),
  281 |     { flag: 'wx' },
  282 |   );
  283 | });
  284 | test('19.2 formal confirmed manual evidence recommends only supported exact knowledge and preserves original links', async ({
  285 |   page,
  286 | }) => {
  287 |   await page.goto('/#/lessons/lesson.c.variables-output');
  288 |   await ready(page);
  289 |   await expect(page.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  290 |   await page.locator('[data-knowledge-mark="knowledge.c.variables"]').click();
  291 |   await expect(page.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  292 |   await open(page);
  293 |   await expect(page.getByTestId('generated-recommendation')).toContainText('手动自评');
  294 |   await page.getByRole('button', { name: '采用此知识建议' }).click();
  295 |   await expect(page.getByLabel('知识', { exact: true })).toHaveValue('knowledge.c.variables');
  296 |   await expect(page.getByRole('link', { name: /原课程：/ })).toHaveAttribute(
  297 |     'href',
  298 |     '#/lessons/lesson.c.variables-output',
  299 |   );
  300 |   await gen(page, 'knowledge.c.variables');
  301 |   const qa = await page.evaluate(() => window.practiceQA);
  302 |   expect(qa.requests).toHaveLength(1);
  303 |   expect(Object.keys(qa.requests[0] as object)).toHaveLength(6);
  304 |   await capture(page, 'manual-minimal-payload');
  305 |   await page.getByRole('link', { name: '核对学习依据 →' }).click();
  306 |   await expect(page.getByRole('link', { name: '生成一道同类加练题 →' })).toBeVisible();
  307 | });
  308 | test('19.2 formal actual exercise failure supplies explainable recommendation without sending history', async ({
  309 |   page,
  310 | }) => {
  311 |   await page.goto('/#/courses');
  312 |   await ready(page);
  313 |   await confirm(page, 'lesson.c.variables-output');
  314 |   await confirm(page, 'lesson.c.expressions');
  315 |   await openAnswer(page, 'exercise.c.echo');
  316 |   const source = await code(page).inputValue();
  317 |   await code(page).fill(source.replace(/printf\([^;]+;/, 'printf("%d\\n", x + 1);'));
  318 |   await expect(page.getByTestId('draft-code-editor')).toHaveAttribute('data-sync', 'synced');
> 319 |   await panel(page).getByRole('button', { name: '提交练习', exact: true }).click();
      |                                                                        ^ Error: locator.click: Test timeout of 30000ms exceeded.
  320 |   await expect(panel(page)).toHaveAttribute('data-state', 'unmet');
  321 |   await expect(page.getByTestId('practice-attempt-save')).toHaveAttribute(
  322 |     'data-save-state',
  323 |     'saved',
  324 |   );
  325 |   await open(page);
  326 |   await expect(page.getByTestId('generated-recommendation')).toContainText('真实练习错误');
  327 |   await page.getByRole('button', { name: '采用此知识建议' }).click();
  328 |   await page.getByRole('button', { name: '生成题目', exact: true }).click();
  329 |   await expect(root(page)).toHaveAttribute('data-status', 'generated');
  330 |   await capture(page, 'automatic-minimal-payload');
  331 | });
  332 | test('19.2 formal unsupported marked knowledge has honest original-course fallback', async ({
  333 |   page,
  334 | }) => {
  335 |   await page.goto('/#/lessons/lesson.c.array-initialization');
  336 |   await ready(page);
  337 |   await expect(page.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  338 |   await page.locator('[data-knowledge-mark="knowledge.c.arrays"]').click();
  339 |   await expect(page.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  340 |   await open(page);
  341 |   await expect(page.getByTestId('generated-recommendation')).toContainText('尚未提供的题型');
  342 |   await expect(page.getByRole('button', { name: '采用此知识建议' })).toHaveCount(0);
  343 |   await expect(page.getByRole('link', { name: '复习队列 →' })).toBeVisible();
  344 | });
  345 | 
```