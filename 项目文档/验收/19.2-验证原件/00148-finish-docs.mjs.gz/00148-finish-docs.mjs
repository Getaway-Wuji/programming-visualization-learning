import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const result=JSON.parse(readFileSync('项目文档/验收/19.2-最终复核.json','utf8'));
assert.equal(result.accepted,true);assert.equal(result.formalChrome.uniquePassed,88);
const message='19.2实际验收（2026-11-01）：Rust规则生成3类C模板×2档，参考解与提交均真实解释完整有限域，最少参数推荐、临时独立身份、错误修复和完整逆向回放齐备；不计分、不保存生成历史、不发学习/奖励事件。正式64/420源、第五WASM独立分支，原四WASM/SAVE9/DB9/17store/预算保持；2116全量前端、Rust549通过/原忽略1、88唯一正式Chrome跨轮、44真实包Schema、类型/lint/格式/完整构建/自有启动通过。旧6035归档/6031原路径及17外窗文件保持。原81/88余7、主81/98、P2 12/19、第19为2/5、P0.5 9/9、21为0/10，原课程/算法数量不增；19.3交回协调另派，本轮无暂存/提交/推送。';
for(const path of ['README.md','项目守则.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md']){
 let body=readFileSync(path,'utf8');assert.equal(body.includes('19.2实际验收（2026-11-01）'),false);
 const docRoot=path.startsWith('项目文档/'),prefix=docRoot?'./':'项目文档/';
 const links=`见[验收](${prefix}验收/19.2-规则生成与真实作答验收.md)、[独立交接](${prefix}交接/19.2-交接.md)、[最终复核](${prefix}验收/19.2-最终复核.json)。下方保留历史时点。`;
 const line=body.indexOf('\n');body=body.slice(0,line+1)+'\n'+message+' '+links+'\n'+body.slice(line+1);
 if(path.endsWith('任务进度与交接.md')){
  const old=body.split('\n').find(s=>s.startsWith('| 19.2 |'));
  assert.ok(old?.includes('进行中'));body=body.replace(old,'| 19.2 | P2 | [Rust 同类题生成与可验证答案](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 已验收 | root / 完成19任务 | 64/420源、3模板×2档、第五真实Rust/WASM、独立临时不计分身份；2116前端、Rust549/忽略1、88唯一正式Chrome、44包Schema及类型/lint/格式/构建/启动通过。[验收](./验收/19.2-规则生成与真实作答验收.md) / [交接](./交接/19.2-交接.md)。第19为2/5，19.3未领取，不Git。 |');
  const previous=body.split('\n').find(s=>s.startsWith('| 19.1 |'));assert.ok(previous);body=body.replace(previous,previous.replace('第19为1/5，19.2未领取','第19当前2/5，19.3未领取'));
  const stats=body.split('\n').find(s=>s.startsWith('阶段统计（19.1实际验收后）'));assert.ok(stats);body=body.replace(stats,'阶段统计（19.2实际验收后）：原P0 41项、P1 28项、P2 12项已验收，原81/88、余7，主路线81/98；P0.5独立9/9，21新增0/10。第17/18已交付，第19为2/5；19.2交回协调，19.3未领取。P2总门槛20.4未完成，本轮无Git写入。');
 }
 writeFileSync(path,body);
}
const cardPath='项目文档/契约/19.2-兼容变更登记.json',card=JSON.parse(readFileSync(cardPath,'utf8'));card.status='accepted';writeFileSync(cardPath,JSON.stringify(card,null,2)+'\n');
console.log('Updated five central records,19.2 accepted;19.3 unclaimed.');
