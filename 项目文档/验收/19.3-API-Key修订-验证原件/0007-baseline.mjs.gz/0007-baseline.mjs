import {readdirSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const files=[];
function scan(dir='.') {for(const d of readdirSync(dir,{withFileTypes:true})) {if(['.git','node_modules','.artifacts','dist','target','.vite'].includes(d.name))continue;const p=(dir==='.'?'':dir+'/')+d.name;if(d.isDirectory())scan(p);else{const b=readFileSync(p);files.push({path:p,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')});}}}
scan();const git=a=>execFileSync('git',a,{encoding:'utf8',maxBuffer:64*1024*1024}).trim();
writeFileSync('.artifacts/19.3-api/baseline.json',JSON.stringify({at:new Date().toISOString(),head:git(['rev-parse','HEAD']),stage:git(['diff','--cached','--name-only']),aheadBehind:git(['rev-list','--left-right','--count','HEAD...origin/main']),files},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({files:files.length}));
