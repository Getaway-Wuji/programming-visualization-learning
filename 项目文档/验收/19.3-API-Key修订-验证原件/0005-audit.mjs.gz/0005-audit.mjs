import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gunzipSync} from 'node:zlib';
const read=p=>readFileSync(p),json=p=>JSON.parse(read(p).toString().replace(/^\uFEFF/,'')),sha=b=>createHash('sha256').update(b).digest('hex'),base=json('.artifacts/19.3-api/baseline.json');
const allowed=['README.md','项目守则.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md'],changed=[],missing=[];
for(const e of base.files){if(!existsSync(e.path)){missing.push(e.path);continue;}const hash=sha(read(e.path));if(hash!==e.sha256){assert.ok(allowed.includes(e.path),'Outside design scope: '+e.path);changed.push({path:e.path,before:e.sha256,after:hash});}}
assert.deepEqual(missing,[]);
const releasePath='content/c/p0/blockly-release-1.0.64.json',release=json(releasePath);for(const e of release.files)assert.equal(sha(read(e.path)),e.sha256,e.path);for(const e of Object.values(release.evidence))assert.equal(sha(read(e.path)),e.sha256);
const wasmPaths=['web/src/generated/c_viz_wasm_bg.wasm','web/src/generated/algorithm/c_viz_algorithm_bg.wasm','web/src/generated/memory/c_viz_memory_bg.wasm','web/src/generated/advanced/c_viz_advanced_bg.wasm','web/src/generated/practice/c_viz_practice_bg.wasm'];const wasm=wasmPaths.map(path=>{const baseline=base.files.find(f=>f.path===path);assert.equal(sha(read(path)),baseline.sha256);return {path,sha256:baseline.sha256};});
const indices=['项目文档/验收/19.3-验证原件/index.json','项目文档/验收/19.2-验证原件/index.json','项目文档/验收/19.1-验证原件/index.json','项目文档/验收/18-整块质量-修改前/index.json','项目文档/验收/18-整块质量原件/index.json',...Array.from({length:6},(_,i)=>`项目文档/验收/18.${i+1}-验证原件/index.json`)];
let archives=0,raw=0;
for(const p of indices){const index=json(p),folder=p.slice(0,p.lastIndexOf('/'));for(const f of index.files){const b=read(folder+'/'+f.file);assert.equal(sha(b),f.archiveSha256);assert.equal(sha(f.encoding==='gzip'?gunzipSync(b):b),f.sha256);archives++;if(f.source?.startsWith('.artifacts/')||f.source?.startsWith('tests/.artifacts/')){assert.equal(sha(read(f.source)),f.sha256,'Protected original '+f.source);raw++;}}}
const other=base.files.filter(e=>/2026-10-31-(?:CI|GitHub-Actions)/.test(e.path)||e.path==='.taste-skill/direction.json');for(const e of other)assert.equal(sha(read(e.path)),e.sha256);
const git=a=>execFileSync('git',a,{encoding:'utf8',maxBuffer:64*1024*1024}).trim();
const old19=base.files.filter(f=>/19\.3-/.test(f.path));for(const f of old19)assert.equal(sha(read(f.path)),f.sha256,'Frozen old19.3 '+f.path);
const prior=json('项目文档/验收/19.2-最终复核.json');assert.equal(prior.release.sha256,sha(read(releasePath)));for(const e of [prior.units.source,prior.rust.source,...prior.formalChrome.reports.map(r=>r.source)])assert.equal(sha(read(e.path)),e.sha256);
const report={old19FrozenFiles:old19.length,inheritedQuality:{frontend:prior.units.passed,rustPassed:prior.rust.passed,rustIgnored:1,formalChromeUnique:prior.formalChrome.uniquePassed,sourceSHAMatched:true,rerun:false},at:new Date().toISOString(),baselineFiles:base.files.length,missing,changed,release:{path:releasePath,sha256:sha(read(releasePath)),sources:release.files.length,version:release.releaseVersion},wasm,protectedArchives:archives,protectedOriginalPaths:raw,otherOwnerProtected:other.length,head:git(['rev-parse','HEAD']),origin:git(['rev-parse','origin/main']),stage:git(['diff','--cached','--name-only']),aheadBehind:git(['rev-list','--left-right','--count','HEAD...origin/main'])};
assert.equal(report.head,base.head);assert.equal(report.origin,base.head);assert.equal(report.stage,'');assert.equal(report.aheadBehind,'0\t0');assert.equal(archives,7070);assert.equal(raw,7066);assert.equal(other.length,17);
writeFileSync('.artifacts/19.3-api/audit-current.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,changed:changed.map(e=>e.path)}));
