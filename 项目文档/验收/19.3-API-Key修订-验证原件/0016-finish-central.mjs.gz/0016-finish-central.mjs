import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const card='项目文档/契约/19.3-API-Key兼容变更登记.json';
const change=JSON.parse(readFileSync(card,'utf8'));change.status='accepted-design-only-revision';writeFileSync(card,JSON.stringify(change,null,2)+'\n');
const docs=['README.md','项目守则.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md'];
for(const path of docs){let body=readFileSync(path,'utf8');assert.equal(body.includes('19.3 API-Key修订验收（2026-11-01）'),false,'Do not repeat current record');const root=!path.startsWith('项目文档/'),prefix=root?'项目文档/':'./';
const intro=`19.3 API-Key修订验收（2026-11-01）：按用户要求，当前设计为默认关闭、设置中选择受支持服务/模型并自备API Key、验证后启用；Key与配置仅当前标签页内存，关闭/刷新/退出清除，禁持久化/日志/URL/错误/截图留Key。DEC-P2-011/AI-DATA-01/AI-EXPLAIN-01升级2.0.0，固定同源受控Rust转发至官方API；逐次预览确认最少当前源码/诊断/同游标事实，明确第三方保留/费用，取消只停止本端且不保证零扣费。旧本机路线和约6.3GB下载询问已被替代而非批准；下方旧19.3记录仅保留历史。旧任务包“密钥不在前端”按用户指示解释为禁止内置/公开/共享Key，允许设置临时输入用户Key。17正/49拒绝设计检查、3份原真实Rust包复核；无凭据验证/模型调用/产品实现。64/420源、五WASM/SAVE9/DB9/17store、原预算和7070旧归档/7066原路径/17外窗保持；按实SHA继承质量，未新发版本。原82/88余6、主82/98、P2 13/19、第19为3/5、P0.5 9/9、21为0/10不增。19.4/19.5未开始；19.4先完成不依赖真Key的实施，真实成功仍需通过产品安全设置入口自备Key，现在不索取Key。无Git写入。见[新版决议](${prefix}架构决策/19.3-API-Key可选AI修订.md)、[修订验收](${prefix}验收/19.3-API-Key修订验收.md)、[独立交接](${prefix}交接/19.3-API-Key修订-交接.md)。`;
const split=body.indexOf('\n');body=body.slice(0,split+1)+'\n'+intro+'\n'+body.slice(split+1);
if(path==='项目文档/任务进度与交接.md'){
body=body.replace(/^\| 19\.3 \|.*$/m,'| 19.3 | P2 | [AI 方案与数据边界决议](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 已验收（设计，API-Key修订） | root / 完成19任务 | DEC-P2-011/AI-DATA/AI-EXPLAIN 2.0.0；默认关闭、自备Key设置启用，同源受控官方API/逐次确认与保留费用披露；17正/49拒绝及原3Rust事实复核，无API验证/推理/产品实现，旧本机下载问题已替代。64/420/五WASM保持。[修订验收](./验收/19.3-API-Key修订验收.md) / [修订交接](./交接/19.3-API-Key修订-交接.md)。第19为3/5不重复计数，19.4/19.5未开始，不Git。 |');
body=body.replace(/^阶段统计（19\.3设计验收后）：.*$/m,'阶段统计（19.3 API-Key设计修订验收后）：原P0 41项、P1 28项、P2 13项已验收，原82/88、余6，主路线82/98；P0.5独立9/9，21新增0/10。第17/18已交付，第19为3/5；19.3修订不重复计数，交回协调。19.4/19.5未开始，AI设置/API尚未实际接入；后续先做独立实施，再通过产品安全入口自备Key取得真实成功，不恢复旧模型下载询问。P2总门槛20.4未完成，本轮无Git写入。');
body=body.replace('| DEC-008 | AI 模型、配置、时间和数据边界 | 19.3 | 三期待决策 |','| DEC-008 | AI 模型、配置、时间和数据边界 | 19.3 | 已由DEC-P2-011 2.0.0设计修订裁决，产品19.4/19.5待实施验收 |');
}
writeFileSync(path,body);}
console.log(JSON.stringify({centralDocuments:docs.length,countsUnchanged:true,productChanges:0}));
