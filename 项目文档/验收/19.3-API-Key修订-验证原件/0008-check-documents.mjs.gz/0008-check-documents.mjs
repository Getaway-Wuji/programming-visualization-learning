import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
const roots=['架构决策','契约','交付','验收','交接'].map(p=>'项目文档/'+p);
const own=roots.flatMap(dir=>readdirSync(dir).filter(n=>/^19\.3-(?:API-Key|AI解释2\.0\.0)/.test(n)).map(n=>dir+'/'+n));
const pending=[],post=process.argv.includes('--final');let links=0,jsonFiles=0;
for(const path of own){if(!/\.(json|md)$/.test(path))continue;const body=readFileSync(path,'utf8');assert.equal(body.includes('\uFFFD'),false,path);if(path.endsWith('.json')){JSON.parse(body);jsonFiles++;continue;}
assert.equal((body.match(/^```/gm)??[]).length%2,0,path);
for(const m of body.matchAll(/\]\(([^)]+)\)/g)){const target=m[1].replace(/^<|>$/g,'').split('#')[0];if(!target||/^https?:/.test(target))continue;const resolved=resolve(dirname(path),target);if(!existsSync(resolved)&&!post&&/19\.3-API-Key修订-(?:最终复核\.json|验证原件[\\/]index\.json)$/.test(target)){pending.push(target);continue;}assert.ok(existsSync(resolved),'Missing link '+path+' -> '+target);links++;}}
const central=['README.md','项目守则.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md'];
for(const p of central){const b=readFileSync(p,'utf8');assert.ok(b.split('\n').slice(0,6).join('\n').includes('19.3 API-Key修订验收'));for(const count of ['82/88','82/98','13/19','3/5','9/9','0/10'])assert.ok(b.includes(count));}
const card=JSON.parse(readFileSync('项目文档/契约/19.3-API-Key兼容变更登记.json','utf8'));assert.equal(card.status,'accepted-design-only-revision');
const report={newDocuments:own.filter(p=>/\.(json|md)$/.test(p)).length,jsonFiles,localLinks:links,pending:[...new Set(pending)],invalidLinks:0,centralDocuments:5,encodingValid:true,countsUnchanged:true};
if(!post)writeFileSync('.artifacts/19.3-api/document-precheck.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
