import {readFileSync,writeFileSync,readdirSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const sha=b=>createHash('sha256').update(b).digest('hex'),target='项目文档/验收/19.3-验证原件';mkdirSync(target,{recursive:true});
function walk(dir){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(dir+'/'+e.name):[dir+'/'+e.name]);}
const paths=walk('.artifacts/19.3').sort();
const files=paths.map((source,i)=>{const bytes=readFileSync(source),binary=/\.(?:gz|zip|png|jpg)$/i.test(source),name=source.slice(source.lastIndexOf('/')+1).replace(/[^a-zA-Z0-9_.-]/g,'_'),file=String(i+1).padStart(4,'0')+'-'+name+(binary?'':'.gz'),stored=binary?bytes:gzipSync(bytes);writeFileSync(target+'/'+file,stored,{flag:'wx'});assert.equal(sha(binary?stored:gunzipSync(stored)),sha(bytes));return {source,file,bytes:bytes.length,sha256:sha(bytes),archiveBytes:stored.length,archiveSha256:sha(stored),encoding:binary?'identity':'gzip'};});
writeFileSync(target+'/index.json',JSON.stringify({version:'1.0.0',task:'19.3',scope:'Design-only host presence and official metadata observations,initial retrieval/schema/document check failures,three actual old-Rust contexts,explicitly hypothetical responses and not-sent provider projections,closed-schema design checks,baseline and source/old-evidence protection. No product model invocation evidence.',at:new Date().toISOString(),files},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({archived:files.length,bytes:files.reduce((n,e)=>n+e.archiveBytes,0)}));
