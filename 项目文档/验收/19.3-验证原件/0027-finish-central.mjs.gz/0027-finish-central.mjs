import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const final=JSON.parse(readFileSync('项目文档/验收/19.3-最终复核.json','utf8'));assert.equal(final.accepted,true);assert.equal(final.productAIImplemented,false);
const message='19.3设计验收（2026-11-01）：已冻结默认关闭的可选本机Ollama/Qwen方案、最少上下文/同源与进程职责、独立60s预算、密钥/日志/预览/失效/取消/降级边界及19.4/19.5真实模型门槛。本机未配置或运行产品模型，未下载/安装/调用；7正/23拒绝设计例与3份原真实Rust事实核对通过，设计答复明标非模型。64/420与五WASM/SAVE9/DB9/17store保持，按实SHA继承原产品质量，未重跑全套或新发产品版本。旧7030归档/7026原路径/17外窗保持。原82/88余6、主82/98、P2 13/19、第19为3/5、P0.5 9/9、21为0/10；19.4交协调另派，准备安装仍需用户明确接受，无Git写入。';
for(const p of ['README.md','项目守则.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md']){
 let body=readFileSync(p,'utf8');assert.equal(body.includes('19.3设计验收（2026-11-01）'),false);const prefix=p.startsWith('项目文档/')?'./':'项目文档/',at=body.indexOf('\n');body=body.slice(0,at+1)+'\n'+message+` 见[决议](${prefix}架构决策/19.3-本机AI方案与最小数据边界.md)、[验收](${prefix}验收/19.3-AI方案与数据边界验收.md)、[交接](${prefix}交接/19.3-交接.md)。下方保留历史时点。\n`+body.slice(at+1);
 if(p.endsWith('任务进度与交接.md')){
  const old=body.split('\n').find(l=>l.startsWith('| 19.3 |'));assert.ok(old?.includes('进行中'));body=body.replace(old,'| 19.3 | P2 | [AI 方案与数据边界决议](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 已验收（设计） | root / 完成19任务 | DEC-P2-011/AI-EXPLAIN1，默认关闭本机候选；7正/23拒绝及3份原真实Rust事实，未安装/调用模型，非AI实现。64/420/五WASM保持。[验收](./验收/19.3-AI方案与数据边界验收.md) / [交接](./交接/19.3-交接.md)。第19为3/5，19.4未领取，不Git。 |');
  for(const id of ['19.1','19.2']){const previous=body.split('\n').find(l=>l.startsWith('| '+id+' |'));assert.ok(previous);body=body.replace(previous,previous.replace('第19当前2/5，19.3未领取','第19当前3/5，19.4未领取').replace('第19为2/5，19.3未领取','第19当前3/5，19.4未领取'));}
  const stats=body.split('\n').find(l=>l.startsWith('阶段统计（19.2实际验收后）'));assert.ok(stats);body=body.replace(stats,'阶段统计（19.3设计验收后）：原P0 41项、P1 28项、P2 13项已验收，原82/88、余6，主路线82/98；P0.5独立9/9，21新增0/10。第17/18已交付，第19为3/5；19.3交回协调，19.4未领取，AI尚未实际接入。P2总门槛20.4未完成，本轮无Git写入。');
 }
 writeFileSync(p,body);
}
console.log('Five central records updated:19.3 design accepted;19.4 unclaimed.');
