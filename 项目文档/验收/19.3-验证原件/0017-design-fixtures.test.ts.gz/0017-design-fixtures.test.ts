import {test,expect} from 'vitest';
import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {initSync,execute_advanced} from '../../web/src/generated/advanced/c_viz_advanced';
import {engineBuild} from '../../web/src/generated/advanced/engine-build';
import {advancedRequest} from '../../web/src/engine/advanced-client';
import {encodeAdvancedRequest,decodeAdvancedResult} from '../../web/src/engine/advanced-protocol';
import {AdvancedPlayer} from '../../web/src/engine/advanced-player';
initSync({module:new WebAssembly.Module(new Uint8Array(readFileSync('web/src/generated/advanced/c_viz_advanced_bg.wasm')))});
mkdirSync('.artifacts/19.3/actual-rust',{recursive:true});
const cases=[
 {id:'pointer',source:'#include <stdio.h>\nint main(){int *p=0;int value=*p;printf("%d\\n",value);return 0;}\n',want:'E_NULL_POINTER'},
 {id:'loop',source:'#include <stdio.h>\nint main(){int i=0;while(i<3){i=i+2;}printf("%d\\n",i);return 0;}\n',want:null},
 {id:'syntax',source:'int main( {\n',want:'syntax'},
];
const examples:unknown[]=[];
test('three design contexts derive from unchanged actual Rust/WASM, not a model',async()=>{
 for(const sample of cases){
  const request=advancedRequest(sample.source,'c',{kind:'integers',values:[]}),bytes=execute_advanced(encodeAdvancedRequest(request),engineBuild.wasmSha256,1000).slice();
  const result=await decodeAdvancedResult(bytes.buffer,request,engineBuild.wasmSha256);
  if(sample.want==='syntax'){expect(result.trace).toBeNull();expect(result.terminal.code).toMatch(/^E_/);}else if(sample.want)expect(result.terminal.code).toBe(sample.want);else expect(result.terminal.status).toBe('completed');
  const player=new AdvancedPlayer();player.accept(result);
  const output=result.trace?.steps.findIndex(s=>s.kind==='output.append')??-1;
  const cursor=result.trace?(sample.id==='loop'?output+1:result.terminal.cursor):null;
  if(cursor!==null)player.seek(cursor);
  const state=player.snapshot().state;
  const facts:Record<string,unknown>[]=[];
  const add=(fact:Record<string,unknown>)=>facts.push({factId:'f'+(facts.length+1),...fact});
  if(result.terminal.code)add({kind:'diagnostic',code:result.terminal.code,byteRange:result.terminal.byteRange});
  if(cursor!==null&&cursor>0){const step=result.trace!.steps[cursor-1],node=result.nodeMap.find(n=>n.nodeId===step.nodeId)!;add({kind:'step',step:cursor,stepKind:step.kind,nodeId:step.nodeId,byteRange:node.byteRange});}
  for(const object of (state?.objects??[]).filter(o=>o.alive&&['i','p'].includes(o.name)).slice(0,2)){
   const cell=object.cells[0];if(cell&&typeof cell.value!=='string')add({kind:'state',atCursor:cursor,objectId:object.id,frameId:object.frameId,byteOffset:cell.byteOffset,name:object.name,typeName:object.typeName,alive:object.alive,value:cell.value});
  }
  if(sample.id==='loop'){expect(facts.some(f=>f.kind==='state'&&f.value===4)).toBe(true);}
  const context={contextId:randomUUID(),runRef:{engineId:result.engine.id,buildId:result.engine.buildId,execVersion:result.execVersion,dslVersion:result.dslVersion,diagnosticVersion:result.diagnosticVersion,language:'c',...result.identity},inputRevision:randomUUID(),cursor,traceAvailable:result.trace!==null,snippets:[{snippetId:'s1',byteRange:{start:0,end:new TextEncoder().encode(sample.source).length},firstLine:1,text:sample.source}],facts};
  const aiRequest={aiVersion:'1.0.0',kind:'explain.request',requestId:randomUUID(),context};
  const aiResponse={aiVersion:'1.0.0',kind:'explain.response',requestId:aiRequest.requestId,contextId:context.contextId,runRef:context.runRef,inputRevision:context.inputRevision,cursor,producer:'local-model-adapter',model:{runtimeVersion:'0.40.13',tag:'qwen2.5-coder:7b-instruct-q4_K_M',manifestSha256:'dae161e27b0e90dd1856c8bb3209201fd6736d8eb66298e75ed87571486f4364'},content:{summary:'设计占位：本内容非模型调用所得。',explanations:[{factIds:[facts[0].factId],text:'设计协议示意，请对照引用的真实Rust事实；不能将此文本作为AI验收证据。'}],suggestions:[],limitations:'没有调用任何模型。'},timing:{elapsedMs:1}};
  const path='.artifacts/19.3/actual-rust/'+sample.id+'.json.gz';writeFileSync(path,gzipSync(JSON.stringify({request,result,selectedCursor:cursor,state})),{flag:'wx'});
  examples.push({id:sample.id,evidence:{path,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')},request:aiRequest,hypotheticalResponse:aiResponse});
 }
 writeFileSync('项目文档/契约/19.3-AI设计样例.json',JSON.stringify({label:'DESIGN SCHEMA FIXTURES ONLY / NO MODEL CALL / NOT AI ACCEPTANCE',factEvidence:'Actual unchanged advanced Rust/WASM runs of authored public C examples; response text is explicitly hypothetical.',modelCalls:0,examples},null,2)+'\n',{flag:'wx'});
});
