import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['.artifacts/19.3/design-fixtures.test.ts'],environment:'node',maxWorkers:1,fileParallelism:false,reporters:['default','json'],outputFile:{json:'.artifacts/19.3/rust-design-fixtures.json'}}});
