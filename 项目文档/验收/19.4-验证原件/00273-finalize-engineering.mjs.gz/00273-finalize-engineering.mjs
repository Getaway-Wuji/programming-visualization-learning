import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
const read=p=>readFileSync(p),json=p=>JSON.parse(read(p).toString().replace(/^\uFEFF/,'')),sha=b=>createHash('sha256').update(b).digest('hex');
const proof=path=>({path,sha256:sha(read(path))});
const save=(p,v)=>writeFileSync(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const dir='.artifacts/19.4';
const unit=json(dir+'/unit-formal65-r1.json');
assert.equal(unit.numPassedTests,2138);assert.equal(unit.success,true);assert.equal(unit.numFailedTests+unit.numPendingTests,0);
const browser={};for(const [run,count] of [['formal65-r2',24],['regression65-r4',21]]){const p=dir+'/browser-'+run+'.json',b=json(p);assert.equal(b.stats.expected,count);assert.equal(b.stats.unexpected+b.stats.skipped+b.stats.flaky,0);assert.deepEqual(b.errors,[]);browser[run]={...proof(p),stats:b.stats};}
const quality=json(dir+'/quality-r7.json');assert.deepEqual(Object.values(quality).sort(),[0,0,0]);
const regPath='content/c/p0/blockly-release-1.0.65.json',release=json(regPath);assert.equal(release.releaseVersion,'1.0.65');assert.equal(release.files.length,451);assert.equal(release.aiGateway.taskAccepted,false);for(const f of release.files)assert.equal(sha(read(f.path)),f.sha256,'Current source '+f.path);for(const e of Object.values(release.evidence))assert.equal(sha(read(e.path)),e.sha256);
const frozen=json(dir+'/sources-65/index.json');assert.equal(frozen.files.length,451);for(const f of frozen.files)assert.equal(sha(gunzipSync(read(dir+'/sources-65/'+f.file))),f.sha256);
assert.equal(sha(read(release.aiGateway.executable.path)),release.aiGateway.executable.sha256);
const facts=json(dir+'/formal-facts-validation.json');assert.equal(facts.actualRustContextsValidated,15);assert.equal(facts.distinctAuthoredCSources,3);assert.equal(facts.officialModelCalls,0);
const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(d+'/'+e.name):[d+'/'+e.name]);
const nativePath=walk(dir+'/browser-formal65-r2-output').find(p=>p.endsWith('/native-db9-before-after.json'));assert.ok(nativePath);const native=json(nativePath);assert.deepEqual(native.before,native.after);const db=native.before.databases['c-viz-learning'];assert.equal(db.version,9);assert.equal(db.names.length,17);assert.ok(!JSON.stringify(native).includes('DESIGN_ONLY_NOT_A_REAL_KEY'));
const protection=json(dir+'/protection-final.json');assert.equal(protection.oldArchives,7094);assert.equal(protection.oldOriginals,7090);assert.equal(protection.old19FrozenFiles,89);assert.equal(protection.otherOwnerProtected,17);assert.equal(protection.git.stage,'');
const docs=['项目文档/交付/19.4-API调试助手运行与安全设置.md','项目文档/验收/19.4-独立工程验证与真实API缺口.md','项目文档/交接/19.4-独立工程交接.md'];
const baseline=new Map(json(dir+'/baseline.json').files.map(f=>[f.path,f]));
const newPaths=[...release.files.map(f=>f.path).filter(p=>!baseline.has(p)),'scripts/register-ai-debug-65.mjs','tests/ai-debug.config.ts','tests/ai-regression.config.ts',...walk('tests/ai-browser'),...walk('tests/ai-regression'),...walk('tests/unit').filter(p=>/ai-debug/.test(p)),...docs,regPath,'项目文档/验收/发布凭据/19.4-1.0.65/index.json'];
save(dir+'/changed-files.json',{modifiedBaselineFiles:protection.changed,newPrimaryFiles:[...new Set(newPaths)].filter(existsSync).map(proof),allProductInputs:proof(regPath),rawQaArchiveWillIncludeAllTaskRounds:true});
save(dir+'/engineering-final.json',{
 task:'19.4',date:'2026-11-01',independentEngineeringComplete:true,taskAccepted:false,officialCredentialVerifications:0,officialModelCalls:0,
 counts:{original:'82/88',main:'82/98',P2:'13/19',step19:'3/5',P05:'9/9',step21:'0/10'},
 release:{...proof(regPath),version:'1.0.65',sources:451,frozenSources:451,executable:release.aiGateway.executable},
 quality:{...proof(dir+'/quality-r7.json'),checks:quality},frontend:{...proof(dir+'/unit-formal65-r1.json'),passed:2138,files:106},
 browser,originalFacts:{...proof(dir+'/formal-facts-validation.json'),...facts},nativeStorage:{...proof(nativePath),schema:'9.0.0',db:9,stores:17,rawRowsAndKeysAndAllLocalAndSessionEqual:true},
 separateRust:{passed:12,tests:proof(dir+'/rust-test-final.log'),clippy:proof(dir+'/rust-clippy-final.log'),releaseBuild:proof(dir+'/gateway-build-final.log')},
 inheritedInterpreterRust:{passed:549,originalIgnored:1,rerunThisTask:false,unchangedFiveWasmAndRootWorkspaceVerified:true},
 productionBuild:proof(dir+'/build-formal65-r1.log'),nativeLauncher:proof(dir+'/production-startup.json'),inspector:{...proof(dir+'/design/inspector-r1/report.json'),failures:0,warnings:2},
 protection:proof(dir+'/protection-final.json'),changedFiles:proof(dir+'/changed-files.json'),
 pending:['Valid own-Key official models verification','Real pointer, loop and no-trace successful official API answers and original fact references','Actual provider cost, retention, logging and cancellation observations'],
 notStarted:['19.5','remote HTTPS deployment','new-feature Edge and Firefox browser matrix'],
 processDisposition:{currentSettingsUrl:'http://127.0.0.1:4196/#/settings?panel=ai',retainedOriginalNativeGateway:true,operatingSystemService:false,additionalBackgroundGatewayStarted:false,combinedTransitionRejected:proof(dir+'/process-transition-rejected.json'),activeLogExcludedFromImmutableRawPaths:dir+'/start-native-4196.log',immutableStartupSnapshot:proof(dir+'/production-startup-log.snapshot.txt')},
 git:protection.git,failuresPreserved:true,completedTaskCountsIncreased:false,docs:docs.map(proof),
});
console.log(JSON.stringify({independentEngineeringComplete:true,taskAccepted:false,release:'1.0.65',sources:451,frontend:2138,formalChrome:24,currentRegressionChrome:21,proxyRust:12,officialModelCalls:0}));
