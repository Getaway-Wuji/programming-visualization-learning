import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { aiDebugPaths } from '../../scripts/ai-debug-release-inputs.mjs';
for (const path of ['README.md', '项目守则.md', '项目文档/任务进度与交接.md', '项目文档/开发路线与依赖.md', '项目文档/需求覆盖与范围裁决.md']) {
  assert.ok(!aiDebugPaths.includes(path));
  let text = readFileSync(path, 'utf8');
  if (text.includes('19.4独立工程交付（2026-11-01）')) continue;
  const relative = path.includes('/') ? './' : './项目文档/';
  const entry = `19.4独立工程交付（2026-11-01）：可选AI默认关闭、设置自备Key/每标签页临时内存、同源独立Rust生产网关、原Rust真实C事实的逐次预览/确认、引用导航及取消失效/固定降级已实现。正式1.0.65/451源（旧64/420冻结保持）；2138完整正式前端、独立网关12测试、正式Chrome24/24及当前回归21/21各自单轮、类型/lint/格式/构建通过，15原Rust包/上下文逐项核验、DB9全17store原始行/键及全部浏览器存储前后相等，六主题明暗/三宽已核。失败原件独立保留；官方验证/推理均0次，模拟不算真实AI，19.4仍待真实指针/循环/无轨迹API成功，数量不增：原82/88余6、主82/98、P2 13/19、第19为3/5、P0.5 9/9、21为0/10。19.5未开始；现在不索取Key，保留[运行与安全设置](${relative}交付/19.4-API调试助手运行与安全设置.md)、[工程验证及缺口](${relative}验收/19.4-独立工程验证与真实API缺口.md)、[独立交接](${relative}交接/19.4-独立工程交接.md)。7094旧归档/7090原路径、89旧19.3文件、17外窗及五WASM/SAVE9/DB9/原预算保持；无模型下载/安装、真实用户资料/其他应用秘密读取或Git写入。下方旧记录保留历史时点。`;
  const blank = /\r?\n\r?\n/.exec(text);
  assert.ok(blank && blank.index > 0);
  const first = blank.index + blank[0].length;
  text = text.slice(0, first) + entry + blank[0] + text.slice(first);
  if (path.endsWith('任务进度与交接.md')) {
    assert.match(text, /进行中（独立实现）/);
    text = text.replace('进行中（独立实现）', '进行中（独立工程完成，待真实API验收）');
    text = text.replace('依据API-Key2.0.0冻结范围，真实成功证据仍是门槛；不进入19.5。', '1.0.65/451源；工程验证齐备，官方调用0次；真实成功仍是门槛，完成计数不增，不进入19.5。');
  }
  writeFileSync(path, text);
}
console.log('Five central records updated; task acceptance counts unchanged.');
