# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: custom-code.spec.ts >> native DB1 through DB7 upgrades preserve old partitions and add the draft store
- Location: tests\browser\custom-code.spec.ts:255:1

# Error details

```
Error: page.goto: net::ERR_HTTP_RESPONSE_CODE_FAILURE at http://127.0.0.1:4194/checks/
Call log:
  - navigating to "http://127.0.0.1:4194/checks/", waiting until "load"

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - generic [ref=f2e6]:
    - heading "找不到 127.0.0.1 的网页" [level=1] [ref=f2e7]
    - paragraph [ref=f2e9]:
      - text: 找不到与以下网址对应的网页：
      - strong [ref=f2e10]: http://127.0.0.1:4194/checks/
    - generic [ref=f2e11]: HTTP ERROR 404
  - button "重新加载" [ref=f2e14] [cursor=pointer]
```

# Test source

```ts
  217 | }) => {
  218 |   await page.addInitScript(() => {
  219 |     const Native = window.Worker;
  220 |     const d = Object.getOwnPropertyDescriptor(Native.prototype, 'onmessage')!;
  221 |     (window as unknown as { qaHold: boolean; qaHeld: (() => void) | null }).qaHold = true;
  222 |     window.Worker = class extends Native {
  223 |       constructor(url: string | URL, options?: WorkerOptions) {
  224 |         super(url, options);
  225 |         Object.defineProperty(this, 'onmessage', {
  226 |           get: () => d.get!.call(this),
  227 |           set: (cb: ((e: MessageEvent) => void) | null) =>
  228 |             d.set!.call(
  229 |               this,
  230 |               cb &&
  231 |                 ((e: MessageEvent) => {
  232 |                   const qa = window as unknown as { qaHold: boolean; qaHeld: (() => void) | null };
  233 |                   if (e.data?.ok && qa.qaHold) {
  234 |                     qa.qaHold = false;
  235 |                     qa.qaHeld = () => cb(e);
  236 |                   } else cb(e);
  237 |                 }),
  238 |             ),
  239 |         });
  240 |       }
  241 |     };
  242 |   });
  243 |   await ready(page);
  244 |   await source(page, 'int main(){return 55;}');
  245 |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  246 |   await page.waitForFunction(() => Boolean((window as unknown as { qaHeld: unknown }).qaHeld));
  247 |   await page.getByRole('button', { name: '取消运行', exact: true }).click();
  248 |   await expect(page.getByTestId('custom-run-status')).toContainText('E_CANCELLED');
  249 |   await source(page, '#include <stdio.h>\nint main(){printf("fresh");return 0;}');
  250 |   await run(page);
  251 |   await end(page);
  252 |   await page.evaluate(() => (window as unknown as { qaHeld: () => void }).qaHeld());
  253 |   await expect(page.getByTestId('custom-output')).toHaveText('fresh');
  254 | });
  255 | test('native DB1 through DB7 upgrades preserve old partitions and add the draft store', async ({
  256 |   page,
  257 | }) => {
  258 |   await ready(page);
  259 |   const old = await rows(page);
  260 |   const name = 'c-viz-learning.test.custom-draft-migration';
  261 |   await page.route('**/qa-blank', (r) =>
  262 |     r.fulfill({ contentType: 'text/html', body: '<title>migration setup</title>' }),
  263 |   );
  264 |   for (const version of [1, 2, 3, 4, 5, 6, 7]) {
  265 |     await page.goto('/qa-blank');
  266 |     await page.evaluate(
  267 |       async ({ old, version, name }) => {
  268 |         const names = [
  269 |           'meta',
  270 |           'settings',
  271 |           'avatar',
  272 |           'progress',
  273 |           'dailyFacts',
  274 |           'goals',
  275 |           'ledger',
  276 |           'receipts',
  277 |           'aliases',
  278 |           ...(version >= 2 ? ['appearance', 'appearanceAssets'] : []),
  279 |           ...(version >= 3 ? ['editHistory'] : []),
  280 |           ...(version >= 4 ? ['knowledgeMarks'] : []),
  281 |           ...(version >= 5 ? ['reviewCards'] : []),
  282 |           ...(version >= 6 ? ['achievements'] : []),
  283 |         ];
  284 |         await new Promise<void>((resolve, reject) => {
  285 |           const r = indexedDB.deleteDatabase(name);
  286 |           r.onsuccess = () => resolve();
  287 |           r.onerror = () => reject(r.error);
  288 |           r.onblocked = () => reject(new Error('old connection not closed'));
  289 |         });
  290 |         await new Promise<void>((resolve, reject) => {
  291 |           const r = indexedDB.open(name, version);
  292 |           r.onupgradeneeded = () => {
  293 |             for (const name of names) {
  294 |               const store = r.result.createObjectStore(name);
  295 |               for (const row of old[name]) {
  296 |                 const data = row as Record<string, unknown>;
  297 |                 if (name === 'meta')
  298 |                   store.put(
  299 |                     { ...data, schemaVersion: version + '.0.0', dbVersion: version },
  300 |                     'current',
  301 |                   );
  302 |                 else if (['settings', 'avatar', 'appearance'].includes(name))
  303 |                   store.put(row, 'current');
  304 |                 else throw new Error('QA seed requires blank independent collections');
  305 |               }
  306 |             }
  307 |           };
  308 |           r.onsuccess = () => {
  309 |             r.result.close();
  310 |             resolve();
  311 |           };
  312 |           r.onerror = () => reject(r.error);
  313 |         });
  314 |       },
  315 |       { old, version, name },
  316 |     );
> 317 |     await page.goto('/checks/');
      |                ^ Error: page.goto: net::ERR_HTTP_RESPONSE_CODE_FAILURE at http://127.0.0.1:4194/checks/
  318 |     await page.waitForFunction(() => Boolean(window.historyHarness));
  319 |     await page.evaluate((name) => window.historyHarness.open(name), name);
  320 |     const after = await rows(page, name);
  321 |     expect(after.customDrafts).toEqual([]);
  322 |     for (const name of Object.keys(old).filter((n) => n !== 'meta' && n !== 'customDrafts'))
  323 |       expect(after[name], `v${version}/${name}`).toEqual(old[name]);
  324 |     expect(after.meta[0]).toMatchObject({
  325 |       schemaVersion: '9.0.0',
  326 |       dbVersion: 9,
  327 |       generation: (old.meta[0] as { generation: string }).generation,
  328 |     });
  329 |   }
  330 | });
  331 | 
  332 | test('real editor and result remain accessible at desktop, tablet and phone widths', async ({
  333 |   page,
  334 | }) => {
  335 |   await ready(page);
  336 |   await run(page);
  337 |   await end(page);
  338 |   for (const width of [1440, 768, 390]) {
  339 |     await page.setViewportSize({ width, height: 900 });
  340 |     if (width < 1000) {
  341 |       await page.getByRole('tab', { name: '执行观察', exact: true }).click();
  342 |     }
  343 |     await expect(page.getByTestId('custom-output')).toHaveText('14\n');
  344 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  345 |       true,
  346 |     );
  347 |     await page.screenshot({ path: `.artifacts/17.3/view-${width}-result.png`, fullPage: true });
  348 |     if (width < 1000) {
  349 |       await page.getByRole('tab', { name: '代码与输入', exact: true }).click();
  350 |       await page.screenshot({ path: `.artifacts/17.3/view-${width}-code.png`, fullPage: true });
  351 |     }
  352 |   }
  353 | });
  354 | 
  355 | test('oversized edits remain exact and unknown draft version is isolated without rewriting it', async ({
  356 |   page,
  357 | }) => {
  358 |   await ready(page);
  359 |   await source(page, 'int main(){return 1;}');
  360 |   await page.getByRole('button', { name: '保存草稿', exact: true }).click();
  361 |   await expect(page.getByTestId('custom-save-status')).toContainText('已保存');
  362 |   const large = 'x'.repeat(32769);
  363 |   await source(page, large);
  364 |   await expect(page.getByRole('textbox', { name: 'C 代码', exact: true })).toHaveValue(large);
  365 |   await expect(page.getByRole('button', { name: '运行代码', exact: true })).toBeDisabled();
  366 |   await expect(page.getByRole('button', { name: '保存草稿', exact: true })).toBeDisabled();
  367 |   await page.evaluate(async () => {
  368 |     const db = await new Promise<IDBDatabase>((resolve) => {
  369 |       const r = indexedDB.open('c-viz-learning');
  370 |       r.onsuccess = () => resolve(r.result);
  371 |     });
  372 |     await new Promise<void>((resolve) => {
  373 |       const tx = db.transaction('customDrafts', 'readwrite');
  374 |       const r = tx.objectStore('customDrafts').get('current');
  375 |       r.onsuccess = () =>
  376 |         tx.objectStore('customDrafts').put({ ...r.result, draftVersion: '2.0.0' }, 'current');
  377 |       tx.oncomplete = () => resolve();
  378 |     });
  379 |     db.close();
  380 |   });
  381 |   await page.reload();
  382 |   await expect(page.getByTestId('custom-save-status')).toContainText('无法读取草稿');
  383 |   await expect(page.getByRole('button', { name: '保存草稿', exact: true })).toBeDisabled();
  384 |   expect((await rows(page)).customDrafts[0]).toMatchObject({
  385 |     draftVersion: '2.0.0',
  386 |     source: 'int main(){return 1;}',
  387 |   });
  388 | });
  389 | 
  390 | test('real C struct uses an aggregate label and its exact fields share the memory cursor', async ({
  391 |   page,
  392 | }) => {
  393 |   await ready(page);
  394 |   await source(
  395 |     page,
  396 |     'struct Pair{int a;int b;};\nint main(){struct Pair pair={0};pair.a=7;pair.b=9;return 0;}',
  397 |   );
  398 |   await run(page);
  399 |   await end(page);
  400 |   await page.getByRole('button', { name: '后退', exact: true }).click();
  401 |   await expect(page.getByRole('region', { name: '基础视图', exact: true })).toContainText(
  402 |     '结构体，内存视图可查看字段',
  403 |   );
  404 |   await page.getByRole('button', { name: '内存视图', exact: true }).click();
  405 |   await expect(page.getByRole('cell', { name: '7', exact: true })).toBeVisible();
  406 |   await expect(page.getByRole('cell', { name: '9', exact: true })).toBeVisible();
  407 |   const cursor = await page.getByTestId('custom-code-page').getAttribute('data-cursor');
  408 |   await page.getByRole('button', { name: '调用栈视图', exact: true }).click();
  409 |   await expect(page.getByRole('region', { name: '调用栈视图', exact: true })).toContainText(
  410 |     '结构体，内存视图可查看字段',
  411 |   );
  412 |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-cursor', cursor!);
  413 | });
  414 | 
```