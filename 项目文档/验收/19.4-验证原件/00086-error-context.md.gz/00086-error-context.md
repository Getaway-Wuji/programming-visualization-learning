# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: themes.spec.ts >> 正式存储: six existing themes retain readable AI controls in light and dark modes
- Location: tests\ai-browser\themes.spec.ts:3:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByTestId('learning-save-status')
Expected: "ready"
Received: "unsaved"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" getByTestId('learning-save-status') with timeout 5000ms
  - waiting for getByTestId('learning-save-status')
    14 × locator resolved to <div data-save-status="unsaved" data-testid="learning-save-status">…</div>
       - unexpected value "unsaved"

```

```yaml
- alert:
  - heading "课程更新尚未就绪" [level=2]
  - paragraph: 当前课程版本尚未完成发布，暂不能保存新的学习结果。原学习档案已保留，无需清除数据或修改存储权限；更新可用后重新读取即可继续。
  - button "重新读取档案"
- paragraph: 当前处于临时模式。已保存的档案仍保留。请等待课程版本更新后再重试。
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import { evidence, instrumentation, settings } from './helpers';
  3  | test('正式存储: six existing themes retain readable AI controls in light and dark modes', async ({
  4  |   page,
  5  | }, info) => {
  6  |   const c = await instrumentation(page);
  7  |   await settings(page);
> 8  |   await expect(page.getByTestId('learning-save-status')).toHaveAttribute(
     |                                                          ^ Error: expect(locator).toHaveAttribute(expected) failed
  9  |     'data-save-status',
  10 |     'ready',
  11 |   );
  12 |   for (const preset of ['minimal', 'cute', 'glass', 'soft', 'cool', 'tech']) {
  13 |     await page.getByRole('tab', { name: '外观与主题', exact: true }).click();
  14 |     await page.getByTestId(`theme-${preset}`).click();
  15 |     await page.getByRole('tab', { name: 'AI解释（可选）', exact: true }).click();
  16 |     await expect(page.locator('html')).toHaveAttribute('data-appearance-preference', preset);
  17 |     for (const mode of ['light', 'dark']) {
  18 |       const current = await page.locator('html').getAttribute('data-theme');
  19 |       if (current !== mode) await page.getByTestId('theme-mode-toggle').click();
  20 |       await expect(page.locator('html')).toHaveAttribute('data-theme', mode);
  21 |       await expect(page.getByLabel('你自己的API Key', { exact: true })).toBeVisible();
  22 |       await expect(page.getByLabel('你自己的API Key', { exact: true })).toHaveAttribute(
  23 |         'type',
  24 |         'password',
  25 |       );
  26 |       await expect(page.getByRole('switch')).toBeEnabled();
  27 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  28 |         true,
  29 |       );
  30 |       await page.screenshot({ path: info.outputPath(`ai-${preset}-${mode}.png`), fullPage: true });
  31 |     }
  32 |   }
  33 |   expect(c.verifies).toBe(0);
  34 |   expect(c.requests).toHaveLength(0);
  35 |   await evidence(page, c, info);
  36 | });
  37 | 
```