import { defineConfig } from 'vitest/config';
export default defineConfig({ test: {
  include: ['.artifacts/19.4/verify-browser-facts.test.ts'],
  environment: 'node',
  reporters: ['default', 'json'],
  outputFile: { json: '.artifacts/19.4/facts-unit.json' },
} });
