import { test, expect } from 'vitest';
import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { decodeAdvancedResult, type AdvancedRequest } from '../../web/src/engine/advanced-protocol';
import { AdvancedPlayer } from '../../web/src/engine/advanced-player';
import { validateOriginal } from '../../web/src/ai-debug/context';
import { validateRequest, type AiRequest } from '../../web/src/ai-debug/protocol';
import { validateProjection } from '../../web/src/ai-debug/projection';

test('formal captured original Rust packets strictly validate every consented AI fact', async () => {
  const root = '.artifacts/19.4/browser-formal65-r1-output';
  const records: string[] = [];
  const walk = (dir: string) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = `${dir}/${entry.name}`;
      if (entry.isDirectory()) walk(path);
      else if (entry.name === 'actual-rust-and-simulated-api.json') records.push(path);
    }
  };
  walk(root);
  const sources = new Set<string>();
  let packets = 0, contexts = 0;
  const budgets: number[] = [];
  for (const path of records) {
    const record = JSON.parse(readFileSync(path, 'utf8')) as {
      workerPackets: { kind: string; raw: string; buildId?: string }[];
      aiRequests: AiRequest[];
      modelCalls: number;
    };
    expect(record.modelCalls).toBe(0);
    const requests = record.workerPackets.filter(p => p.kind === 'request');
    for (const ai of record.aiRequests) {
      const packet = requests.find(p => JSON.parse(p.raw).runId === ai.context.runRef.runId);
      expect(packet).toBeDefined();
      const request = JSON.parse(packet!.raw) as AdvancedRequest;
      const raw = record.workerPackets.find(p => p.kind === 'result' && JSON.parse(p.raw).identity?.runId === request.runId);
      expect(raw).toBeDefined();
      const buffer = new TextEncoder().encode(raw!.raw).buffer;
      const result = await decodeAdvancedResult(buffer, request, packet!.buildId!);
      packets++;
      const player = new AdvancedPlayer();
      player.accept(result);
      if (result.trace) expect(player.seek(ai.context.cursor!)).toBe(true);
      validateOriginal(ai.context, {
        source: request.source,
        inputRevision: ai.context.inputRevision,
        result,
        state: player.snapshot().state,
        cursor: ai.context.cursor ?? 0,
        selection: null,
      });
      validateRequest(ai);
      budgets.push(validateProjection(ai));
      contexts++;
      sources.add(request.source);
    }
  }
  expect(sources.size).toBeGreaterThanOrEqual(3);
  expect(contexts).toBeGreaterThanOrEqual(3);
  writeFileSync('.artifacts/19.4/formal-facts-validation.json', JSON.stringify({
    strictOriginalPacketsValidated: packets,
    actualRustContextsValidated: contexts,
    distinctAuthoredCSources: sources.size,
    providerBodyBytes: budgets,
    officialModelCalls: 0,
    simulatedAnswersAreNotAIQualityEvidence: true,
  }, null, 2) + '\n', { flag: 'wx' });
});
