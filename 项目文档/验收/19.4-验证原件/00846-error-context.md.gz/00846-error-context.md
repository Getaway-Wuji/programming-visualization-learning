# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-debug.spec.ts >> actual Rust loop, exact preview and simulated API references, never a real AI answer
- Location: tests\ai-browser\ai-debug.spec.ts:36:3

# Error details

```
Error: expect(received).toBeDefined()

Received: undefined
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - button "进入专注模式" [ref=e68] [cursor=pointer]:
          - generic [ref=e71]: 专注
        - generic [ref=e72]: 本地学习
        - link "本地数据" [ref=e73] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e77] [cursor=pointer]
    - main [ref=e80]:
      - generic [ref=e81]:
        - generic [ref=e82]:
          - paragraph [ref=e83]: 自由练习
          - heading "C 代码工作台" [level=1] [ref=e84]
          - paragraph [ref=e85]: 粘贴教学 C 程序，用真实执行观察变量、内存和调用栈。
        - generic [ref=e86]:
          - button "运行代码" [ref=e87] [cursor=pointer]
          - button "保存草稿" [ref=e88] [cursor=pointer]
          - status [ref=e89]: 有未保存的修改。
        - group [ref=e90]:
          - generic "支持范围与本地数据" [ref=e91] [cursor=pointer]
        - generic [ref=e92]:
          - generic [ref=e93]:
            - generic [ref=e94]: 拖动中间分隔条调整宽度
            - button "恢复默认比例" [disabled] [ref=e95] [cursor=pointer]
          - generic [ref=e96]:
            - region "代码与输入" [ref=e97]:
              - generic [ref=e98]:
                - generic [ref=e99]: 代码与输入
                - button "展开代码与输入" [ref=e100] [cursor=pointer]:
                  - generic [ref=e103]: 展开
              - generic [ref=e105]:
                - generic [ref=e106]:
                  - heading "C 源码" [level=2] [ref=e107]
                  - generic [ref=e108]:
                    - button "编辑代码" [ref=e109] [cursor=pointer]
                    - button "源码定位与断点" [pressed] [ref=e110] [cursor=pointer]
                - generic [ref=e111]:
                  - paragraph [ref=e112]: 点击行号设置断点；自动播放在该行步骤完成后暂停。
                  - paragraph [ref=e113]: 尚未设置断点。
                  - generic "源码与行断点" [ref=e114]:
                    - generic [ref=e115]:
                      - group "行断点" [ref=e116]:
                        - button "设置第 1 行断点" [ref=e117] [cursor=pointer]: · 1
                        - button "设置第 2 行断点" [ref=e118] [cursor=pointer]: · 2
                        - button "设置第 3 行断点" [disabled] [ref=e119]: · 3
                      - generic "本次执行的只读源码" [ref=e120]:
                        - text: "#include <stdio.h> int main(){int sum=0;for(int i=0;i<3;i"
                        - mark [ref=e121]: ++
                        - text: "){sum=sum+i;}printf(\"%d\",sum);return 0;}"
                - generic [ref=e122]:
                  - text: 整数输入
                  - textbox "整数输入" [ref=e123]: "7"
                - paragraph [ref=e124]: 按读取顺序提供，使用空格或逗号分隔。输入仅用于本次运行。
            - separator "调整面板宽度" [ref=e125]
            - region "执行观察" [ref=e127]:
              - generic [ref=e128]:
                - generic [ref=e129]: 执行观察
                - button "展开执行观察" [ref=e130] [cursor=pointer]:
                  - generic [ref=e133]: 展开
              - region "执行观察" [ref=e135]:
                - generic [ref=e136]:
                  - heading "执行观察" [level=2] [ref=e137]
                  - generic [ref=e138]: 等待运行
                - status [ref=e139]: 程序停止，查看下方诊断
                - alert [ref=e140]:
                  - strong [ref=e141]: E_UNSUPPORTED_SYNTAX
                  - paragraph [ref=e142]: 程序未能继续，请核对当前代码与支持范围。 第 2 行，第 39 列。
                  - button "定位错误源码" [ref=e143] [cursor=pointer]
                - generic [ref=e144]:
                  - button "后退" [disabled] [ref=e145]
                  - button "前进" [disabled] [ref=e146]
                  - button "播放" [disabled] [ref=e147]
                  - button "回到开头" [disabled] [ref=e148]
                  - generic [ref=e149]:
                    - text: 速度
                    - combobox "播放速度" [ref=e150]:
                      - option "0.25×"
                      - option "0.5×"
                      - option "1×" [selected]
                      - option "1.5×"
                      - option "2×"
                      - option "4×"
                - generic [ref=e151]:
                  - text: 步骤 0 / 0
                  - slider "执行步骤" [disabled] [ref=e152]: "0"
                - paragraph [ref=e153]: 当前定位：第 2 行。
                - group "选择执行视图" [ref=e154]:
                  - button "基础视图" [pressed] [ref=e155] [cursor=pointer]
                  - button "内存视图" [ref=e156] [cursor=pointer]
                  - button "调用栈视图" [ref=e157] [cursor=pointer]
                - paragraph [ref=e158]: 暂无执行状态。运行支持范围内的程序后查看。
                - region [ref=e159]:
                  - generic [ref=e160]:
                    - heading "AI解释（可选）" [level=3] [ref=e161]
                    - button "预览本次AI请求" [ref=e162] [cursor=pointer]
                  - generic "AI解释与真实事实" [ref=e163]:
                    - heading "真实Rust事实" [level=4] [ref=e164]
                    - list [ref=e165]:
                      - listitem [ref=e166]: 本次运行诊断：E_UNSUPPORTED_SYNTAX
                    - heading "AI解释" [level=4] [ref=e167]
                    - paragraph [ref=e168]: 模拟返回，仅验证接口与引用；不是实际模型解释。
                    - generic [ref=e169]:
                      - paragraph [ref=e170]: 此处只验证已提供事实的定位能力，不代表AI质量验收。
                      - button "查看真实诊断源码" [ref=e172] [cursor=pointer]
                    - heading "AI建议（未经执行验证）" [level=4] [ref=e173]
                    - list [ref=e174]:
                      - listitem [ref=e175]: 模拟建议，未经执行验证。
                    - paragraph [ref=e176]: 本测试没有调用官方API。
                    - paragraph [ref=e177]: 服务：openai，返回模型：gpt-5.4-mini-2026-03-17。AI文字不改变实际执行与学习判定。
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import {
  3   |   enable,
  4   |   evidence,
  5   |   instrumentation,
  6   |   native,
  7   |   preview,
  8   |   send,
  9   |   settings,
  10  |   workbench,
  11  | } from './helpers';
  12  | const sources = {
  13  |   pointer:
  14  |     '#include <stdio.h>\nint main(){int *p=0;int value=*p;printf("%d\\n",value);return 0;}\n',
  15  |   loop: '#include <stdio.h>\nint main(){int sum=0;for(int i=0;i<3;i++){sum=sum+i;}printf("%d",sum);return 0;}\n',
  16  |   syntax: 'int main( { return 0; }',
  17  | };
  18  | test('default off and missing Key make no verification/inference request; ordinary C remains usable', async ({
  19  |   page,
  20  | }, info) => {
  21  |   const c = await instrumentation(page);
  22  |   await settings(page);
  23  |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  24  |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  25  |   await page.getByRole('switch').click();
  26  |   await expect(page.getByRole('alert')).toContainText('请选择');
  27  |   expect(c.verifies).toBe(0);
  28  |   await page.getByRole('link', { name: 'C 代码工作台', exact: true }).click();
  29  |   await page.getByRole('textbox', { name: 'C 代码', exact: true }).fill(sources.loop);
  30  |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  31  |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  32  |   expect(c.requests).toHaveLength(0);
  33  |   await evidence(page, c, info);
  34  | });
  35  | for (const kind of ['pointer', 'loop', 'syntax'] as const)
  36  |   test(`actual Rust ${kind}, exact preview and simulated API references, never a real AI answer`, async ({
  37  |     page,
  38  |   }, info) => {
  39  |     const c = await instrumentation(page);
  40  |     await enable(page);
  41  |     await workbench(page, sources[kind]);
  42  |     await preview(page);
  43  |     expect(c.requests).toHaveLength(0);
  44  |     if (kind === 'syntax')
  45  |       await expect(page.getByText('本次语法或前置检查没有轨迹', { exact: false })).toBeVisible();
  46  |     await page.getByRole('button', { name: '确认并发送本次内容', exact: true }).click();
  47  |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toBeVisible();
  48  |     expect(c.requests).toHaveLength(1);
  49  |     const req = c.requests[0];
  50  |     expect(req.context.runRef.language).toBe('c');
  51  |     expect(req.context.snippets.map((s) => s.text).join('')).toContain(
  52  |       kind === 'syntax' ? 'int main' : 'int main',
  53  |     );
  54  |     expect(req.context.facts.length).toBeGreaterThan(0);
  55  |     if (kind === 'syntax') {
  56  |       expect(req.context.traceAvailable).toBe(false);
  57  |       expect(req.context.facts.every((f) => f.kind === 'diagnostic')).toBe(true);
  58  |       await expect(page.getByRole('button', { name: /查看真实步骤/ })).toHaveCount(0);
  59  |       await page.getByRole('button', { name: '查看真实诊断源码', exact: true }).click();
  60  |       await expect(page.getByRole('textbox', { name: 'C 代码', exact: true })).toBeFocused();
  61  |     } else {
  62  |       const step = req.context.facts.find((f) => f.kind === 'step');
> 63  |       expect(step).toBeDefined();
      |                    ^ Error: expect(received).toBeDefined()
  64  |       if (step?.kind === 'step') {
  65  |         await page.getByRole('button', { name: `查看真实步骤 ${step.step}`, exact: true }).click();
  66  |         await expect(page.getByTestId('custom-code-page')).toHaveAttribute(
  67  |           'data-cursor',
  68  |           String(step.step),
  69  |         );
  70  |       }
  71  |     }
  72  |     await evidence(page, c, info);
  73  |   });
  74  | for (const mode of ['auth', 'quota', 'rate', 'badref', 'stale', 'blank'] as const)
  75  |   test(`simulated ${mode} failure has fixed fallback and real execution still works`, async ({
  76  |     page,
  77  |   }, info) => {
  78  |     const c = await instrumentation(page);
  79  |     await enable(page, 'deepseek');
  80  |     await workbench(page, sources.pointer);
  81  |     c.mode = mode;
  82  |     await send(page);
  83  |     await expect(page.locator('.ai-panel [role=alert]')).toBeVisible();
  84  |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  85  |     await page.getByRole('button', { name: '运行代码', exact: true }).click();
  86  |     await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  87  |     expect(c.requests).toHaveLength(1);
  88  |     await evidence(page, c, info);
  89  |   });
  90  | test('simulated HTML answer is plain text and never loads an image or URL', async ({
  91  |   page,
  92  | }, info) => {
  93  |   const c = await instrumentation(page);
  94  |   await enable(page);
  95  |   await workbench(page, sources.loop);
  96  |   c.mode = 'html';
  97  |   await send(page);
  98  |   await expect(page.locator('.ai-answer')).toContainText('<img src=');
  99  |   await expect(page.locator('.ai-answer img')).toHaveCount(0);
  100 |   await evidence(page, c, info);
  101 | });
  102 | for (const action of ['cancel', 'source', 'input', 'cursor'] as const)
  103 |   test(`${action} invalidates an in-flight simulated answer`, async ({ page }, info) => {
  104 |     const c = await instrumentation(page);
  105 |     await enable(page);
  106 |     await workbench(page, sources.loop);
  107 |     c.mode = 'delay';
  108 |     c.delay = 700;
  109 |     await send(page);
  110 |     await expect(page.getByText('正在等待OpenAI解释', { exact: false })).toBeVisible();
  111 |     if (action === 'cancel')
  112 |       await page.getByRole('button', { name: '取消本端等待', exact: true }).click();
  113 |     else if (action === 'source') {
  114 |       await page.getByRole('button', { name: '编辑代码', exact: true }).click();
  115 |       await page
  116 |         .getByRole('textbox', { name: 'C 代码', exact: true })
  117 |         .fill('int main(){return 0;}');
  118 |     } else if (action === 'input')
  119 |       await page.getByRole('textbox', { name: '整数输入', exact: true }).fill('8');
  120 |     else await page.getByRole('button', { name: '后退', exact: true }).click();
  121 |     await expect(page.getByRole('heading', { name: '确认本次发送内容', exact: true })).toHaveCount(
  122 |       0,
  123 |     );
  124 |     await page.waitForTimeout(800);
  125 |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  126 |     await evidence(page, c, info);
  127 |   });
  128 | test('refresh and leaving the workbench discard all AI configuration', async ({ page }, info) => {
  129 |   const c = await instrumentation(page);
  130 |   await enable(page);
  131 |   await workbench(page, sources.loop);
  132 |   await page.getByRole('link', { name: '本地设置', exact: true }).click();
  133 |   await page.getByRole('button', { name: 'AI解释（可选）', exact: true }).click();
  134 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  135 |   await enable(page);
  136 |   await page.reload();
  137 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  138 |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  139 |   await evidence(page, c, info);
  140 | });
  141 | test('正式存储: AI configuration, real execution, simulated explanation and close preserve native DB9 rows/keys and all browser storage', async ({
  142 |   page,
  143 | }, info) => {
  144 |   const c = await instrumentation(page);
  145 |   await settings(page);
  146 |   await expect(page.getByTestId('learning-save-status')).toHaveAttribute(
  147 |     'data-save-status',
  148 |     'ready',
  149 |   );
  150 |   const before = await native(page);
  151 |   const db = before.databases['c-viz-learning'] as { version: number; names: string[] };
  152 |   expect(db.version).toBe(9);
  153 |   expect(db.names).toHaveLength(17);
  154 |   await enable(page);
  155 |   await workbench(page, sources.loop);
  156 |   await send(page);
  157 |   await expect(page.locator('.ai-answer')).toBeVisible();
  158 |   await page.getByRole('link', { name: '本地设置', exact: true }).click();
  159 |   await page.getByRole('button', { name: 'AI解释（可选）', exact: true }).click();
  160 |   const after = await native(page);
  161 |   expect(after).toEqual(before);
  162 |   await evidence(page, c, info);
  163 | });
```