# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-debug.spec.ts >> refresh and leaving the workbench discard all AI configuration
- Location: tests\ai-browser\ai-debug.spec.ts:128:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'AI解释（可选）', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - generic [ref=e68]: 本地学习
        - link "本地数据" [ref=e69] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e73] [cursor=pointer]
    - main [ref=e76]:
      - generic [ref=e77]:
        - navigation "当前位置" [ref=e78]:
          - list [ref=e79]:
            - listitem [ref=e80]:
              - link "学习首页" [ref=e81] [cursor=pointer]:
                - /url: "#/"
            - listitem [ref=e82]:
              - generic [ref=e85]: 本地设置
        - generic [ref=e86]:
          - paragraph [ref=e87]: 你的浏览器，你的学习空间
          - heading "本地设置" [active] [level=1] [ref=e88]
          - paragraph [ref=e89]: 学习档案保存在当前浏览器，不跨设备同步。存储不可用时仅临时使用，未保存内容会在关闭或刷新后丢失。
        - generic [ref=e90]:
          - alert [ref=e91]:
            - generic [ref=e95]:
              - heading "课程更新尚未就绪" [level=2] [ref=e96]
              - paragraph [ref=e97]: 当前课程版本尚未完成发布，暂不能保存新的学习结果。原学习档案已保留，无需清除数据或修改存储权限；更新可用后重新读取即可继续。
              - button "重新读取档案" [ref=e99] [cursor=pointer]
          - paragraph [ref=e100]: 当前处于临时模式。已保存的档案仍保留。请等待课程版本更新后再重试。
        - generic [ref=e101]:
          - tablist "设置分类" [ref=e102]:
            - tab "外观与主题" [selected] [ref=e103] [cursor=pointer]
            - tab "基础形象" [ref=e106] [cursor=pointer]
            - tab "显示设置" [ref=e109] [cursor=pointer]
            - tab "AI解释（可选）" [ref=e112] [cursor=pointer]
            - tab "本地数据" [ref=e115] [cursor=pointer]
          - tabpanel "外观与主题" [ref=e118]:
            - generic [ref=e119]:
              - generic [ref=e120]:
                - generic [ref=e121]:
                  - heading "外观与主题" [level=2] [ref=e122]
                  - paragraph [ref=e123]: 选择喜欢的界面风格，积木也会同步换肤。
                - generic [ref=e124]: 当前已保存外观
              - group "选择界面主题" [ref=e125]:
                - button "清爽 · 代码学园 清楚的纸面与课程层次" [pressed] [ref=e126] [cursor=pointer]:
                  - emphasis [ref=e130]
                  - strong [ref=e131]: 清爽 · 代码学园
                  - generic [ref=e132]: 清楚的纸面与课程层次
                - button "粉晶 · 流体花园 晶亮窗口与柔软回弹" [ref=e133] [cursor=pointer]:
                  - emphasis [ref=e137]
                  - strong [ref=e138]: 粉晶 · 流体花园
                  - generic [ref=e139]: 晶亮窗口与柔软回弹
                - button "珍珠 · 磨砂书桌 珍珠磨砂与分层桌面" [ref=e140] [cursor=pointer]:
                  - emphasis [ref=e144]
                  - strong [ref=e145]: 珍珠 · 磨砂书桌
                  - generic [ref=e146]: 珍珠磨砂与分层桌面
                - button "暖光 · 触感工坊 同色浮雕与按压触感" [ref=e147] [cursor=pointer]:
                  - emphasis [ref=e151]
                  - strong [ref=e152]: 暖光 · 触感工坊
                  - generic [ref=e153]: 同色浮雕与按压触感
                - button "深蓝 · 流光空间 深蓝玻璃与局部流光" [ref=e154] [cursor=pointer]:
                  - emphasis [ref=e158]
                  - strong [ref=e159]: 深蓝 · 流光空间
                  - generic [ref=e160]: 深蓝玻璃与局部流光
                - button "轻雾 · 灵感实验室 浅雾浮雕与安静轨道" [ref=e161] [cursor=pointer]:
                  - emphasis [ref=e165]
                  - strong [ref=e166]: 轻雾 · 灵感实验室
                  - generic [ref=e167]: 浅雾浮雕与安静轨道
              - generic [ref=e168]:
                - button "保存外观" [disabled] [ref=e169]
                - button "恢复全部外观默认" [ref=e170] [cursor=pointer]
```

# Test source

```ts
  33  |   await evidence(page, c, info);
  34  | });
  35  | for (const kind of ['pointer', 'loop', 'syntax'] as const)
  36  |   test(`actual Rust ${kind}, exact preview and simulated API references, never a real AI answer`, async ({
  37  |     page,
  38  |   }, info) => {
  39  |     const c = await instrumentation(page);
  40  |     await enable(page);
  41  |     await workbench(page, sources[kind]);
  42  |     await preview(page);
  43  |     expect(c.requests).toHaveLength(0);
  44  |     if (kind === 'syntax')
  45  |       await expect(page.getByText('本次语法或前置检查没有轨迹', { exact: false })).toBeVisible();
  46  |     await page.getByRole('button', { name: '确认并发送本次内容', exact: true }).click();
  47  |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toBeVisible();
  48  |     expect(c.requests).toHaveLength(1);
  49  |     const req = c.requests[0];
  50  |     expect(req.context.runRef.language).toBe('c');
  51  |     expect(req.context.snippets.map((s) => s.text).join('')).toContain(
  52  |       kind === 'syntax' ? 'int main' : 'int main',
  53  |     );
  54  |     expect(req.context.facts.length).toBeGreaterThan(0);
  55  |     if (kind === 'syntax') {
  56  |       expect(req.context.traceAvailable).toBe(false);
  57  |       expect(req.context.facts.every((f) => f.kind === 'diagnostic')).toBe(true);
  58  |       await expect(page.getByRole('button', { name: /查看真实步骤/ })).toHaveCount(0);
  59  |       await page.getByRole('button', { name: '查看真实诊断源码', exact: true }).click();
  60  |       await expect(page.getByRole('textbox', { name: 'C 代码', exact: true })).toBeFocused();
  61  |     } else {
  62  |       const step = req.context.facts.find((f) => f.kind === 'step');
  63  |       expect(step).toBeDefined();
  64  |       if (step?.kind === 'step') {
  65  |         await page.getByRole('button', { name: `查看真实步骤 ${step.step}`, exact: true }).click();
  66  |         await expect(page.getByTestId('custom-code-page')).toHaveAttribute(
  67  |           'data-cursor',
  68  |           String(step.step),
  69  |         );
  70  |       }
  71  |     }
  72  |     await evidence(page, c, info);
  73  |   });
  74  | for (const mode of ['auth', 'quota', 'rate', 'badref', 'stale', 'blank'] as const)
  75  |   test(`simulated ${mode} failure has fixed fallback and real execution still works`, async ({
  76  |     page,
  77  |   }, info) => {
  78  |     const c = await instrumentation(page);
  79  |     await enable(page, 'deepseek');
  80  |     await workbench(page, sources.pointer);
  81  |     c.mode = mode;
  82  |     await send(page);
  83  |     await expect(page.locator('.ai-panel [role=alert]')).toBeVisible();
  84  |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  85  |     await page.getByRole('button', { name: '运行代码', exact: true }).click();
  86  |     await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  87  |     expect(c.requests).toHaveLength(1);
  88  |     await evidence(page, c, info);
  89  |   });
  90  | test('simulated HTML answer is plain text and never loads an image or URL', async ({
  91  |   page,
  92  | }, info) => {
  93  |   const c = await instrumentation(page);
  94  |   await enable(page);
  95  |   await workbench(page, sources.loop);
  96  |   c.mode = 'html';
  97  |   await send(page);
  98  |   await expect(page.locator('.ai-answer')).toContainText('<img src=');
  99  |   await expect(page.locator('.ai-answer img')).toHaveCount(0);
  100 |   await evidence(page, c, info);
  101 | });
  102 | for (const action of ['cancel', 'source', 'input', 'cursor'] as const)
  103 |   test(`${action} invalidates an in-flight simulated answer`, async ({ page }, info) => {
  104 |     const c = await instrumentation(page);
  105 |     await enable(page);
  106 |     await workbench(page, sources.loop);
  107 |     c.mode = 'delay';
  108 |     c.delay = 700;
  109 |     await send(page);
  110 |     await expect(page.getByText('正在等待OpenAI解释', { exact: false })).toBeVisible();
  111 |     if (action === 'cancel')
  112 |       await page.getByRole('button', { name: '取消本端等待', exact: true }).click();
  113 |     else if (action === 'source') {
  114 |       await page.getByRole('button', { name: '编辑代码', exact: true }).click();
  115 |       await page
  116 |         .getByRole('textbox', { name: 'C 代码', exact: true })
  117 |         .fill('int main(){return 0;}');
  118 |     } else if (action === 'input')
  119 |       await page.getByRole('textbox', { name: '整数输入', exact: true }).fill('8');
  120 |     else await page.getByRole('button', { name: '后退', exact: true }).click();
  121 |     await expect(page.getByRole('heading', { name: '确认本次发送内容', exact: true })).toHaveCount(
  122 |       0,
  123 |     );
  124 |     await page.waitForTimeout(800);
  125 |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  126 |     await evidence(page, c, info);
  127 |   });
  128 | test('refresh and leaving the workbench discard all AI configuration', async ({ page }, info) => {
  129 |   const c = await instrumentation(page);
  130 |   await enable(page);
  131 |   await workbench(page, sources.loop);
  132 |   await page.getByRole('link', { name: '本地设置', exact: true }).click();
> 133 |   await page.getByRole('button', { name: 'AI解释（可选）', exact: true }).click();
      |                                                                     ^ Error: locator.click: Test timeout of 30000ms exceeded.
  134 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  135 |   await enable(page);
  136 |   await page.reload();
  137 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  138 |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  139 |   await evidence(page, c, info);
  140 | });
  141 | test('正式存储: AI configuration, real execution, simulated explanation and close preserve native DB9 rows/keys and all browser storage', async ({
  142 |   page,
  143 | }, info) => {
  144 |   const c = await instrumentation(page);
  145 |   await settings(page);
  146 |   await expect(page.getByTestId('learning-save-status')).toHaveAttribute(
  147 |     'data-save-status',
  148 |     'ready',
  149 |   );
  150 |   const before = await native(page);
  151 |   const db = before.databases['c-viz-learning'] as { version: number; names: string[] };
  152 |   expect(db.version).toBe(9);
  153 |   expect(db.names).toHaveLength(17);
  154 |   await enable(page);
  155 |   await workbench(page, sources.loop);
  156 |   await send(page);
  157 |   await expect(page.locator('.ai-answer')).toBeVisible();
  158 |   await page.getByRole('link', { name: '本地设置', exact: true }).click();
  159 |   await page.getByRole('button', { name: 'AI解释（可选）', exact: true }).click();
  160 |   const after = await native(page);
  161 |   expect(after).toEqual(before);
  162 |   await evidence(page, c, info);
  163 | });
  164 | test('正式存储: two tabs never share Key, and clearing learning data in another tab closes the configured tab', async ({
  165 |   page,
  166 |   context,
  167 | }, info) => {
  168 |   const c = await instrumentation(page);
  169 |   await enable(page);
  170 |   const second = await context.newPage();
  171 |   await instrumentation(second);
  172 |   await settings(second);
  173 |   await expect(second.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  174 |   await expect(second.getByLabel('你自己的API Key', { exact: true })).toHaveValue('');
  175 |   await second.getByRole('button', { name: '本地数据', exact: true }).click();
  176 |   await second.getByRole('button', { name: '清除本地数据', exact: true }).click();
  177 |   await second.getByRole('button', { name: '确认清除', exact: true }).click();
  178 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  179 |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  180 |   await evidence(page, c, info);
  181 | });
  182 | for (const width of [1440, 768, 390])
  183 |   test(`AI settings keyboard and layout at ${width}px`, async ({ page }, info) => {
  184 |     const c = await instrumentation(page);
  185 |     await page.setViewportSize({ width, height: 900 });
  186 |     await settings(page);
  187 |     await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toBeVisible();
  188 |     await page.getByRole('combobox', { name: 'AI服务', exact: true }).focus();
  189 |     await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toBeFocused();
  190 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  191 |       true,
  192 |     );
  193 |     await page.screenshot({ path: info.outputPath(`settings-${width}.png`), fullPage: true });
  194 |     await evidence(page, c, info);
  195 |   });
  196 | 
```