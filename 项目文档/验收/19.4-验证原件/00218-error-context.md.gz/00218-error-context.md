# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-regression\current-nav.spec.ts >> a real static deployment without the AI gateway fails before forwarding a Key and ordinary Rust C still runs
- Location: tests\ai-regression\current-nav.spec.ts:73:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByLabel('模型', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - generic [ref=e68]: 本地学习
        - link "本地数据" [ref=e69] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e73] [cursor=pointer]
    - main [ref=e76]:
      - generic [ref=e77]:
        - navigation "当前位置" [ref=e78]:
          - list [ref=e79]:
            - listitem [ref=e80]:
              - link "学习首页" [ref=e81] [cursor=pointer]:
                - /url: "#/"
            - listitem [ref=e82]:
              - generic [ref=e85]: 本地设置
        - generic [ref=e86]:
          - paragraph [ref=e87]: 你的浏览器，你的学习空间
          - heading "本地设置" [level=1] [ref=e88]
          - paragraph [ref=e89]: 学习档案保存在当前浏览器，不跨设备同步。存储不可用时仅临时使用，未保存内容会在关闭或刷新后丢失。
        - status [ref=e91]:
          - generic [ref=e95]:
            - heading "本地档案已读取" [level=2] [ref=e96]
            - paragraph [ref=e97]: 正在显示当前浏览器中已保存的记录与设置。
        - generic [ref=e98]:
          - tablist "设置分类" [ref=e99]:
            - tab "外观与主题" [ref=e100] [cursor=pointer]
            - tab "基础形象" [ref=e103] [cursor=pointer]
            - tab "显示设置" [ref=e106] [cursor=pointer]
            - tab "AI解释（可选）" [selected] [ref=e109] [cursor=pointer]
            - tab "本地数据" [ref=e112] [cursor=pointer]
          - tabpanel "AI解释（可选）" [ref=e115]:
            - region [ref=e116]:
              - generic [ref=e117]:
                - generic [ref=e118]:
                  - heading "AI解释（可选）" [level=2] [ref=e119]
                  - paragraph [ref=e120]: 默认关闭。只在当前标签页临时启用，刷新或退出工作台后关闭；正常学习无需开启。
                - status [ref=e121]: 未开启
              - generic [ref=e122]:
                - generic [ref=e123]:
                  - generic [ref=e124]: AI服务
                  - combobox "AI服务" [ref=e125]:
                    - option "请选择服务"
                    - option "OpenAI 官方API" [selected]
                    - option "DeepSeek 官方API"
                - generic [ref=e126]:
                  - generic [ref=e127]: 模型
                  - combobox "AI模型" [ref=e128]:
                    - option "请选择模型" [selected]
                    - option "gpt-5.4-mini-2026-03-17"
                - generic [ref=e129]:
                  - generic [ref=e130]: 你自己的API Key
                  - textbox "你自己的API Key" [ref=e131]
                - paragraph [ref=e132]: 验证会经本平台同源转发，把Key发送到 api.openai.com 的模型列表接口，不发送代码，也不调用推理。平台转发方会接触当次Key；Key不会保存到学习档案。
                - generic [ref=e133]:
                  - paragraph [ref=e134]: 默认滥用监测可保留内容至30天，另有法律、安全和缓存例外；本平台不承诺服务方零保留。
                  - paragraph [ref=e135]: 解释请求的费用由Key账户承担；取消本端等待不保证服务方停止或免收费。验证通过不保证推理权限或额度。
                  - link "OpenAI官方价格" [ref=e136] [cursor=pointer]:
                    - /url: https://developers.openai.com/api/docs/pricing
                  - text: ·
                  - link "数据与保留政策" [ref=e137] [cursor=pointer]:
                    - /url: https://developers.openai.com/api/docs/guides/your-data
                - generic [ref=e138]:
                  - switch "验证并开启AI解释" [ref=e139] [cursor=pointer]
                  - button "清除AI配置" [ref=e140] [cursor=pointer]
              - paragraph [ref=e141]: 关闭、刷新、离开工作台或清除学习数据会丢弃Key。每次发送代码前另行预览确认；此处不会自动请求解释。
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import { native } from '../ai-browser/helpers';
  3  | 
  4  | test('current ten navigation entries and original workbench width/collapse behavior at four desktop widths', async ({
  5  |   page,
  6  | }, info) => {
  7  |   await page.goto('/#/practice/exercise.c.echo');
  8  |   await expect(page.getByTestId('practice-execution')).toHaveAttribute('data-state', 'ready');
  9  |   const before = await native(page);
  10 |   const samples = [];
  11 |   for (const width of [1366, 1440, 1920, 2560]) {
  12 |     await page.setViewportSize({ width, height: 900 });
  13 |     const bench = page.locator('[data-testid="workbench"][data-kind="practice"]');
  14 |     const geometry = () =>
  15 |       bench.evaluate((element) => {
  16 |         const box = (node: Element) => {
  17 |           const { x, width, right } = node.getBoundingClientRect();
  18 |           return { x, width, right };
  19 |         };
  20 |         return {
  21 |           sidebar: box(document.querySelector('.sidebar')!),
  22 |           main: box(document.querySelector('.main-content')!),
  23 |           bench: box(element),
  24 |           first: box(element.querySelector('[data-testid="workbench-first"]')!),
  25 |           second: box(element.querySelector('[data-testid="workbench-second"]')!),
  26 |         };
  27 |       });
  28 |     await expect(page.getByRole('button', { name: '收起侧栏', exact: true })).toBeVisible();
  29 |     const expanded = await geometry();
  30 |     expect(expanded.sidebar.x).toBeCloseTo(0, 0);
  31 |     expect(expanded.sidebar.width).toBeCloseTo(216, 0);
  32 |     expect(expanded.main.right).toBeCloseTo(width, 0);
  33 |     expect(expanded.bench.width).toBeGreaterThan(expanded.main.width * 0.8);
  34 |     expect(expanded.first.right).toBeLessThanOrEqual(expanded.second.x + 1);
  35 |     await page.getByRole('button', { name: '收起侧栏', exact: true }).click();
  36 |     await expect(page.locator('.app-shell')).toHaveAttribute('data-sidebar', 'collapsed');
  37 |     const collapsed = await geometry();
  38 |     expect(collapsed.sidebar.x).toBeCloseTo(0, 0);
  39 |     expect(collapsed.sidebar.width).toBeCloseTo(60, 0);
  40 |     expect(collapsed.bench.width).toBeGreaterThan(expanded.bench.width + 140);
  41 |     const links = page.getByRole('navigation', { name: '主导航', exact: true }).getByRole('link');
  42 |     await expect(links).toHaveText([
  43 |       '学习首页',
  44 |       'C 语言课程',
  45 |       '进阶课程',
  46 |       '算法与演示',
  47 |       'C 代码工作台',
  48 |       '编译流程',
  49 |       '错题与陌生点',
  50 |       '今日复习',
  51 |       '学习成就',
  52 |       '本地设置',
  53 |     ]);
  54 |     for (const link of await links.all()) await expect(link).toBeVisible();
  55 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
  56 |       true,
  57 |     );
  58 |     samples.push({ width, expanded, collapsed });
  59 |     await page.getByRole('button', { name: '展开侧栏', exact: true }).click();
  60 |     await expect(page.locator('.app-shell')).toHaveAttribute('data-sidebar', 'expanded');
  61 |   }
  62 |   const after = await native(page);
  63 |   const a = before.databases['c-viz-learning'] as { rows: Record<string, unknown> };
  64 |   const b = after.databases['c-viz-learning'] as { rows: Record<string, unknown> };
  65 |   for (const name of Object.keys(a.rows).filter((name) => !['appearance', 'meta'].includes(name)))
  66 |     expect(b.rows[name]).toEqual(a.rows[name]);
  67 |   await info.attach('current-navigation-and-geometry', {
  68 |     body: JSON.stringify({ samples, before, after }),
  69 |     contentType: 'application/json',
  70 |   });
  71 | });
  72 | 
  73 | test('a real static deployment without the AI gateway fails before forwarding a Key and ordinary Rust C still runs', async ({
  74 |   page,
  75 | }) => {
  76 |   const posts: string[] = [];
  77 |   const external: string[] = [];
  78 |   page.on('request', (request) => {
  79 |     if (request.method() === 'POST' && request.url().includes('/api/ai/'))
  80 |       posts.push(request.url());
  81 |     if (!request.url().startsWith('http://127.0.0.1:4178/')) external.push(request.url());
  82 |   });
  83 |   await page.goto('/#/settings?panel=ai');
  84 |   await page.getByLabel('AI服务', { exact: true }).selectOption('openai');
> 85 |   await page.getByLabel('模型', { exact: true }).selectOption('gpt-5.4-mini-2026-03-17');
     |                                                ^ Error: locator.selectOption: Test timeout of 30000ms exceeded.
  86 |   await page.getByLabel('你自己的API Key', { exact: true }).fill('DESIGN_ONLY_NOT_A_REAL_KEY');
  87 |   await page.getByRole('button', { name: '验证并开启AI解释', exact: true }).click();
  88 |   await expect(page.getByRole('alert')).toContainText('当前入口未连接AI转发服务');
  89 |   expect(posts).toEqual([]);
  90 |   await page.goto('/#/custom-code');
  91 |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  92 |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  93 |   expect(external).toEqual([]);
  94 | });
  95 | 
```