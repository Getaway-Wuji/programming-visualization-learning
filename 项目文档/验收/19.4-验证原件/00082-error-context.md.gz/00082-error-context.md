# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-debug.spec.ts >> 正式存储: AI configuration, real execution, simulated explanation and close preserve native DB9 rows/keys and all browser storage
- Location: tests\ai-browser\ai-debug.spec.ts:185:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByTestId('learning-save-status')
Expected: "ready"
Received: "unsaved"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" getByTestId('learning-save-status') with timeout 5000ms
  - waiting for getByTestId('learning-save-status')
    14 × locator resolved to <div data-save-status="unsaved" data-testid="learning-save-status">…</div>
       - unexpected value "unsaved"

```

```yaml
- alert:
  - heading "课程更新尚未就绪" [level=2]
  - paragraph: 当前课程版本尚未完成发布，暂不能保存新的学习结果。原学习档案已保留，无需清除数据或修改存储权限；更新可用后重新读取即可继续。
  - button "重新读取档案"
- paragraph: 当前处于临时模式。已保存的档案仍保留。请等待课程版本更新后再重试。
```

# Test source

```ts
  90  |         req.context.facts.some(
  91  |           (f) => f.kind === 'state' && f.name === 'sum' && f.value === 3 && f.alive,
  92  |         ),
  93  |       ).toBe(true);
  94  |     expect(req.context.runRef.language).toBe('c');
  95  |     expect(req.context.snippets.map((s) => s.text).join('')).toContain(
  96  |       kind === 'syntax' ? 'int main' : 'int main',
  97  |     );
  98  |     expect(req.context.facts.length).toBeGreaterThan(0);
  99  |     if (kind === 'syntax') {
  100 |       expect(req.context.traceAvailable).toBe(false);
  101 |       expect(req.context.facts.every((f) => f.kind === 'diagnostic')).toBe(true);
  102 |       await expect(page.getByRole('button', { name: /查看真实步骤/ })).toHaveCount(0);
  103 |       await page.getByRole('button', { name: '查看真实诊断源码', exact: true }).click();
  104 |       await expect(page.getByRole('textbox', { name: 'C 代码', exact: true })).toBeFocused();
  105 |     } else {
  106 |       const step = req.context.facts.find((f) => f.kind === 'step');
  107 |       expect(step).toBeDefined();
  108 |       if (step?.kind === 'step') {
  109 |         await page.getByRole('button', { name: `查看真实步骤 ${step.step}`, exact: true }).click();
  110 |         await expect(page.getByTestId('custom-code-page')).toHaveAttribute(
  111 |           'data-cursor',
  112 |           String(step.step),
  113 |         );
  114 |       }
  115 |     }
  116 |     await evidence(page, c, info);
  117 |   });
  118 | for (const mode of ['auth', 'quota', 'rate', 'badref', 'stale', 'blank'] as const)
  119 |   test(`simulated ${mode} failure has fixed fallback and real execution still works`, async ({
  120 |     page,
  121 |   }, info) => {
  122 |     const c = await instrumentation(page);
  123 |     await enable(page, 'deepseek');
  124 |     await workbench(page, sources.pointer);
  125 |     c.mode = mode;
  126 |     await send(page);
  127 |     await expect(page.locator('.ai-panel [role=alert]')).toBeVisible();
  128 |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  129 |     await page.getByRole('button', { name: '运行代码', exact: true }).click();
  130 |     await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  131 |     expect(c.requests).toHaveLength(1);
  132 |     await evidence(page, c, info);
  133 |   });
  134 | test('simulated HTML answer is plain text and never loads an image or URL', async ({
  135 |   page,
  136 | }, info) => {
  137 |   const c = await instrumentation(page);
  138 |   await enable(page);
  139 |   await workbench(page, sources.loop);
  140 |   c.mode = 'html';
  141 |   await send(page);
  142 |   await expect(page.locator('.ai-answer')).toContainText('<img src=');
  143 |   await expect(page.locator('.ai-answer img')).toHaveCount(0);
  144 |   await evidence(page, c, info);
  145 | });
  146 | for (const action of ['cancel', 'source', 'input', 'cursor'] as const)
  147 |   test(`${action} invalidates an in-flight simulated answer`, async ({ page }, info) => {
  148 |     const c = await instrumentation(page);
  149 |     await enable(page);
  150 |     await workbench(page, sources.loop);
  151 |     c.mode = 'delay';
  152 |     c.delay = 700;
  153 |     await send(page);
  154 |     await expect(page.getByText('正在等待OpenAI解释', { exact: false })).toBeVisible();
  155 |     if (action === 'cancel')
  156 |       await page.getByRole('button', { name: '取消本端等待', exact: true }).click();
  157 |     else if (action === 'source') {
  158 |       await page.getByRole('button', { name: '编辑代码', exact: true }).click();
  159 |       await page
  160 |         .getByRole('textbox', { name: 'C 代码', exact: true })
  161 |         .fill('int main(){return 0;}');
  162 |     } else if (action === 'input')
  163 |       await page.getByRole('textbox', { name: '整数输入', exact: true }).fill('8');
  164 |     else await page.getByRole('button', { name: '后退', exact: true }).click();
  165 |     await expect(page.getByRole('heading', { name: '确认本次发送内容', exact: true })).toHaveCount(
  166 |       0,
  167 |     );
  168 |     await page.waitForTimeout(800);
  169 |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  170 |     await evidence(page, c, info);
  171 |   });
  172 | test('refresh and leaving the workbench discard all AI configuration', async ({ page }, info) => {
  173 |   const c = await instrumentation(page);
  174 |   await enable(page);
  175 |   await workbench(page, sources.loop);
  176 |   await page.getByRole('link', { name: '本地设置', exact: true }).click();
  177 |   await page.getByRole('tab', { name: 'AI解释（可选）', exact: true }).click();
  178 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  179 |   await enable(page);
  180 |   await page.reload();
  181 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  182 |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  183 |   await evidence(page, c, info);
  184 | });
  185 | test('正式存储: AI configuration, real execution, simulated explanation and close preserve native DB9 rows/keys and all browser storage', async ({
  186 |   page,
  187 | }, info) => {
  188 |   const c = await instrumentation(page);
  189 |   await settings(page);
> 190 |   await expect(page.getByTestId('learning-save-status')).toHaveAttribute(
      |                                                          ^ Error: expect(locator).toHaveAttribute(expected) failed
  191 |     'data-save-status',
  192 |     'ready',
  193 |   );
  194 |   const before = await native(page);
  195 |   const db = before.databases['c-viz-learning'] as { version: number; names: string[] };
  196 |   expect(db.version).toBe(9);
  197 |   expect(db.names).toHaveLength(17);
  198 |   await enable(page);
  199 |   await workbench(page, sources.loop);
  200 |   await send(page);
  201 |   await expect(page.locator('.ai-answer')).toBeVisible();
  202 |   await page.getByRole('link', { name: '本地设置', exact: true }).click();
  203 |   await page.getByRole('tab', { name: 'AI解释（可选）', exact: true }).click();
  204 |   const after = await native(page);
  205 |   expect(after).toEqual(before);
  206 |   await evidence(page, c, info);
  207 | });
  208 | test('正式存储: two tabs never share Key, and clearing learning data in another tab closes the configured tab', async ({
  209 |   page,
  210 |   context,
  211 | }, info) => {
  212 |   const c = await instrumentation(page);
  213 |   await enable(page);
  214 |   const second = await context.newPage();
  215 |   await instrumentation(second);
  216 |   await settings(second);
  217 |   await expect(second.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  218 |   await expect(second.getByLabel('你自己的API Key', { exact: true })).toHaveValue('');
  219 |   await second.getByRole('tab', { name: '本地数据', exact: true }).click();
  220 |   await second.getByRole('button', { name: '清除本地数据', exact: true }).click();
  221 |   await second.getByRole('button', { name: '确认清除', exact: true }).click();
  222 |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  223 |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  224 |   await evidence(page, c, info);
  225 | });
  226 | for (const width of [1440, 768, 390])
  227 |   test(`AI settings keyboard and layout at ${width}px`, async ({ page }, info) => {
  228 |     const c = await instrumentation(page);
  229 |     await page.setViewportSize({ width, height: 900 });
  230 |     await settings(page);
  231 |     await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toBeVisible();
  232 |     await page.getByRole('combobox', { name: 'AI服务', exact: true }).focus();
  233 |     await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toBeFocused();
  234 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  235 |       true,
  236 |     );
  237 |     await page.screenshot({ path: info.outputPath(`settings-${width}.png`), fullPage: true });
  238 |     await evidence(page, c, info);
  239 |   });
  240 | 
```