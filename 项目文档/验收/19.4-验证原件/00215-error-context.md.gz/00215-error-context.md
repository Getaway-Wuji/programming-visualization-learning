# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-regression\current-nav.spec.ts >> current ten navigation entries and original workbench width/collapse behavior at four desktop widths
- Location: tests\ai-regression\current-nav.spec.ts:4:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

@@ -6,11 +6,11 @@
      ],
    ],
    "rows": Array [
      Object {
        "authority": "blocks",
-       "captureVersion": 0,
+       "captureVersion": 1,
        "codeText": "#include <stdio.h>
  int main(void) {
      int x = 7;
      return 0;
  }
@@ -37,11 +37,11 @@
            "id": "program.c.echo",
            "version": "1.0.0",
          },
        },
        "sequence": 1,
-       "state": "pending",
+       "state": "synced",
        "workspaceJson": "{\"blocks\":{\"languageVersion\":0,\"blocks\":[{\"type\":\"cv_main\",\"id\":\"lesson.main\",\"x\":0,\"y\":0,\"inputs\":{\"BODY\":{\"block\":{\"type\":\"cv_declare\",\"id\":\"lesson.block.1\",\"editable\":false,\"extraState\":{\"binding\":{\"bindingKey\":\"param.x\",\"name\":\"x\",\"targetKind\":\"scalar\"}},\"fields\":{\"NAME\":\"x\",\"INITIALIZE\":false}}}}}]}}",
        "writerId": "047a8dc8-e5ee-4c56-95d1-03028c6ad9bb",
      },
    ],
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - button "进入专注模式" [ref=e68] [cursor=pointer]:
          - generic [ref=e71]: 专注
        - generic [ref=e72]: 本地学习
        - link "本地数据" [ref=e73] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e77] [cursor=pointer]
    - main [ref=e80]:
      - generic [ref=e81]:
        - navigation "当前位置" [ref=e82]:
          - list [ref=e83]:
            - listitem [ref=e84]:
              - link "C 语言课程" [ref=e85] [cursor=pointer]:
                - /url: "#/courses"
            - listitem [ref=e86]:
              - link "变量和输出" [ref=e89] [cursor=pointer]:
                - /url: "#/lessons/lesson.c.variables-output"
            - listitem [ref=e90]:
              - generic [ref=e93]: 输出输入变量
        - generic [ref=e94]:
          - paragraph [ref=e95]: 动手练习 · 程序与输入
          - heading "输出输入变量" [level=1] [ref=e96]
          - paragraph [ref=e97]: 用 C 代码或积木解答，提交后逐步复盘真实执行。
        - paragraph [ref=e101]: 尚无已保存的学习记录
        - generic [ref=e102]:
          - generic [ref=e104]:
            - heading "题目与答题区" [level=2] [ref=e105]
            - paragraph [ref=e106]: 保留输入源变量x（-999到999），用输出积木读取x，输出它的十进制整数和一个换行，不要加提示文字。例：x=7输出7并换行，x=0输出0，x=-9输出-9。必须实际声明、读取输入变量，不能打印固定答案。所有测试正常结束且main返回0。思路：先找到输入声明，再把变量读取放进printf的%d参数。
            - paragraph [ref=e107]: 教学目标：真实声明并读取x，输出依赖输入，不打印固定答案。
            - group [ref=e108]:
              - generic "练习与保存说明" [ref=e109] [cursor=pointer]
          - generic [ref=e110]:
            - generic [ref=e111]:
              - generic "练习起点" [ref=e112]:
                - button "独立练习" [pressed] [ref=e113] [cursor=pointer]
                - button "改错练习" [ref=e114] [cursor=pointer]
                - button "拆积木练习" [ref=e115] [cursor=pointer]
              - link "查看课程示例" [ref=e116] [cursor=pointer]:
                - /url: "#/lessons/lesson.c.variables-output"
            - paragraph [ref=e117]: 从零搭建解答。已保留本题输入声明，请在 main 中加入你的程序。各模式草稿独立保留，切换会清除本次结果；已保存的编辑历史可在离题或刷新后选择恢复，未保存内容可能丢失。示例在新标签页打开。
            - generic [ref=e119]:
              - strong [ref=e120]: 需要一点帮助？
              - button "查看第 1 层提示" [ref=e121] [cursor=pointer]
          - generic [ref=e122]:
            - button "运行本组" [ref=e123] [cursor=pointer]
            - button "准备代码" [ref=e124] [cursor=pointer]
            - button "提交练习" [ref=e125] [cursor=pointer]
            - button "取消提交" [disabled] [ref=e126]
            - link "查看本次复盘" [ref=e127] [cursor=pointer]:
              - /url: "#/practice/exercise.c.echo/review"
          - paragraph [ref=e128]: 运行本组只检查第一组输入，不记录通过或积分；提交练习才检查全部3 组与教学目标。准备代码只生成源码。 修改积木或代码会立即使旧判定和轨迹失效；已保存的历史通过仍保留。
          - generic [ref=e129]:
            - generic [ref=e130]:
              - generic [ref=e131]: 积木显示
              - combobox "积木显示" [ref=e132]:
                - option "自动（按课程推荐）" [selected]
                - option "始终显示"
                - option "隐藏"
            - paragraph [ref=e133]: 本节推荐代码作答。隐藏积木后仍可写代码、运行和提交；切换显示不会修改解答。
            - status [ref=e134]: 正在使用当前浏览器的积木显示偏好。
          - group [ref=e135]:
            - generic "积木权限：已永久解锁 0 / 20 · 本节临时开放 8 类" [ref=e136] [cursor=pointer]
          - group [ref=e137]:
            - generic "编辑历史 · 1 条已保存" [ref=e138] [cursor=pointer]
          - region "编辑代码" [ref=e142]:
            - complementary "代码与积木联动" [ref=e146]:
              - generic [ref=e147]:
                - generic [ref=e148]:
                  - heading "编辑 C 代码" [level=3] [ref=e149]
                  - generic [ref=e150]: 当前草稿
                - status [ref=e151]: 代码与积木已同步。
                - generic [ref=e152]:
                  - generic [aria-hidden]:
                    - code: "#include <stdio.h> int main(void) { int x = 7; return 0; }"
                  - textbox "编辑 C 代码" [ref=e153]: "#include <stdio.h> int main(void) { int x = 7; return 0; }"
                - paragraph [ref=e154]:
                  - text: 编辑稿使用本题第一组输入：
                  - code [ref=e155]: "{\"x\":7}"
                  - text: 。已保存的编辑历史可在刷新后选择恢复，未保存内容仅在本次页面保留；选择代码或积木可查看对应位置。
          - heading "本次提交与反馈" [level=3] [ref=e157]
          - status [ref=e159]:
            - generic [ref=e163]:
              - heading "已保存" [level=2] [ref=e164]
              - paragraph [ref=e165]: 这次更改已保存到当前浏览器。
          - region "小节完成清单" [ref=e166]:
            - generic [ref=e167]:
              - heading "小节完成清单" [level=3] [ref=e168]
              - generic [ref=e169]: 0/2 项已保存
            - list [ref=e170]:
              - listitem [ref=e171]:
                - generic [ref=e172]: 阅读并主动确认学习
                - strong [ref=e173]: 待确认
              - listitem [ref=e174]:
                - generic [ref=e175]: 输出输入变量
                - strong [ref=e176]: 待通过并保存
            - paragraph [ref=e177]: 小节尚未完成
            - link "阅读并确认本节学习" [ref=e178] [cursor=pointer]:
              - /url: "#/lessons/lesson.c.variables-output#lesson-study-confirmation"
          - paragraph [ref=e179]: 当前源码对应测试组：positive。此处为将实际执行的完整代码。
          - paragraph [ref=e180]:
            - text: 本组输入：
            - code [ref=e181]: "{\"x\":7}"
          - generic "执行播放工作区" [ref=e182]:
            - region "运行结果" [ref=e183]:
              - heading "当前步骤画面" [level=3] [ref=e185]
              - generic "播放控制" [ref=e186]:
                - generic [ref=e187]:
                  - button "后退" [disabled] [ref=e188]
                  - button "播放" [disabled] [ref=e189]
                  - button "前进" [disabled] [ref=e190]
                  - button "重播" [disabled] [ref=e191]
                - generic [ref=e192]:
                  - text: 速度
                  - combobox "播放速度" [disabled] [ref=e193]:
                    - option "0.25×"
                    - option "0.5×"
                    - option "1×" [selected]
                    - option "1.5×"
                    - option "2×"
                    - option "4×"
                - generic [ref=e194]:
                  - generic [ref=e195]: 步骤 — / 0
                  - status [ref=e196]: 等待运行轨迹
                - paragraph [ref=e197]: 聚焦播放工作区后，空格播放或暂停，左右方向键单步查看。重播从初始状态开始播放。
              - paragraph [ref=e199]: 尚无当前步骤画面。运行后从初始状态开始查看。
        - paragraph [ref=e200]: 积木只生成受支持的 C 程序。返回本节可查看已保存的历史进度。
        - link "返回本节学习" [ref=e201] [cursor=pointer]:
          - /url: "#/lessons/lesson.c.variables-output"
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import { native } from '../ai-browser/helpers';
  3  | 
  4  | test('current ten navigation entries and original workbench width/collapse behavior at four desktop widths', async ({
  5  |   page,
  6  | }, info) => {
  7  |   await page.goto('/#/practice/exercise.c.echo');
  8  |   await expect(page.getByTestId('practice-execution')).toHaveAttribute('data-state', 'ready');
  9  |   const before = await native(page);
  10 |   const samples = [];
  11 |   for (const width of [1366, 1440, 1920, 2560]) {
  12 |     await page.setViewportSize({ width, height: 900 });
  13 |     const bench = page.locator('[data-testid="workbench"][data-kind="practice"]');
  14 |     const geometry = () =>
  15 |       bench.evaluate((element) => {
  16 |         const box = (node: Element) => {
  17 |           const { x, width, right } = node.getBoundingClientRect();
  18 |           return { x, width, right };
  19 |         };
  20 |         return {
  21 |           sidebar: box(document.querySelector('.sidebar')!),
  22 |           main: box(document.querySelector('.main-content')!),
  23 |           bench: box(element),
  24 |           first: box(element.querySelector('[data-testid="workbench-first"]')!),
  25 |           second: box(element.querySelector('[data-testid="workbench-second"]')!),
  26 |         };
  27 |       });
  28 |     await expect(page.getByRole('button', { name: '收起侧栏', exact: true })).toBeVisible();
  29 |     const expanded = await geometry();
  30 |     expect(expanded.sidebar.x).toBeCloseTo(0, 0);
  31 |     expect(expanded.sidebar.width).toBeCloseTo(216, 0);
  32 |     expect(expanded.main.right).toBeCloseTo(width, 0);
  33 |     expect(expanded.bench.width).toBeGreaterThan(expanded.main.width * 0.8);
  34 |     expect(expanded.first.right).toBeLessThanOrEqual(expanded.second.x + 1);
  35 |     await page.getByRole('button', { name: '收起侧栏', exact: true }).click();
  36 |     await expect(page.locator('.app-shell')).toHaveAttribute('data-sidebar', 'collapsed');
  37 |     const collapsed = await geometry();
  38 |     expect(collapsed.sidebar.x).toBeCloseTo(0, 0);
  39 |     expect(collapsed.sidebar.width).toBeCloseTo(60, 0);
  40 |     expect(collapsed.bench.width).toBeGreaterThan(expanded.bench.width + 140);
  41 |     const links = page.getByRole('navigation', { name: '主导航', exact: true }).getByRole('link');
  42 |     await expect(links).toHaveText([
  43 |       '学习首页',
  44 |       'C 语言课程',
  45 |       '进阶课程',
  46 |       '算法与演示',
  47 |       'C 代码工作台',
  48 |       '编译流程',
  49 |       '错题与陌生点',
  50 |       '今日复习',
  51 |       '学习成就',
  52 |       '本地设置',
  53 |     ]);
  54 |     for (const link of await links.all()) await expect(link).toBeVisible();
  55 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
  56 |       true,
  57 |     );
  58 |     samples.push({ width, expanded, collapsed });
  59 |     await page.getByRole('button', { name: '展开侧栏', exact: true }).click();
  60 |     await expect(page.locator('.app-shell')).toHaveAttribute('data-sidebar', 'expanded');
  61 |   }
  62 |   const after = await native(page);
  63 |   const a = before.databases['c-viz-learning'] as { rows: Record<string, unknown> };
  64 |   const b = after.databases['c-viz-learning'] as { rows: Record<string, unknown> };
  65 |   for (const name of Object.keys(a.rows).filter((name) => !['appearance', 'meta'].includes(name)))
> 66 |     expect(b.rows[name]).toEqual(a.rows[name]);
     |                          ^ Error: expect(received).toEqual(expected) // deep equality
  67 |   await info.attach('current-navigation-and-geometry', {
  68 |     body: JSON.stringify({ samples, before, after }),
  69 |     contentType: 'application/json',
  70 |   });
  71 | });
  72 | 
  73 | test('a real static deployment without the AI gateway fails before forwarding a Key and ordinary Rust C still runs', async ({
  74 |   page,
  75 | }) => {
  76 |   const posts: string[] = [];
  77 |   const external: string[] = [];
  78 |   page.on('request', (request) => {
  79 |     if (request.method() === 'POST' && request.url().includes('/api/ai/'))
  80 |       posts.push(request.url());
  81 |     if (!request.url().startsWith('http://127.0.0.1:4178/')) external.push(request.url());
  82 |   });
  83 |   await page.goto('/#/settings?panel=ai');
  84 |   await page.getByLabel('AI服务', { exact: true }).selectOption('openai');
  85 |   await page.getByLabel('模型', { exact: true }).selectOption('gpt-5.4-mini-2026-03-17');
  86 |   await page.getByLabel('你自己的API Key', { exact: true }).fill('DESIGN_ONLY_NOT_A_REAL_KEY');
  87 |   await page.getByRole('button', { name: '验证并开启AI解释', exact: true }).click();
  88 |   await expect(page.getByRole('alert')).toContainText('当前入口未连接AI转发服务');
  89 |   expect(posts).toEqual([]);
  90 |   await page.goto('/#/custom-code');
  91 |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  92 |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  93 |   expect(external).toEqual([]);
  94 | });
  95 | 
```