# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workbench-layout.spec.ts >> selected themes use the available workbench width and keep the collapsible navigation on the left
- Location: tests\browser\workbench-layout.spec.ts:176:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('navigation', { name: '主导航', exact: true }).getByRole('link')
Timeout: 5000ms
- Expected  - 0
+ Received  + 2

@@ -1,9 +1,11 @@
  Array [
    "学习首页",
    "C 语言课程",
+   "进阶课程",
    "算法与演示",
+   "C 代码工作台",
    "编译流程",
    "错题与陌生点",
    "今日复习",
    "学习成就",
    "本地设置",

Call log:
  - Expect "toHaveText" getByRole('navigation', { name: '主导航', exact: true }).getByRole('link') with timeout 5000ms
  - waiting for getByRole('navigation', { name: '主导航', exact: true }).getByRole('link')
    14 × locator resolved to 10 elements

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "展开侧栏" [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e9] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e10]: "{ }"
    - navigation "主导航" [ref=e11]:
      - link "学习首页" [ref=e12] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e15] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e18] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e21] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e24] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e27] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e30] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e33] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e36] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e39] [cursor=pointer]:
        - /url: "#/settings"
  - generic [ref=e42]:
    - banner [ref=e43]:
      - generic [ref=e44]: C 语言 · 从零开始
      - generic [ref=e45]:
        - button "进入专注模式" [ref=e46] [cursor=pointer]:
          - generic [ref=e49]: 专注
        - generic [ref=e50]: 本地学习
        - link "本地数据" [ref=e51] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e55] [cursor=pointer]
    - main [ref=e58]:
      - generic [ref=e59]:
        - navigation "当前位置" [ref=e60]:
          - list [ref=e61]:
            - listitem [ref=e62]:
              - link "C 语言课程" [ref=e63] [cursor=pointer]:
                - /url: "#/courses"
            - listitem [ref=e64]:
              - link "变量和输出" [ref=e67] [cursor=pointer]:
                - /url: "#/lessons/lesson.c.variables-output"
            - listitem [ref=e68]:
              - generic [ref=e71]: 输出输入变量
        - generic [ref=e72]:
          - paragraph [ref=e73]: 动手练习 · 程序与输入
          - heading "输出输入变量" [level=1] [ref=e74]
          - paragraph [ref=e75]: 用 C 代码或积木解答，提交后逐步复盘真实执行。
        - paragraph [ref=e79]: 尚无已保存的学习记录
        - generic [ref=e80]:
          - generic [ref=e82]:
            - heading "题目与答题区" [level=2] [ref=e83]
            - paragraph [ref=e84]: 保留输入源变量x（-999到999），用输出积木读取x，输出它的十进制整数和一个换行，不要加提示文字。例：x=7输出7并换行，x=0输出0，x=-9输出-9。必须实际声明、读取输入变量，不能打印固定答案。所有测试正常结束且main返回0。思路：先找到输入声明，再把变量读取放进printf的%d参数。
            - paragraph [ref=e85]: 教学目标：真实声明并读取x，输出依赖输入，不打印固定答案。
            - group [ref=e86]:
              - generic "练习与保存说明" [ref=e87] [cursor=pointer]
          - generic [ref=e88]:
            - generic [ref=e89]:
              - generic "练习起点" [ref=e90]:
                - button "独立练习" [pressed] [ref=e91] [cursor=pointer]
                - button "改错练习" [ref=e92] [cursor=pointer]
                - button "拆积木练习" [ref=e93] [cursor=pointer]
              - link "查看课程示例" [ref=e94] [cursor=pointer]:
                - /url: "#/lessons/lesson.c.variables-output"
            - paragraph [ref=e95]: 从零搭建解答。已保留本题输入声明，请在 main 中加入你的程序。各模式草稿独立保留，切换会清除本次结果；已保存的编辑历史可在离题或刷新后选择恢复，未保存内容可能丢失。示例在新标签页打开。
            - generic [ref=e97]:
              - strong [ref=e98]: 需要一点帮助？
              - button "查看第 1 层提示" [ref=e99] [cursor=pointer]
          - generic [ref=e100]:
            - button "运行本组" [ref=e101] [cursor=pointer]
            - button "准备代码" [ref=e102] [cursor=pointer]
            - button "提交练习" [ref=e103] [cursor=pointer]
            - button "取消提交" [disabled] [ref=e104]
            - link "查看本次复盘" [ref=e105] [cursor=pointer]:
              - /url: "#/practice/exercise.c.echo/review"
            - button "编辑 C 并同步积木" [ref=e106] [cursor=pointer]
            - status [ref=e107]: 当前代码与积木已同步。
          - paragraph [ref=e108]: 运行本组只检查第一组输入，不记录通过或积分；提交练习才检查全部3 组与教学目标。准备代码只生成源码。 修改积木或代码会立即使旧判定和轨迹失效；已保存的历史通过仍保留。
          - generic [ref=e109]:
            - generic [ref=e110]:
              - generic [ref=e111]: 积木显示
              - combobox "积木显示" [ref=e112]:
                - option "自动（按课程推荐）"
                - option "始终显示" [selected]
                - option "隐藏"
            - paragraph [ref=e113]: 本节推荐代码作答。隐藏积木后仍可写代码、运行和提交；切换显示不会修改解答。
            - status [ref=e114]: 积木显示偏好已保存到当前浏览器。
          - group [ref=e115]:
            - generic "积木权限：已永久解锁 0 / 20 · 本节临时开放 8 类" [ref=e116] [cursor=pointer]
          - group [ref=e117]:
            - generic "编辑历史 · 1 条已保存" [ref=e118] [cursor=pointer]
          - generic [ref=e120]:
            - generic [ref=e121]:
              - generic [ref=e122]: 拖动中间分隔条调整宽度
              - button "恢复默认比例" [disabled] [ref=e123] [cursor=pointer]
            - generic [ref=e124]:
              - region "积木" [ref=e125]:
                - generic [ref=e126]:
                  - generic [ref=e127]: 积木
                  - button "展开积木" [ref=e128] [cursor=pointer]:
                    - generic [ref=e131]: 展开
                - region "积木工作区" [ref=e134]:
                  - paragraph [ref=e135]: 从左侧分类拖入积木，右侧同步显示生成的 C 代码。键盘操作可展开下方“逐块编辑与键盘连接”。
                  - generic [ref=e136]:
                    - group "积木编辑操作" [ref=e137]:
                      - button "撤销" [disabled] [ref=e138]
                      - button "重做" [disabled] [ref=e139]
                    - status [ref=e140]: 拖动到匹配的插槽即可拼接。
                  - generic "可拖拽积木画布" [ref=e141]:
                    - application [ref=e142]:
                      - tree [ref=e144]:
                        - treeitem "程序与作用域" [level=1] [ref=e145]
                        - treeitem "整数与变量" [level=1] [ref=e147]
                        - treeitem "运算与判断" [level=1] [ref=e149]
                        - treeitem "条件与循环" [level=1] [ref=e151]
                        - treeitem "数组与输出" [level=1] [ref=e153]
                      - region "Blocks工作区。" [ref=e155]:
                        - figure "0个块堆"
                        - figure "块堆开始, 主程序 int main, 执行, 结尾默认返回 0," [ref=e158]
                        - figure "声明 int, x, Not checked, 设置初值 · 课程输入（按测试组实例化）, 有输入," [ref=e159]
                        - generic [aria-hidden] [ref=e161]: 声明 int
                        - 'button "text: x" [ref=e162]':
                          - generic [aria-hidden]: x
                        - checkbox "checkbox" [ref=e164]
                        - generic [aria-hidden] [ref=e167]: 设置初值
                        - generic [aria-hidden] [ref=e169]: · 课程输入（按测试组实例化）
                        - figure [ref=e170]
                        - figure [ref=e171]
                        - generic [aria-hidden] [ref=e173]: 主程序 int main
                        - generic [aria-hidden] [ref=e175]: 执行
                        - generic [aria-hidden] [ref=e177]: 结尾默认返回 0
                        - figure [ref=e178]
                        - button "垃圾桶，当前为空" [disabled] [ref=e179]
                        - button "Zoom out" [ref=e182]
                        - button "Zoom in" [ref=e185]
                        - button "Reset zoom" [ref=e188]
                      - status [ref=e193]
                  - group [ref=e194]:
                    - generic "逐块编辑与键盘连接" [ref=e195] [cursor=pointer]
                    - option "请选择积木"
                    - option "1. 主程序" [selected]
                    - option "2. 声明整数 · x"
                    - option "主程序"
                    - option "整数" [selected]
                    - option "声明整数"
                    - option "读取变量"
                    - option "变量赋值"
                    - option "一元运算"
                    - option "算术运算（未解锁）" [disabled]
                    - option "比较（未解锁）" [disabled]
                    - option "逻辑运算（未解锁）" [disabled]
                    - option "条件分支（未解锁）" [disabled]
                    - option "while 循环（未解锁）" [disabled]
                    - option "for 循环（未解锁）" [disabled]
                    - option "跳出循环（未解锁）" [disabled]
                    - option "继续下轮（未解锁）" [disabled]
                    - option "声明数组（未解锁）" [disabled]
                    - option "读取数组（未解锁）" [disabled]
                    - option "写入数组（未解锁）" [disabled]
                    - option "输出"
                    - option "返回"
                    - option "独立作用域（未解锁）" [disabled]
                    - option "请选择目标积木" [selected]
                    - option "1. 声明整数 · x"
                    - option "请选择插槽" [selected]
              - separator "调整面板宽度" [ref=e196]
              - region "生成代码" [ref=e198]:
                - generic [ref=e199]:
                  - generic [ref=e200]: 生成代码
                  - button "展开生成代码" [ref=e201] [cursor=pointer]:
                    - generic [ref=e204]: 展开
                - complementary "代码与积木联动" [ref=e206]:
                  - region "执行代码区域" [ref=e207]:
                    - generic [ref=e208]:
                      - heading "本次执行的 C 代码" [level=3] [ref=e209]
                      - generic [ref=e210]: 只读
                    - paragraph [ref=e211]: 尚无当前执行步骤，源码已就绪。
                    - generic [ref=e212]:
                      - generic [aria-hidden]:
                        - code: "#include <stdio.h> int main(void) { int x = 7; return 0; }"
                      - textbox "当前执行的 C 代码" [ref=e213]: "#include <stdio.h> int main(void) { int x = 7; return 0; }"
          - heading "本次提交与反馈" [level=3] [ref=e215]
          - status [ref=e217]:
            - generic [ref=e221]:
              - heading "已保存" [level=2] [ref=e222]
              - paragraph [ref=e223]: 这次更改已保存到当前浏览器。
          - region "小节完成清单" [ref=e224]:
            - generic [ref=e225]:
              - heading "小节完成清单" [level=3] [ref=e226]
              - generic [ref=e227]: 0/2 项已保存
            - list [ref=e228]:
              - listitem [ref=e229]:
                - generic [ref=e230]: 阅读并主动确认学习
                - strong [ref=e231]: 待确认
              - listitem [ref=e232]:
                - generic [ref=e233]: 输出输入变量
                - strong [ref=e234]: 待通过并保存
            - paragraph [ref=e235]: 小节尚未完成
            - link "阅读并确认本节学习" [ref=e236] [cursor=pointer]:
              - /url: "#/lessons/lesson.c.variables-output#lesson-study-confirmation"
          - paragraph [ref=e237]: 当前源码对应测试组：positive。此处为将实际执行的完整代码。
          - paragraph [ref=e238]:
            - text: 本组输入：
            - code [ref=e239]: "{\"x\":7}"
          - generic "执行播放工作区" [ref=e240]:
            - region "运行结果" [ref=e241]:
              - heading "当前步骤画面" [level=3] [ref=e243]
              - generic "播放控制" [ref=e244]:
                - generic [ref=e245]:
                  - button "后退" [disabled] [ref=e246]
                  - button "播放" [disabled] [ref=e247]
                  - button "前进" [disabled] [ref=e248]
                  - button "重播" [disabled] [ref=e249]
                - generic [ref=e250]:
                  - text: 速度
                  - combobox "播放速度" [disabled] [ref=e251]:
                    - option "0.25×"
                    - option "0.5×"
                    - option "1×" [selected]
                    - option "1.5×"
                    - option "2×"
                    - option "4×"
                - generic [ref=e252]:
                  - generic [ref=e253]: 步骤 — / 0
                  - status [ref=e254]: 等待运行轨迹
                - paragraph [ref=e255]: 聚焦播放工作区后，空格播放或暂停，左右方向键单步查看。重播从初始状态开始播放。
              - paragraph [ref=e257]: 尚无当前步骤画面。运行后从初始状态开始查看。
        - paragraph [ref=e258]: 积木只生成受支持的 C 程序。返回本节可查看已保存的历史进度。
        - link "返回本节学习" [ref=e259] [cursor=pointer]:
          - /url: "#/lessons/lesson.c.variables-output"
```

# Test source

```ts
  106 |   expect(
  107 |     await page.evaluate(() =>
  108 |       Math.max(0, document.documentElement.scrollWidth - document.documentElement.clientWidth),
  109 |     ),
  110 |   ).toBeLessThanOrEqual(1);
  111 | }
  112 | 
  113 | async function geometry(scope: Locator) {
  114 |   return scope.evaluate((element) => {
  115 |     const rect = (node: Element) => {
  116 |       const { x, y, width, height, right } = node.getBoundingClientRect();
  117 |       return { x, y, width, height, right };
  118 |     };
  119 |     return {
  120 |       viewport: document.documentElement.clientWidth,
  121 |       sidebar: rect(document.querySelector('.sidebar')!),
  122 |       main: rect(document.querySelector('.main-content')!),
  123 |       bench: rect(element),
  124 |       first: rect(element.querySelector('[data-testid="workbench-first"]')!),
  125 |       second: rect(element.querySelector('[data-testid="workbench-second"]')!),
  126 |     };
  127 |   });
  128 | }
  129 | 
  130 | async function savedRatio(page: Page, kind: 'practice' | 'visualize' | 'review', value: number) {
  131 |   await expect
  132 |     .poll(async () => (await snapshot(page)).appearance.layout.splitRatios[kind])
  133 |     .toBe(value);
  134 |   await ready(page);
  135 | }
  136 | 
  137 | async function attach(info: TestInfo, name: string, value: unknown) {
  138 |   await info.attach(name, { body: JSON.stringify(value), contentType: 'application/json' });
  139 | }
  140 | 
  141 | async function executions(page: Page) {
  142 |   return page.evaluate(
  143 |     () => window.__verticalObservation.workers.filter((worker) => worker.kind === 'execute').length,
  144 |   );
  145 | }
  146 | 
  147 | async function presentVariableFrame(page: Page) {
  148 |   const core = page.getByTestId('trace-view').getByLabel('当前变量', { exact: true });
  149 |   await core.evaluate((element) =>
  150 |     element.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' }),
  151 |   );
  152 |   await expect
  153 |     .poll(() =>
  154 |       core.evaluate((element) => {
  155 |         const bounds = element.getBoundingClientRect();
  156 |         const visibleHeight = Math.min(bounds.bottom, innerHeight) - Math.max(bounds.top, 0);
  157 |         const visibleWidth = Math.min(bounds.right, innerWidth) - Math.max(bounds.left, 0);
  158 |         return (
  159 |           bounds.width > 0 &&
  160 |           bounds.height > 0 &&
  161 |           visibleHeight >= Math.min(bounds.height, 160) * 0.75 &&
  162 |           visibleWidth >= Math.min(bounds.width, 240) * 0.75
  163 |         );
  164 |       }),
  165 |     )
  166 |     .toBe(true);
  167 |   // Let the production observer see two genuine painted frames, including cursor zero.
  168 |   await page.evaluate(
  169 |     () =>
  170 |       new Promise<void>((resolve) =>
  171 |         requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  172 |       ),
  173 |   );
  174 | }
  175 | 
  176 | test('selected themes use the available workbench width and keep the collapsible navigation on the left', async ({
  177 |   page,
  178 | }, info) => {
  179 |   test.setTimeout(120000);
  180 |   await page.setViewportSize({ width: 1440, height: 900 });
  181 |   await saveTheme(page, 'minimal');
  182 |   const before = await snapshot(page);
  183 |   const samples = [];
  184 |   for (const theme of themes) {
  185 |     await saveTheme(page, theme);
  186 |     await openPractice(page);
  187 |     for (const width of [1366, 1440, 1920, 2560]) {
  188 |       await page.setViewportSize({ width, height: 900 });
  189 |       await expect(shell(page)).toHaveAttribute('data-sidebar', 'expanded');
  190 |       const scope = workbench(page, 'practice');
  191 |       await expect(separator(scope)).toBeVisible();
  192 |       const expanded = await geometry(scope);
  193 |       expect(expanded.sidebar.x).toBeCloseTo(0, 0);
  194 |       expect(expanded.sidebar.width).toBeCloseTo(216, 0);
  195 |       expect(expanded.main.right).toBeCloseTo(expanded.viewport, 0);
  196 |       expect(expanded.bench.width).toBeGreaterThan(expanded.main.width * 0.8);
  197 |       expect(expanded.first.right).toBeLessThanOrEqual(expanded.second.x + 1);
  198 |       await page.getByRole('button', { name: '收起侧栏', exact: true }).click();
  199 |       await expect(shell(page)).toHaveAttribute('data-sidebar', 'collapsed');
  200 |       await ready(page);
  201 |       const collapsed = await geometry(scope);
  202 |       expect(collapsed.sidebar.x).toBeCloseTo(0, 0);
  203 |       expect(collapsed.sidebar.width).toBeCloseTo(60, 0);
  204 |       expect(collapsed.bench.width).toBeGreaterThan(expanded.bench.width + 140);
  205 |       const links = page.getByRole('navigation', { name: '主导航', exact: true }).getByRole('link');
> 206 |       await expect(links).toHaveText([
      |                           ^ Error: expect(locator).toHaveText(expected) failed
  207 |         '学习首页',
  208 |         'C 语言课程',
  209 |         '算法与演示',
  210 |         '编译流程',
  211 |         '错题与陌生点',
  212 |         '今日复习',
  213 |         '学习成就',
  214 |         '本地设置',
  215 |       ]);
  216 |       for (const name of ['学习首页', 'C 语言课程', '算法与演示', '编译流程', '本地设置'])
  217 |         await expect(
  218 |           page
  219 |             .getByRole('navigation', { name: '主导航', exact: true })
  220 |             .getByRole('link', { name, exact: true }),
  221 |         ).toBeVisible();
  222 |       await noPageOverflow(page);
  223 |       samples.push({ theme, width, expanded, collapsed });
  224 |       if (width === 1440)
  225 |         await scope.screenshot({ path: info.outputPath(`${theme}-workbench.png`) });
  226 |       await page.getByRole('button', { name: '展开侧栏', exact: true }).click();
  227 |       await expect(shell(page)).toHaveAttribute('data-sidebar', 'expanded');
  228 |       await ready(page);
  229 |     }
  230 |   }
  231 |   await page.getByRole('button', { name: '收起侧栏', exact: true }).click();
  232 |   await ready(page);
  233 |   await page.reload();
  234 |   await ready(page);
  235 |   await expect(shell(page)).toHaveAttribute('data-sidebar', 'collapsed');
  236 |   const after = await snapshot(page);
  237 |   expect(after.appearance.layout.sidebar).toBe('collapsed');
  238 |   noLearningChange(before, after);
  239 |   await attach(info, 'six-themes-four-desktop-widths-and-native-storage', {
  240 |     samples,
  241 |     before,
  242 |     after,
  243 |   });
  244 | });
  245 | 
  246 | test('pointer and keyboard resizing clamp safely, persist independent ratios and restore the defaults', async ({
  247 |   page,
  248 | }, info) => {
  249 |   await openPractice(page);
  250 |   const scope = workbench(page, 'practice');
  251 |   const divider = separator(scope);
  252 |   await expect(divider).toHaveAttribute('aria-valuenow', '50');
  253 |   await divider.focus();
  254 |   await page.keyboard.press('End');
  255 |   await expect(divider).toHaveAttribute('aria-valuenow', '70');
  256 |   await savedRatio(page, 'practice', 70);
  257 |   let sizes = await geometry(scope);
  258 |   expect(sizes.first.width).toBeGreaterThanOrEqual(340);
  259 |   expect(sizes.second.width).toBeGreaterThanOrEqual(420);
  260 |   await noPageOverflow(page);
  261 |   await page.keyboard.press('ArrowRight');
  262 |   await expect(divider).toHaveAttribute('aria-valuenow', '70');
  263 |   await page.keyboard.press('Home');
  264 |   await expect(divider).toHaveAttribute('aria-valuenow', '30');
  265 |   await savedRatio(page, 'practice', 30);
  266 |   sizes = await geometry(scope);
  267 |   expect(sizes.first.width).toBeGreaterThanOrEqual(340);
  268 |   expect(sizes.second.width).toBeGreaterThanOrEqual(420);
  269 |   await page.keyboard.press('ArrowLeft');
  270 |   await expect(divider).toHaveAttribute('aria-valuenow', '30');
  271 |   await page.keyboard.press('ArrowRight');
  272 |   await expect(divider).toHaveAttribute('aria-valuenow', '32');
  273 |   await savedRatio(page, 'practice', 32);
  274 |   await scope.getByRole('button', { name: '恢复默认比例', exact: true }).click();
  275 |   await expect(divider).toHaveAttribute('aria-valuenow', '50');
  276 |   await savedRatio(page, 'practice', 50);
  277 |   await divider.scrollIntoViewIfNeeded();
  278 |   const handle = await divider.boundingBox();
  279 |   const bounds = await scope.boundingBox();
  280 |   expect(handle).not.toBeNull();
  281 |   expect(bounds).not.toBeNull();
  282 |   const dragY =
  283 |     (Math.max(0, handle!.y) + Math.min(page.viewportSize()!.height, handle!.y + handle!.height)) /
  284 |     2;
  285 |   await page.mouse.move(handle!.x + handle!.width / 2, dragY);
  286 |   await page.mouse.down();
  287 |   await page.mouse.move(bounds!.x + bounds!.width * 0.6, dragY, { steps: 12 });
  288 |   // Live drag only changes geometry. The write is committed when the pointer is released.
  289 |   expect((await snapshot(page)).appearance.layout.splitRatios.practice).toBe(50);
  290 |   await page.mouse.up();
  291 |   const dragged = Number(await divider.getAttribute('aria-valuenow'));
  292 |   expect(dragged).toBeGreaterThanOrEqual(57);
  293 |   expect(dragged).toBeLessThanOrEqual(63);
  294 |   await savedRatio(page, 'practice', dragged);
  295 |   await page.reload();
  296 |   await ready(page);
  297 |   await expect(separator(workbench(page, 'practice'))).toHaveAttribute(
  298 |     'aria-valuenow',
  299 |     String(dragged),
  300 |   );
  301 | 
  302 |   await page.goto('/#/visualize/case.c.assignment');
  303 |   await ready(page);
  304 |   await expect(page.getByTestId('case-execution')).toHaveAttribute('data-state', 'ready');
  305 |   const visualDivider = separator(workbench(page, 'visualize'));
  306 |   await expect(visualDivider).toHaveAttribute('aria-valuenow', '35');
```