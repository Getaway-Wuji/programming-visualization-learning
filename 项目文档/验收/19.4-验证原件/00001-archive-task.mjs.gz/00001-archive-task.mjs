import assert from 'node:assert/strict';
import {readdirSync,readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {basename} from 'node:path';
const target='项目文档/验收/19.4-验证原件';assert.equal(existsSync(target),false);
const sha=b=>createHash('sha256').update(b).digest('hex');
const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(d+'/'+e.name):[d+'/'+e.name]);
const excluded='.artifacts/19.4/start-native-4196.log';
const sources=[...walk('.artifacts/19.4'),...walk('tests/.artifacts/19.4'),...walk('tests/ai-browser'),...walk('tests/ai-regression'),'tests/ai-debug.config.ts','tests/ai-regression.config.ts',...walk('tests/unit').filter(p=>/ai-debug/.test(p))].filter(p=>p!==excluded).sort();
assert.equal(new Set(sources).size,sources.length);mkdirSync(target,{recursive:true});
const files=sources.map((source,i)=>{const raw=readFileSync(source),compress=/\.(?:json|log|txt|mjs|ts|tsx|md|css|html|ps1|toml|lock)$/.test(source);const bytes=compress?gzipSync(raw):raw;const file=String(i+1).padStart(5,'0')+'-'+basename(source)+(compress?'.gz':'');writeFileSync(target+'/'+file,bytes,{flag:'wx'});return{source,file,bytes:raw.length,sha256:sha(raw),archiveBytes:bytes.length,archiveSha256:sha(bytes),encoding:compress?'gzip':'identity'};});
const index={version:'1.0.0',task:'19.4',at:new Date().toISOString(),scope:'All independent-engineering QA rounds, failures, original source snapshots,451 frozen65 inputs, native Rust and browser packets, full unfiltered keyed DB9/local/session before-after, formal/candidate/current regression/visual/build/quality/protection and verification scripts. Model answers are simulated; official calls0; task not fully accepted.',exclusions:[{source:excluded,reason:'Retained user-requested live native scene; mutable process log. Exact observed startup separately frozen in production-startup-log.snapshot.txt.'}],files};
writeFileSync(target+'/index.json',JSON.stringify(index,null,2)+'\n',{flag:'wx'});
for(const f of files){const raw=readFileSync(f.source),b=readFileSync(target+'/'+f.file);assert.equal(sha(raw),f.sha256);assert.equal(sha(b),f.archiveSha256);assert.equal(sha(f.encoding==='gzip'?gunzipSync(b):b),f.sha256);}
console.log(JSON.stringify({archive:target,files:files.length,rawBytes:files.reduce((n,f)=>n+f.bytes,0),archiveBytes:files.reduce((n,f)=>n+f.archiveBytes,0),allRawPathsVerified:true,taskAccepted:false}));
