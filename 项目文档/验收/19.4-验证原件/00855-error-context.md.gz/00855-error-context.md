# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-debug.spec.ts >> default off and missing Key make no verification/inference request; ordinary C remains usable
- Location: tests\ai-browser\ai-debug.spec.ts:18:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "请选择"
Error: strict mode violation: getByRole('alert') resolved to 2 elements:
    1) <div role="alert" aria-busy="false" class="state-panel state-error">…</div> aka getByTestId('learning-save-status').getByRole('alert')
    2) <p role="alert" class="notice">请选择受支持的服务和模型，并填写自己的API Key。</p> aka getByText('请选择受支持的服务和模型，并填写自己的API Key。')

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - generic [ref=e68]: 本地学习
        - link "本地数据" [ref=e69] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e73] [cursor=pointer]
    - main [ref=e76]:
      - generic [ref=e77]:
        - navigation "当前位置" [ref=e78]:
          - list [ref=e79]:
            - listitem [ref=e80]:
              - link "学习首页" [ref=e81] [cursor=pointer]:
                - /url: "#/"
            - listitem [ref=e82]:
              - generic [ref=e85]: 本地设置
        - generic [ref=e86]:
          - paragraph [ref=e87]: 你的浏览器，你的学习空间
          - heading "本地设置" [level=1] [ref=e88]
          - paragraph [ref=e89]: 学习档案保存在当前浏览器，不跨设备同步。存储不可用时仅临时使用，未保存内容会在关闭或刷新后丢失。
        - generic [ref=e90]:
          - alert [ref=e91]:
            - generic [ref=e95]:
              - heading "课程更新尚未就绪" [level=2] [ref=e96]
              - paragraph [ref=e97]: 当前课程版本尚未完成发布，暂不能保存新的学习结果。原学习档案已保留，无需清除数据或修改存储权限；更新可用后重新读取即可继续。
              - button "重新读取档案" [ref=e99] [cursor=pointer]
          - paragraph [ref=e100]: 当前处于临时模式。已保存的档案仍保留。请等待课程版本更新后再重试。
        - generic [ref=e101]:
          - tablist "设置分类" [ref=e102]:
            - tab "外观与主题" [ref=e103] [cursor=pointer]
            - tab "基础形象" [ref=e106] [cursor=pointer]
            - tab "显示设置" [ref=e109] [cursor=pointer]
            - tab "AI解释（可选）" [selected] [ref=e112] [cursor=pointer]
            - tab "本地数据" [ref=e115] [cursor=pointer]
          - tabpanel "AI解释（可选）" [ref=e118]:
            - region [ref=e119]:
              - generic [ref=e120]:
                - generic [ref=e121]:
                  - heading "AI解释（可选）" [level=2] [ref=e122]
                  - paragraph [ref=e123]: 默认关闭。只在当前标签页临时启用，刷新或退出工作台后关闭；正常学习无需开启。
                - status [ref=e124]: 未开启
              - generic [ref=e125]:
                - generic [ref=e126]:
                  - generic [ref=e127]: AI服务
                  - combobox "AI服务" [ref=e128]:
                    - option "请选择服务" [selected]
                    - option "OpenAI 官方API"
                    - option "DeepSeek 官方API"
                - generic [ref=e129]:
                  - generic [ref=e130]: 模型
                  - combobox "AI模型" [disabled] [ref=e131]:
                    - option "请选择模型" [selected]
                - generic [ref=e132]:
                  - generic [ref=e133]: 你自己的API Key
                  - textbox "你自己的API Key" [ref=e134]
                - paragraph [ref=e135]: 验证会经本平台同源转发，把Key发送到你选择的官方服务，不发送代码，也不调用推理。平台转发方会接触当次Key；Key不会保存到学习档案。
                - generic [ref=e136]:
                  - switch "验证并开启AI解释" [active] [ref=e137] [cursor=pointer]
                  - button "清除AI配置" [ref=e138] [cursor=pointer]
              - alert [ref=e139]: 请选择受支持的服务和模型，并填写自己的API Key。
              - paragraph [ref=e140]: 关闭、刷新、离开工作台或清除学习数据会丢弃Key。每次发送代码前另行预览确认；此处不会自动请求解释。
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import {
  3   |   enable,
  4   |   evidence,
  5   |   instrumentation,
  6   |   native,
  7   |   preview,
  8   |   send,
  9   |   settings,
  10  |   workbench,
  11  | } from './helpers';
  12  | const sources = {
  13  |   pointer:
  14  |     '#include <stdio.h>\nint main(){int *p=0;int value=*p;printf("%d\\n",value);return 0;}\n',
  15  |   loop: '#include <stdio.h>\nint main(){int sum=0;for(int i=0;i<3;i++){sum=sum+i;}printf("%d",sum);return 0;}\n',
  16  |   syntax: 'int main( { return 0; }',
  17  | };
  18  | test('default off and missing Key make no verification/inference request; ordinary C remains usable', async ({
  19  |   page,
  20  | }, info) => {
  21  |   const c = await instrumentation(page);
  22  |   await settings(page);
  23  |   await expect(page.getByRole('switch')).toHaveAttribute('aria-checked', 'false');
  24  |   await expect(page.getByRole('combobox', { name: 'AI服务', exact: true })).toHaveValue('');
  25  |   await page.getByRole('switch').click();
> 26  |   await expect(page.getByRole('alert')).toContainText('请选择');
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  27  |   expect(c.verifies).toBe(0);
  28  |   await page.getByRole('link', { name: 'C 代码工作台', exact: true }).click();
  29  |   await page.getByRole('textbox', { name: 'C 代码', exact: true }).fill(sources.loop);
  30  |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  31  |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  32  |   expect(c.requests).toHaveLength(0);
  33  |   await evidence(page, c, info);
  34  | });
  35  | for (const kind of ['pointer', 'loop', 'syntax'] as const)
  36  |   test(`actual Rust ${kind}, exact preview and simulated API references, never a real AI answer`, async ({
  37  |     page,
  38  |   }, info) => {
  39  |     const c = await instrumentation(page);
  40  |     await enable(page);
  41  |     await workbench(page, sources[kind]);
  42  |     await preview(page);
  43  |     expect(c.requests).toHaveLength(0);
  44  |     if (kind === 'syntax')
  45  |       await expect(page.getByText('本次语法或前置检查没有轨迹', { exact: false })).toBeVisible();
  46  |     await page.getByRole('button', { name: '确认并发送本次内容', exact: true }).click();
  47  |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toBeVisible();
  48  |     expect(c.requests).toHaveLength(1);
  49  |     const req = c.requests[0];
  50  |     expect(req.context.runRef.language).toBe('c');
  51  |     expect(req.context.snippets.map((s) => s.text).join('')).toContain(
  52  |       kind === 'syntax' ? 'int main' : 'int main',
  53  |     );
  54  |     expect(req.context.facts.length).toBeGreaterThan(0);
  55  |     if (kind === 'syntax') {
  56  |       expect(req.context.traceAvailable).toBe(false);
  57  |       expect(req.context.facts.every((f) => f.kind === 'diagnostic')).toBe(true);
  58  |       await expect(page.getByRole('button', { name: /查看真实步骤/ })).toHaveCount(0);
  59  |       await page.getByRole('button', { name: '查看真实诊断源码', exact: true }).click();
  60  |       await expect(page.getByRole('textbox', { name: 'C 代码', exact: true })).toBeFocused();
  61  |     } else {
  62  |       const step = req.context.facts.find((f) => f.kind === 'step');
  63  |       expect(step).toBeDefined();
  64  |       if (step?.kind === 'step') {
  65  |         await page.getByRole('button', { name: `查看真实步骤 ${step.step}`, exact: true }).click();
  66  |         await expect(page.getByTestId('custom-code-page')).toHaveAttribute(
  67  |           'data-cursor',
  68  |           String(step.step),
  69  |         );
  70  |       }
  71  |     }
  72  |     await evidence(page, c, info);
  73  |   });
  74  | for (const mode of ['auth', 'quota', 'rate', 'badref', 'stale', 'blank'] as const)
  75  |   test(`simulated ${mode} failure has fixed fallback and real execution still works`, async ({
  76  |     page,
  77  |   }, info) => {
  78  |     const c = await instrumentation(page);
  79  |     await enable(page, 'deepseek');
  80  |     await workbench(page, sources.pointer);
  81  |     c.mode = mode;
  82  |     await send(page);
  83  |     await expect(page.locator('.ai-panel [role=alert]')).toBeVisible();
  84  |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  85  |     await page.getByRole('button', { name: '运行代码', exact: true }).click();
  86  |     await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  87  |     expect(c.requests).toHaveLength(1);
  88  |     await evidence(page, c, info);
  89  |   });
  90  | test('simulated HTML answer is plain text and never loads an image or URL', async ({
  91  |   page,
  92  | }, info) => {
  93  |   const c = await instrumentation(page);
  94  |   await enable(page);
  95  |   await workbench(page, sources.loop);
  96  |   c.mode = 'html';
  97  |   await send(page);
  98  |   await expect(page.locator('.ai-answer')).toContainText('<img src=');
  99  |   await expect(page.locator('.ai-answer img')).toHaveCount(0);
  100 |   await evidence(page, c, info);
  101 | });
  102 | for (const action of ['cancel', 'source', 'input', 'cursor'] as const)
  103 |   test(`${action} invalidates an in-flight simulated answer`, async ({ page }, info) => {
  104 |     const c = await instrumentation(page);
  105 |     await enable(page);
  106 |     await workbench(page, sources.loop);
  107 |     c.mode = 'delay';
  108 |     c.delay = 700;
  109 |     await send(page);
  110 |     await expect(page.getByText('正在等待OpenAI解释', { exact: false })).toBeVisible();
  111 |     if (action === 'cancel')
  112 |       await page.getByRole('button', { name: '取消本端等待', exact: true }).click();
  113 |     else if (action === 'source') {
  114 |       await page.getByRole('button', { name: '编辑代码', exact: true }).click();
  115 |       await page
  116 |         .getByRole('textbox', { name: 'C 代码', exact: true })
  117 |         .fill('int main(){return 0;}');
  118 |     } else if (action === 'input')
  119 |       await page.getByRole('textbox', { name: '整数输入', exact: true }).fill('8');
  120 |     else await page.getByRole('button', { name: '后退', exact: true }).click();
  121 |     await expect(page.getByRole('heading', { name: '确认本次发送内容', exact: true })).toHaveCount(
  122 |       0,
  123 |     );
  124 |     await page.waitForTimeout(800);
  125 |     await expect(page.getByRole('heading', { name: 'AI解释', exact: true })).toHaveCount(0);
  126 |     await evidence(page, c, info);
```