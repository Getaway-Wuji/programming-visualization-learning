import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {writeFileSync,appendFileSync} from 'node:fs';
const status={};
for(const task of ['typecheck','lint','format:check']){
 const log='.artifacts/18-quality/'+task.replace(':','-')+'.log';writeFileSync(log,'',{flag:'wx'});
 const child=spawn('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/task.ps1',task]);
 for(const stream of [child.stdout,child.stderr])stream.on('data',b=>appendFileSync(log,b));
 status[task]=await new Promise((resolve,reject)=>{child.on('close',resolve);child.on('error',reject);});console.log(task+':'+status[task]);
}
writeFileSync('.artifacts/18-quality/quality-status.json',JSON.stringify(status,null,2)+'\n',{flag:'wx'});assert(Object.values(status).every(v=>v===0));
