import assert from 'node:assert/strict';
import {readFileSync,existsSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {resolve,dirname} from 'node:path';
const read=p=>readFileSync(p),json=p=>JSON.parse(read(p)),hb=b=>createHash('sha256').update(b).digest('hex'),hash=p=>hb(read(p));
const proof=json('项目文档/验收/18-整块质量最终复核.json');assert.equal(proof.status,'accepted');assert.equal(proof.qaDebt.startsWith('resolved'),true);assert.equal(hash(proof.qaArchive.path),proof.qaArchive.indexSha256);assert.equal(hash(proof.beforeFreeze.path),proof.beforeFreeze.sha256);assert.equal(hash(proof.auditSource.path),proof.auditSource.sha256);
let qa=0;const archives=[];
for(const path of ['项目文档/验收/18.1-验证原件/index.json','项目文档/验收/18.2-验证原件/index.json','项目文档/验收/18.3-验证原件/index.json','项目文档/验收/18.4-验证原件/index.json','项目文档/验收/18.5-验证原件/index.json','项目文档/验收/18.6-验证原件/index.json',proof.beforeFreeze.path,proof.qaArchive.path]){
 const index=json(path),dir=dirname(path);for(const f of index.files){const b=read(dir+'/'+f.file);assert.equal(hb(b),f.archiveSha256);assert.equal(hb(f.encoding==='gzip'?gunzipSync(b):b),f.sha256);if(path!==proof.beforeFreeze.path||f.source!=='tests/browser/case-set.spec.ts')assert.equal(hash(f.source),f.sha256,f.source);}qa+=index.files.length;archives.push({path,files:index.files.length});
}
assert.equal(qa,2015+13+proof.qaArchive.files);
const base=json('.artifacts/18-quality/baseline.json'),changed=base.files.filter(f=>!existsSync(f.path)||hash(f.path)!==f.sha256).map(f=>f.path).sort();assert.deepEqual(changed,[...proof.baselineChanged].sort());assert.equal(changed.length,6);
for(const d of proof.documents)assert.equal(hash(d.path),d.sha256,d.path);
const reg=json(proof.registration.path);assert.equal(hash(proof.registration.path),proof.registration.sha256);for(const f of reg.files)assert.equal(hash(f.path),f.sha256,f.path);for(const f of proof.wasm)assert.equal(hash(f.path),f.sha256);for(const f of proof.inherited.evidence)assert.equal(hash(f.path),f.sha256);
const git=a=>execFileSync('git',a,{maxBuffer:64*1024*1024}).toString();assert.equal(git(['rev-parse','HEAD']).trim(),proof.head);assert.equal(git(['diff','--cached','--name-only']),'');assert.equal(git(['rev-list','--left-right','--count','HEAD...origin/main']).trim(),'0\t0');git(['-c','core.whitespace=cr-at-eol','diff','--check','--',...changed]);
let links=0;const docs=[];for(const dir of ['项目文档/架构决策','项目文档/契约','项目文档/验收','项目文档/交接','项目文档/交付'])for(const name of readdirSync(dir))if(/^18\.[1-6]-.*\.md$/.test(name))docs.push(dir+'/'+name);docs.push('项目文档/架构决策/18-整块QA维护范围.md','项目文档/验收/18-整块质量复核.md','项目文档/交接/18-整块质量-交接.md');
function checkLinks(p,text){for(const m of text.matchAll(/\[[^\]]*\]\(([^)]+)\)/g)){const h=m[1].replace(/^<|>$/g,'').split('#')[0];if(!h||/^[a-z][a-z\d+.-]*:/i.test(h))continue;assert(existsSync(resolve(dirname(p),decodeURIComponent(h))),p+' -> '+h);links++;}}
for(const p of docs)checkLinks(p,read(p).toString());assert.equal(links,proof.links.localLinks);
for(const p of ['README.md','项目守则.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md']){const first=read(p).toString().split(/\r?\n/).slice(0,4).join('\n');assert(first.includes('整块质量复核通过'));checkLinks(p,first);}
const ledger=read('项目文档/任务进度与交接.md').toString();assert.match(ledger,/\| 19\.1 \|[^\r\n]+\| 未开始 \|/);assert(ledger.includes('整块QA债务已消除'));assert(ledger.includes('原79/88、余9，主路线79/98'));
console.log(JSON.stringify({status:'accepted',head:proof.head,staged:0,aheadBehind:[0,0],baseline:base.files.length,changed:changed.length,unchanged:base.files.length-changed.length,productSources:reg.files.length,oldQa:2015,beforeQa:13,newQa:proof.qaArchive.files,allArchiveRawAndSourceShaVerified:true,archives,relativeLinks:links,quality:proof.quality,finalChrome:proof.browser.stats.expected,fullPublicInputs:42,fullAtomicWalks:7,pauseResumeRates:42,genuineExecutions:43,qaDebt:'resolved',next:'Coordinator Git dispatch; no19/21'},null,2));
