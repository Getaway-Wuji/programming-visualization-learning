# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: case-set.spec.ts >> all four demonstration and three algorithm catalog links open the correct real input workspace
- Location: tests\browser\case-set.spec.ts:774:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.case-card .card-link')
Expected: 7
Received: 15
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.case-card .card-link') with timeout 5000ms
  - waiting for locator('.case-card .card-link')
    - locator resolved to 0 elements
    - unexpected value "0"
    13 × locator resolved to 15 elements
       - unexpected value "15"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - generic [ref=e68]: 本地学习
        - link "本地数据" [ref=e69] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e73] [cursor=pointer]
    - main [ref=e76]:
      - generic [ref=e77]:
        - navigation "当前位置" [ref=e78]:
          - list [ref=e79]:
            - listitem [ref=e80]:
              - link "学习首页" [ref=e81] [cursor=pointer]:
                - /url: "#/"
            - listitem [ref=e82]:
              - generic [ref=e85]: 算法与演示
        - generic [ref=e86]:
          - paragraph [ref=e87]: 看懂程序怎样执行
          - heading "让数据变化，有迹可循。" [level=1] [ref=e88]
          - paragraph [ref=e89]: 选择案例、输入数据，运行实际源码并逐步查看变化。原C案例完整观看后主动确认可获首次奖励；新增C++观察不计积分。
        - generic [ref=e90]:
          - paragraph [ref=e91]: 标准内容样例 · 尚未正式发布
          - paragraph [ref=e92]: 内容版本 1.0.0 · 只读预览，浏览不会产生学习记录或奖励。
          - paragraph [ref=e93]: 已读取 4 个语法演示和 3 个算法案例样例。下方 7 个已审核案例独立开放观看确认；本样例目录的读取与检查不触发奖励。选择案例后可查看讲解、设置输入并运行，支持单步、回退与重播。
        - paragraph [ref=e94]: 建议按顺序学习：基础语法演示 → 排序与查找 → 数据结构 → 经典问题与进阶观察。
        - generic [ref=e95]:
          - generic [ref=e96]:
            - heading "基础语法演示" [level=2] [ref=e97]
            - generic [ref=e98]: 4 个语法演示
          - generic [ref=e99]:
            - article [ref=e100]:
              - heading "变量赋值" [level=3] [ref=e104]
              - paragraph [ref=e105]: 观察变量的值怎样改变。
              - generic [ref=e106]: 可运行与回放
              - paragraph [ref=e107]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e108] [cursor=pointer]:
                - /url: "#/visualize/case.c.assignment"
            - article [ref=e111]:
              - heading "分支判断" [level=3] [ref=e115]
              - paragraph [ref=e116]: 看清条件选择了哪条执行路径。
              - generic [ref=e117]: 可运行与回放
              - paragraph [ref=e118]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e119] [cursor=pointer]:
                - /url: "#/visualize/case.c.branch"
            - article [ref=e122]:
              - heading "循环" [level=3] [ref=e126]
              - paragraph [ref=e127]: 认识 while 和 for 的重复过程。
              - generic [ref=e128]: 可运行与回放
              - paragraph [ref=e129]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e130] [cursor=pointer]:
                - /url: "#/visualize/case.c.loops"
            - article [ref=e133]:
              - heading "数组遍历" [level=3] [ref=e137]
              - paragraph [ref=e138]: 逐个访问数组中的元素。
              - generic [ref=e139]: 可运行与回放
              - paragraph [ref=e140]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e141] [cursor=pointer]:
                - /url: "#/visualize/case.c.array-traversal"
        - generic [ref=e144]:
          - generic [ref=e145]:
            - heading "排序与查找" [level=2] [ref=e146]
            - generic [ref=e147]: 3 个算法案例
          - generic [ref=e148]:
            - article [ref=e149]:
              - heading "冒泡排序" [level=3] [ref=e153]
              - paragraph [ref=e154]: 比较相邻元素，理解交换的作用。
              - generic [ref=e155]: 可运行与回放
              - paragraph [ref=e156]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e157] [cursor=pointer]:
                - /url: "#/visualize/case.c.bubble-sort"
            - article [ref=e160]:
              - heading "选择排序" [level=3] [ref=e164]
              - paragraph [ref=e165]: 寻找最小值，逐步整理数组。
              - generic [ref=e166]: 可运行与回放
              - paragraph [ref=e167]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e168] [cursor=pointer]:
                - /url: "#/visualize/case.c.selection-sort"
            - article [ref=e171]:
              - heading "二分搜索首次匹配" [level=3] [ref=e175]
              - paragraph [ref=e176]: 在有序数组中缩小查找范围。
              - paragraph [ref=e177]: 输入须为非递减数组。
              - generic [ref=e178]: 可运行与回放
              - paragraph [ref=e179]: 尚无已保存的学习记录
              - link "查看演示工作区" [ref=e180] [cursor=pointer]:
                - /url: "#/visualize/case.c.binary-search-first"
        - region [ref=e183]:
          - generic [ref=e184]:
            - heading "C++ · 迭代排序" [level=2] [ref=e185]
            - generic [ref=e186]: 3个独立案例
          - paragraph [ref=e187]: 通过实际C++程序观察插入、间隔分组和计数回填。此组观察不记课程进度或积分。
          - generic [ref=e188]:
            - article [ref=e189]:
              - heading "插入排序" [level=3] [ref=e190]
              - paragraph [ref=e191]: 暂存一个数，将左侧较大的元素右移，再放回空位。
              - paragraph [ref=e192]: 0～30项 · -999～999 · C++受支持子集
              - link "查看插入排序工作区 →" [ref=e193] [cursor=pointer]:
                - /url: "#/algorithms/case.cpp.insertion-sort"
            - article [ref=e194]:
              - heading "希尔排序" [level=3] [ref=e195]
              - paragraph [ref=e196]: 按逐次减半的间隔做插入，最后以间隔1完成整理。
              - paragraph [ref=e197]: 0～30项 · -999～999 · C++受支持子集
              - link "查看希尔排序工作区 →" [ref=e198] [cursor=pointer]:
                - /url: "#/algorithms/case.cpp.shell-sort"
            - article [ref=e199]:
              - heading "计数排序" [level=3] [ref=e200]
              - paragraph [ref=e201]: 将−20～20映射到41个频率桶，再从小到大回填原数组。
              - paragraph [ref=e202]: 0～30项 · -20～20 · C++受支持子集
              - link "查看计数排序工作区 →" [ref=e203] [cursor=pointer]:
                - /url: "#/algorithms/case.cpp.counting-sort"
        - region [ref=e204]:
          - generic [ref=e205]:
            - heading "C++ · 递归排序" [level=2] [ref=e206]
            - generic [ref=e207]: 2个独立案例与同数据对比
          - paragraph [ref=e208]: 观察真实调用帧、共享数组别名与当前存储。归并借助辅助数组，快速递归较小区间；不计课程进度或积分。
          - generic [ref=e209]:
            - article [ref=e210]:
              - heading "归并排序" [level=3] [ref=e211]
              - paragraph [ref=e212]: 递归整理两个闭区间，借助同一个辅助数组合并，再写回原区间。
              - paragraph [ref=e213]: 0～30项 · −999～999 · C++受支持子集
              - link "查看归并排序工作区 →" [ref=e214] [cursor=pointer]:
                - /url: "#/algorithms/case.cpp.merge-sort"
            - article [ref=e215]:
              - heading "快速排序" [level=3] [ref=e216]
              - paragraph [ref=e217]: 以区间末项为枢轴分区，递归较小的一侧，在当前帧循环处理较大的一侧。
              - paragraph [ref=e218]: 0～30项 · −999～999 · C++受支持子集
              - link "查看快速排序工作区 →" [ref=e219] [cursor=pointer]:
                - /url: "#/algorithms/case.cpp.quick-sort"
          - paragraph [ref=e220]:
            - link "归并与快速 · 同数据对比 →" [ref=e221] [cursor=pointer]:
              - /url: "#/compare?pair=cpp-recursive"
        - region [ref=e222]:
          - generic [ref=e223]:
            - heading "C++ · 桶排序" [level=2] [ref=e224]
            - generic [ref=e225]: 1个独立案例
          - paragraph [ref=e226]: 五个固定桶、真实槽位与桶内插入。物理容量与逻辑数量分开显示，不计课程进度或积分。
          - article [ref=e227]:
            - heading "桶排序" [level=3] [ref=e228]
            - paragraph [ref=e229]: 将有限域整数依序放入五个桶，在桶内插入排序，再按桶序写回原数组。
            - paragraph [ref=e230]: 0～30项 · −20～29 · 五桶各30槽 · C++受支持子集
            - link "查看桶排序工作区 →" [ref=e231] [cursor=pointer]:
              - /url: "#/algorithms/case.cpp.bucket-sort"
        - paragraph [ref=e232]:
          - link "打开同数据双算法对比" [ref=e233] [cursor=pointer]:
            - /url: "#/compare"
          - text: 比较冒泡与选择排序，或归并与快速排序。
        - region [ref=e234]:
          - generic [ref=e235]:
            - heading "C++ · 栈与队列" [level=2] [ref=e236]
            - generic [ref=e237]: 2个操作案例
          - paragraph [ref=e238]: 给出入/出操作序列，真实执行后核对有效项、物理残值与空满结果。容量各5，不计学习进度或积分。
          - generic [ref=e239]:
            - article [ref=e240]:
              - heading "数组栈" [level=3] [ref=e241]
              - paragraph [ref=e242]: 沿真实C++操作观察后进先出，分清有效栈项、容量端点与物理残值。
              - paragraph [ref=e243]: 最多30个编码整数槽 · −999～999 · C++受支持子集
              - link "查看数组栈工作区 →" [ref=e244] [cursor=pointer]:
                - /url: "#/structures/case.cpp.array-stack"
            - article [ref=e245]:
              - heading "环形队列" [level=3] [ref=e246]
              - paragraph [ref=e247]: 沿真实C++操作观察先进先出，用读写序号取模复用五个物理槽。
              - paragraph [ref=e248]: 最多30个编码整数槽 · −999～999 · C++受支持子集
              - link "查看环形队列工作区 →" [ref=e249] [cursor=pointer]:
                - /url: "#/structures/case.cpp.circular-queue"
        - generic [ref=e250]:
          - heading "C++链表与树" [level=2] [ref=e251]
          - paragraph [ref=e252]: 真实动态节点与指针操作，和内存/调用栈共用同一执行步骤；观察不计课程或积分。
          - generic [ref=e253]:
            - article [ref=e254]:
              - heading "单链表" [level=3] [ref=e255]
              - paragraph [ref=e256]: 沿真实指针逐步核对位置插入、断链删除与遍历，分清存活节点和释放墓碑。
              - paragraph [ref=e257]: 容量7 · 原输入最多30整数槽 · C++子集
              - link "查看单链表工作区 →" [ref=e258] [cursor=pointer]:
                - /url: "#/nodes/case.cpp.singly-linked-list"
            - article [ref=e259]:
              - heading "二叉搜索树（BST）" [level=3] [ref=e260]
              - paragraph [ref=e261]: 沿真实左右指针观察插入与查找，用同一游标核对前中后序递归和释放。
              - paragraph [ref=e262]: 容量7 · 原输入最多30整数槽 · C++子集
              - link "查看二叉搜索树（BST）工作区 →" [ref=e263] [cursor=pointer]:
                - /url: "#/nodes/case.cpp.binary-search-tree"
        - generic [ref=e264]:
          - heading "C++经典问题" [level=2] [ref=e265]
          - paragraph [ref=e266]: 真实数值、盘位置与调用栈回放；四例独立观察不计课程或积分。
          - generic [ref=e267]:
            - article [ref=e268]:
              - heading "汉诺塔" [level=3] [ref=e269]
              - paragraph [ref=e270]: 读取真实盘位置数组，逐步核对递归调用、合法移动与同游标回退。
              - paragraph [ref=e271]: 一个0～5的整数盘数；0盘合法，最多31次移动。
              - link "查看汉诺塔工作区 →" [ref=e272] [cursor=pointer]:
                - /url: "#/classics/case.cpp.hanoi"
            - article [ref=e273]:
              - heading "辗转相除法求GCD" [level=3] [ref=e274]
              - paragraph [ref=e275]: 逐步观察符号归一、余数和a/b的真实变化，明确零参数约定。
              - paragraph [ref=e276]: 两个−999～999整数；结果非负，本例约定gcd(0,0)=0。
              - link "查看辗转相除法求GCD工作区 →" [ref=e277] [cursor=pointer]:
                - /url: "#/classics/case.cpp.euclidean-gcd"
            - article [ref=e278]:
              - heading "朴素素数判断" [level=3] [ref=e279]
              - paragraph [ref=e280]: 从2逐个尝试实际因子，观察判断、早停及0/1/负数边界。
              - paragraph [ref=e281]: 一个−999～999整数；低于2都不是素数。
              - link "查看朴素素数判断工作区 →" [ref=e282] [cursor=pointer]:
                - /url: "#/classics/case.cpp.trial-division-prime"
            - article [ref=e283]:
              - heading "回文数" [level=3] [ref=e284]
              - paragraph [ref=e285]: 读取真实拆位和完整反转过程，核对负号、零和尾零规则。
              - paragraph [ref=e286]: 一个−999～999整数；负数判否，非负数完整反转比较。
              - link "查看回文数工作区 →" [ref=e287] [cursor=pointer]:
                - /url: "#/classics/case.cpp.palindrome-number"
        - region [ref=e288]:
          - generic [ref=e289]:
            - heading "筛法与序列 · C++" [level=2] [ref=e290]
            - link "查看四个算法 →" [ref=e291] [cursor=pointer]:
              - /url: "#/advanced/algorithms"
          - paragraph [ref=e292]: 从真实标记和递推状态理解算法。四个阅读案例不计学习完成或积分，基础准备与复习仍用统一档案。
          - list [ref=e293]:
            - listitem [ref=e294]:
              - generic [ref=e295]:
                - heading [level=3] [ref=e296]:
                  - link "埃氏筛" [ref=e297] [cursor=pointer]:
                    - /url: "#/advanced/algorithms/case.cpp.eratosthenes-sieve"
                - paragraph [ref=e298]: 逐步排除合数
              - generic [ref=e299]: 上界0～30
            - listitem [ref=e300]:
              - generic [ref=e301]:
                - heading [level=3] [ref=e302]:
                  - link "欧拉筛" [ref=e303] [cursor=pointer]:
                    - /url: "#/advanced/algorithms/case.cpp.euler-sieve"
                - paragraph [ref=e304]: 每个合数只标记一次
              - generic [ref=e305]: 上界0～30
            - listitem [ref=e306]:
              - generic [ref=e307]:
                - heading [level=3] [ref=e308]:
                  - link "最大连续子序列和" [ref=e309] [cursor=pointer]:
                    - /url: "#/advanced/algorithms/case.cpp.maximum-subarray"
                - paragraph [ref=e310]: 保留以当前位置结尾的最优和
              - generic [ref=e311]: 序列0～30项
            - listitem [ref=e312]:
              - generic [ref=e313]:
                - heading [level=3] [ref=e314]:
                  - link "最长上升子序列" [ref=e315] [cursor=pointer]:
                    - /url: "#/advanced/algorithms/case.cpp.strict-lis"
                - paragraph [ref=e316]: 严格上升，不要求连续
              - generic [ref=e317]: 序列0～30项
        - region [ref=e318]:
          - generic [ref=e319]:
            - heading "字符串匹配 · C++" [level=2] [ref=e320]
            - link "打开KMP →" [ref=e321] [cursor=pointer]:
              - /url: "#/advanced/algorithms/case.cpp.kmp"
          - paragraph [ref=e322]: 沿真实前缀表和失配回退理解首个匹配；两个输入字段分别保留空串和空格，不计学习完成或积分。
          - list [ref=e323]:
            - listitem [ref=e324]:
              - generic [ref=e325]:
                - heading [level=3] [ref=e326]:
                  - link "KMP字符串匹配" [ref=e327] [cursor=pointer]:
                    - /url: "#/advanced/algorithms/case.cpp.kmp"
                - paragraph [ref=e328]: 前缀构造、字符比较与模式指针回退
              - generic [ref=e329]: 两行ASCII，各0～30字节
        - region [ref=e330]:
          - heading "进阶观察 · 内存与调用栈" [level=2] [ref=e332]
          - paragraph [ref=e333]:
            - link "打开内存观察 →" [ref=e334] [cursor=pointer]:
              - /url: "#/memory"
            - text: 逐步查看指针、对象与教学地址。
          - paragraph [ref=e335]:
            - link "打开递归与调用栈 →" [ref=e336] [cursor=pointer]:
              - /url: "#/memory?example=hanoi&view=stack"
            - text: 观察函数进入、返回及局部状态，点击源码行号设置断点。
```

# Test source

```ts
  678 |     test.setTimeout(120_000);
  679 |     await observeCaseSetExecution(page);
  680 |     await observeViews(page);
  681 |     await openCase(page, caseId);
  682 |     const before = await storageSnapshot(page);
  683 |     const samples = caseSetSamples
  684 |       .filter((sample) => sample.caseId === caseId)
  685 |       .toSorted((left, right) => {
  686 |         const priority = (sample: CaseSetSample) =>
  687 |           sample.key.endsWith('-maximum') ? -1 : sample.walk ? 1 : 0;
  688 |         return priority(left) - priority(right);
  689 |       });
  690 |     expect(samples.filter((sample) => sample.walk)).toHaveLength(1);
  691 |     let executeCount = 0;
  692 |     const identities = new Set<string>();
  693 |     for (const sample of samples) {
  694 |       if (executeCount > 0) {
  695 |         // Keep large raw evidence from earlier samples out of this run's
  696 |         // receive deadline. Each input gets an independent real document;
  697 |         // replay still uses the representative's one accepted trajectory.
  698 |         await page.goto('about:blank');
  699 |         await openCase(page, caseId);
  700 |         expect(await storageSnapshot(page)).toEqual(before);
  701 |       }
  702 |       const run = await prepareRun(page, sample);
  703 |       executeCount++;
  704 |       expect(identities.has(run.request.identity.runId)).toBe(false);
  705 |       identities.add(run.request.identity.runId);
  706 |       const walk = sample.walk ? await walkAndRecover(page, run, sample, testInfo) : null;
  707 |       const rates = sample.walk ? await playAtAllRates(page, run) : [];
  708 |       expect(
  709 |         await page.evaluate(
  710 |           () =>
  711 |             window.__verticalObservation.workers.filter((worker) => worker.kind === 'execute')
  712 |               .length,
  713 |         ),
  714 |       ).toBe(1);
  715 |       await saveCapture(page, run, sample, testInfo, before, walk, rates);
  716 |     }
  717 |     expect(await storageSnapshot(page)).toEqual(before);
  718 |   });
  719 | }
  720 | 
  721 | test('binary input refuses unsorted and invalid drafts before preparing, preserves order and recovers', async ({
  722 |   page,
  723 | }, testInfo) => {
  724 |   await observeCaseSetExecution(page);
  725 |   await observeViews(page);
  726 |   await openCase(page, 'case.c.binary-search-first');
  727 |   const before = await storageSnapshot(page);
  728 |   const rejected = [];
  729 |   for (const draft of [
  730 |     { values: '3, 1, 2', target: '1', message: '非递减' },
  731 |     { values: '1, 2, 3', target: '1000', message: '999' },
  732 |     { values: '1, 2.5, 3', target: '1', message: '十进制整数' },
  733 |     { values: Array.from({ length: 31 }, (_, at) => at).join(', '), target: '1', message: '30' },
  734 |   ]) {
  735 |     await page.getByTestId('input-field-values').fill(draft.values);
  736 |     await page.getByTestId('input-field-target').fill(draft.target);
  737 |     await expect(page.getByTestId('input-errors')).toContainText(draft.message);
  738 |     await expect(
  739 |       panel(page).getByRole('button', { name: '应用输入并准备', exact: true }),
  740 |     ).toBeDisabled();
  741 |     await expect(
  742 |       panel(page).getByRole('button', { name: '准备运行样例', exact: true }),
  743 |     ).toBeDisabled();
  744 |     await expect(page.getByTestId('input-field-values')).toHaveValue(draft.values);
  745 |     expect(
  746 |       await page.evaluate(() =>
  747 |         window.__verticalObservation.workers.filter((worker) =>
  748 |           ['prepare-case', 'execute'].includes(worker.kind),
  749 |         ),
  750 |       ),
  751 |     ).toEqual([]);
  752 |     rejected.push({ ...draft, workers: 0 });
  753 |   }
  754 |   const sample = caseSetSamples.find((sample) => sample.key === 'search-duplicate')!;
  755 |   const recovered = await prepareRun(page, sample);
  756 |   expect(recovered.request.input.values.values).toEqual([-2, 0, 0, 4, 8]);
  757 |   expect(await storageSnapshot(page)).toEqual(before);
  758 |   await saveCapture(page, recovered, sample, testInfo, before, null, [], 'binary-input-recovery');
  759 |   await testInfo.attach('08.4-binary-input-rejection-and-recovery', {
  760 |     body: JSON.stringify({
  761 |       rejected,
  762 |       recovery: {
  763 |         producer: recovered.result.producer,
  764 |         values: recovered.request.input.values,
  765 |         stdout: recovered.finalOutput,
  766 |         identity: recovered.request.identity,
  767 |       },
  768 |       storageUnchanged: true,
  769 |     }),
  770 |     contentType: 'application/json',
  771 |   });
  772 | });
  773 | 
  774 | test('all four demonstration and three algorithm catalog links open the correct real input workspace', async ({
  775 |   page,
  776 | }, testInfo) => {
  777 |   await page.goto('/#/cases');
> 778 |   await expect(page.locator('.case-card .card-link')).toHaveCount(7);
      |                                                       ^ Error: expect(locator).toHaveCount(expected) failed
  779 |   const visited = [];
  780 |   for (const caseId of caseSetIds) {
  781 |     const link = page.locator(`.case-card a[href="#/visualize/${caseId}"]`);
  782 |     await expect(link).toBeVisible();
  783 |     await link.click();
  784 |     await expect(page).toHaveURL(new RegExp(`#/visualize/${caseId.replaceAll('.', '\\.')}$`, 'u'));
  785 |     await expect(page.getByTestId('input-panel')).toBeVisible();
  786 |     await expect(panel(page)).toHaveAttribute('data-state', 'ready');
  787 |     await expect(panel(page).getByRole('button', { name: '运行示例', exact: true })).toBeEnabled();
  788 |     await expect(
  789 |       page.getByRole('textbox', { name: '当前执行的 C 代码', exact: true }),
  790 |     ).not.toHaveValue('');
  791 |     visited.push({ caseId, route: new URL(page.url()).hash });
  792 |     await page.getByRole('link', { name: '返回案例目录', exact: true }).click();
  793 |     await expect(page).toHaveURL(/#\/cases$/u);
  794 |   }
  795 |   await testInfo.attach('08.4-seven-catalog-links', {
  796 |     body: JSON.stringify(visited),
  797 |     contentType: 'application/json',
  798 |   });
  799 | });
  800 | 
```