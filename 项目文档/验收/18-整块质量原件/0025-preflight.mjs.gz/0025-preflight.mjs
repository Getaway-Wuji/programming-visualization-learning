import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gzipSync, gunzipSync } from 'node:zlib';
import { caseSetIds, caseSetSamples } from '../../tests/fixtures/case-set.ts';
const root = '.artifacts/18-quality';
const read = p => readFileSync(p), hash = b => createHash('sha256').update(b).digest('hex');
const json = p => JSON.parse(read(p).toString().replace(/^\uFEFF/, ''));
const save = (p, v) => writeFileSync(p, JSON.stringify(v, null, 2) + '\n', {flag:'wx'});
const git = args => execFileSync('git', args, {maxBuffer:64*1024*1024}).toString();
mkdirSync(root, {recursive:true});
assert.equal(git(['diff','--cached','--name-only']), '');
const files = git(['ls-files','--cached','--others','--exclude-standard','-z']).split('\0').filter(Boolean);
const proof = files.map(path => ({path,sha256:hash(read(path))}));
save(root+'/baseline.json', {at:new Date().toISOString(),head:git(['rev-parse','HEAD']).trim(),aheadBehind:git(['rev-list','--left-right','--count','HEAD...origin/main']).trim(),files:proof});
const reg = json('content/c/p0/blockly-release-1.0.59.json');
assert.equal(reg.files.length,394);
for(const f of reg.files) assert.equal(hash(read(f.path)),f.sha256,f.path);
for(const p of ['tests/browser/case-set.spec.ts','tests/browser/case-set-observation.ts','tests/fixtures/case-set.ts','tests/playwright.config.ts']) assert(!reg.files.some(f=>f.path===p),p+' is a product source');
assert.equal(caseSetSamples.length,42);assert.equal(caseSetSamples.filter(s=>s.walk).length,7);
const inventory=caseSetIds.map(caseId=>({caseId,count:caseSetSamples.filter(s=>s.caseId===caseId).length,walk:caseSetSamples.filter(s=>s.caseId===caseId&&s.walk).map(s=>s.key)}));
save(root+'/matrix-inventory.json',{fixtureSha256:hash(read('tests/fixtures/case-set.ts')),caseTests:7,inputSamples:42,walkRepresentatives:7,perCase:inventory,samples:caseSetSamples,rejectionDrafts:4,recoveryExecutions:1,directoryLinks:7,specTests:9,rates:[0.25,0.5,1,1.5,2,4],limits:'Original 120000ms per case test,30000ms other tests,retries0,workers1; no execution budget change'});
const beforeDir='项目文档/验收/18-整块质量-修改前';mkdirSync(beforeDir,{recursive:true});
const originals=['tests/browser/case-set.spec.ts','tests/browser/case-set-observation.ts','tests/fixtures/case-set.ts','tests/playwright.config.ts','.artifacts/18.4/browser-formal57.json','.artifacts/18.4/browser-formal57-r2.json'];
for(const round of ['formal57-output','formal57-r2-output']) {
  try {for(const ent of readdirSync('.artifacts/18.4/'+round,{withFileTypes:true}))if(ent.isDirectory()&&ent.name.startsWith('case-set-')) originals.push('.artifacts/18.4/'+round+'/'+ent.name+'/error-context.md');} catch(e){if(e.code!=='ENOENT')throw e;}
}
const entries=originals.map((source,i)=>{const b=read(source),compressed=gzipSync(b),file=String(i+1).padStart(3,'0')+'-'+source.split('/').at(-1)+'.gz';writeFileSync(beforeDir+'/'+file,compressed,{flag:'wx'});assert.equal(hash(gunzipSync(read(beforeDir+'/'+file))),hash(b));return{source,file,bytes:b.length,sha256:hash(b),archiveBytes:compressed.length,archiveSha256:hash(compressed),encoding:'gzip'};});
const failures=originals.filter(p=>p.endsWith('.json')).map(path=>{const r=json(path);const errors=[];function walk(x){if(Array.isArray(x)){for(const v of x)walk(v);}else if(x&&typeof x==='object'){if(x.error)errors.push(x.error.message);for(const [k,v]of Object.entries(x))if(k!=='error')walk(v);}}walk(r.suites);return{path,sha256:hash(read(path)),stats:r.stats,errors};});
save(beforeDir+'/index.json',{task:'18-block-quality-before-change',at:new Date().toISOString(),scope:'Independent byte-frozen copies of original active QA and old failure reports; original locations unchanged.',files:entries,failures});
console.log(JSON.stringify({baseline:proof.length,regSources:reg.files.length,activeQaOutsideProductSources:true,inventory,frozenBefore:entries.length,oldFailedReports:failures.map(f=>({path:f.path,stats:f.stats,firstError:f.errors[0]?.slice(0,350)}))},null,2));
