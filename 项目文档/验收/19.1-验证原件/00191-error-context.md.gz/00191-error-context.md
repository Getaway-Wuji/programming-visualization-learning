# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: weaknesses.spec.ts >> 19.1 corrupt or future summary remains preserved, never looks like no weakness, courses still work
- Location: tests\browser\weaknesses.spec.ts:280:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '课程', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '课程', exact: true }) with timeout 5000ms
  - waiting for getByRole('heading', { name: '课程', exact: true })

```

```yaml
- link "跳到主要内容":
  - /url: "#main-content"
- complementary:
  - button "收起侧栏" [expanded]
  - link "编程可视化教学平台 · 学习首页":
    - /url: "#/"
    - text: "{ } 一步一懂 编程可视化教学平台"
  - paragraph: 从代码，到理解。
  - navigation "主导航":
    - link "学习首页":
      - /url: "#/"
    - link "C 语言课程":
      - /url: "#/courses"
    - link "进阶课程":
      - /url: "#/advanced"
    - link "算法与演示":
      - /url: "#/cases"
    - link "C 代码工作台":
      - /url: "#/custom-code"
    - link "编译流程":
      - /url: "#/compilation"
    - link "错题与陌生点":
      - /url: "#/notebook"
    - link "今日复习":
      - /url: "#/reviews"
    - link "学习成就":
      - /url: "#/achievements"
    - link "本地设置":
      - /url: "#/settings"
  - strong: 按自己的节奏学习
  - paragraph: 学习记录将保存在当前浏览器，不跨设备同步。
  - link "了解本地数据":
    - /url: "#/settings?panel=data"
- banner:
  - text: C 语言 · 从零开始 本地学习
  - link "本地数据":
    - /url: "#/settings?panel=data"
  - button "切换为深色"
- main:
  - navigation "当前位置":
    - list:
      - listitem:
        - link "学习首页":
          - /url: "#/"
      - listitem: C 语言课程
  - paragraph: C 语言入门
  - heading "从基础开始，一步步学懂。" [level=1]
  - paragraph: 按章节学习目标、讲解与示例，主动记录学习，并通过必修练习完成小节。
  - status:
    - heading "本地档案已读取" [level=2]
    - paragraph: 正在显示当前浏览器中已保存的记录与设置。
  - link "继续学习":
    - /url: "#/lessons/lesson.c.first-program"
  - text: 进度仅保存在当前浏览器；本节学习确认与必修题通过分别记录。
  - group: 拆积木练习 · 6 题
  - paragraph:
    - link "Bug 修复闯关":
      - /url: "#/bugs"
    - text: 从语法、逻辑、指针与循环错误稿开始，修复后用真实测试验证。
  - paragraph:
    - link "进入进阶课程：复用基础进度，连接真实C++案例 →":
      - /url: "#/advanced"
    - text: ·
    - link "语言迁移与语法对照":
      - /url: "#/advanced/migration"
  - text: 01 课程阅读
  - heading "程序入门与输出" [level=2]
  - list:
    - listitem:
      - link "1 第一个程序与正常结束 未开始":
        - /url: "#/lessons/lesson.c.first-program"
        - text: "1"
        - strong: 第一个程序与正常结束
        - text: 未开始
    - listitem:
      - link "2 变量和输出 未开始":
        - /url: "#/lessons/lesson.c.variables-output"
        - text: "2"
        - strong: 变量和输出
        - text: 未开始
    - listitem:
      - link "3 整数格式与多值输出 未开始":
        - /url: "#/lessons/lesson.c.printf-layout"
        - text: "3"
        - strong: 整数格式与多值输出
        - text: 未开始
    - listitem:
      - link "4 语句顺序与当前值 未开始":
        - /url: "#/lessons/lesson.c.statement-order"
        - text: "4"
        - strong: 语句顺序与当前值
        - text: 未开始
  - text: 02 课程阅读
  - heading "变量与程序状态" [level=2]
  - list:
    - listitem:
      - link "1 声明、初始化与再次赋值 未开始":
        - /url: "#/lessons/lesson.c.initialization-assignment"
        - text: "1"
        - strong: 声明、初始化与再次赋值
        - text: 未开始
    - listitem:
      - link "2 临时变量与交换 未开始":
        - /url: "#/lessons/lesson.c.temporary-swap"
        - text: "2"
        - strong: 临时变量与交换
        - text: 未开始
    - listitem:
      - link "3 块作用域与同名遮蔽 未开始":
        - /url: "#/lessons/lesson.c.scope-shadowing"
        - text: "3"
        - strong: 块作用域与同名遮蔽
        - text: 未开始
    - listitem:
      - link "4 int32范围与安全计算 未开始":
        - /url: "#/lessons/lesson.c.integer-safety"
        - text: "4"
        - strong: int32范围与安全计算
        - text: 未开始
  - text: 03 课程阅读
  - heading "表达式与逻辑" [level=2]
  - list:
    - listitem:
      - link "1 表达式 未开始":
        - /url: "#/lessons/lesson.c.expressions"
        - text: "1"
        - strong: 表达式
        - text: 未开始
    - listitem:
      - link "2 整数除法与余数 未开始":
        - /url: "#/lessons/lesson.c.quotient-remainder"
        - text: "2"
        - strong: 整数除法与余数
        - text: 未开始
    - listitem:
      - link "3 比较结果与逻辑组合 未开始":
        - /url: "#/lessons/lesson.c.boolean-logic"
        - text: "3"
        - strong: 比较结果与逻辑组合
        - text: 未开始
    - listitem:
      - link "4 短路与安全求值顺序 未开始":
        - /url: "#/lessons/lesson.c.short-circuit-safety"
        - text: "4"
        - strong: 短路与安全求值顺序
        - text: 未开始
  - text: 04 课程阅读
  - heading "条件与分支" [level=2]
  - list:
    - listitem:
      - link "1 单分支if与条件写入 未开始":
        - /url: "#/lessons/lesson.c.single-if"
        - text: "1"
        - strong: 单分支if与条件写入
        - text: 未开始
    - listitem:
      - link "2 条件 未开始":
        - /url: "#/lessons/lesson.c.conditions"
        - text: "2"
        - strong: 条件
        - text: 未开始
    - listitem:
      - link "3 嵌套分支与三路分类 未开始":
        - /url: "#/lessons/lesson.c.nested-conditions"
        - text: "3"
        - strong: 嵌套分支与三路分类
        - text: 未开始
    - listitem:
      - link "4 闭区间与组合条件 未开始":
        - /url: "#/lessons/lesson.c.interval-boundaries"
        - text: "4"
        - strong: 闭区间与组合条件
        - text: 未开始
  - text: 05 课程阅读
  - heading "循环与重复" [level=2]
  - list:
    - listitem:
      - link "1 while倒计时与零轮循环 未开始":
        - /url: "#/lessons/lesson.c.while-countdown"
        - text: "1"
        - strong: while倒计时与零轮循环
        - text: 未开始
    - listitem:
      - link "2 while 与 for 未开始":
        - /url: "#/lessons/lesson.c.loops"
        - text: "2"
        - strong: while 与 for
        - text: 未开始
    - listitem:
      - link "3 break、continue与有效累加 未开始":
        - /url: "#/lessons/lesson.c.loop-control"
        - text: "3"
        - strong: break、continue与有效累加
        - text: 未开始
    - listitem:
      - link "4 嵌套循环逐格计数 未开始":
        - /url: "#/lessons/lesson.c.nested-loops"
        - text: "4"
        - strong: 嵌套循环逐格计数
        - text: 未开始
  - text: 06 课程阅读
  - heading "一维数组基础" [level=2]
  - list:
    - listitem:
      - link "1 数组容量、初值与补零 未开始":
        - /url: "#/lessons/lesson.c.array-initialization"
        - text: "1"
        - strong: 数组容量、初值与补零
        - text: 未开始
    - listitem:
      - link "2 一维数组 未开始":
        - /url: "#/lessons/lesson.c.array-update"
        - text: "2"
        - strong: 一维数组
        - text: 未开始
    - listitem:
      - link "3 遍历逻辑数组并输出 未开始":
        - /url: "#/lessons/lesson.c.array-traversal-output"
        - text: "3"
        - strong: 遍历逻辑数组并输出
        - text: 未开始
    - listitem:
      - link "4 逻辑长度与安全下标 未开始":
        - /url: "#/lessons/lesson.c.logical-length-guards"
        - text: "4"
        - strong: 逻辑长度与安全下标
        - text: 未开始
  - text: 07 课程阅读
  - heading "数组问题求解" [level=2]
  - list:
    - listitem:
      - link "1 综合练习 未开始":
        - /url: "#/lessons/lesson.c.array-sum"
        - text: "1"
        - strong: 综合练习
        - text: 未开始
    - listitem:
      - link "2 扫描数组求最小与最大 未开始":
        - /url: "#/lessons/lesson.c.array-extrema"
        - text: "2"
        - strong: 扫描数组求最小与最大
        - text: 未开始
    - listitem:
      - link "3 条件计数与严格正数 未开始":
        - /url: "#/lessons/lesson.c.array-counting"
        - text: "3"
        - strong: 条件计数与严格正数
        - text: 未开始
    - listitem:
      - link "4 顺序查找第一次匹配 未开始":
        - /url: "#/lessons/lesson.c.linear-search-first"
        - text: "4"
        - strong: 顺序查找第一次匹配
        - text: 未开始
  - text: 08 课程阅读
  - heading "排序与搜索入门" [level=2]
  - list:
    - listitem:
      - link "1 相邻比较与非递减 未开始":
        - /url: "#/lessons/lesson.c.adjacent-order"
        - text: "1"
        - strong: 相邻比较与非递减
        - text: 未开始
    - listitem:
      - link "2 冒泡排序与逐轮缩尾 未开始":
        - /url: "#/lessons/lesson.c.bubble-sort"
        - text: "2"
        - strong: 冒泡排序与逐轮缩尾
        - text: 未开始
    - listitem:
      - link "3 选择排序与最小下标 未开始":
        - /url: "#/lessons/lesson.c.selection-sort"
        - text: "3"
        - strong: 选择排序与最小下标
        - text: 未开始
    - listitem:
      - link "4 二分查找首次匹配 未开始":
        - /url: "#/lessons/lesson.c.binary-search-first"
        - text: "4"
        - strong: 二分查找首次匹配
        - text: 未开始
```

# Test source

```ts
  206 |   await expect(variable(page)).toContainText('现有证据已修复');
  207 |   const repaired = await archive(page);
  208 |   await fail(page);
  209 |   await open(page);
  210 |   await expect(variable(page)).toContainText('近30天未修复失败 1 次');
  211 |   expect((await archive(page)).ledger).toEqual(repaired.ledger);
  212 |   await capture(page, 'reopened', true);
  213 | });
  214 | test('19.1 manual evidence stays distinct, cancellation and peer synchronization preserve true facts', async ({
  215 |   page,
  216 |   context,
  217 | }) => {
  218 |   await mark(page);
  219 |   await open(page);
  220 |   await expect(variable(page)).toContainText('手动自评');
  221 |   const before = await archive(page);
  222 |   const peer = await context.newPage();
  223 |   await open(peer);
  224 |   await expect(variable(peer)).toContainText('手动自评');
  225 |   expect((await archive(peer)).receipts).toEqual(before.receipts);
  226 |   expect((await archive(peer)).ledger).toEqual(before.ledger);
  227 |   await mark(page);
  228 |   await open(peer);
  229 |   await expect(variable(peer)).toHaveCount(0);
  230 |   await peer.getByRole('checkbox', { name: '显示已修复与历史', exact: true }).check();
  231 |   await expect(variable(peer)).toContainText('已修复、已取消或超出');
  232 |   await capture(peer, 'manual-cancel');
  233 | });
  234 | test('19.1 native quota rolls back summary, explicit retry and peer clear cannot resurrect old evidence', async ({
  235 |   page,
  236 |   context,
  237 | }) => {
  238 |   await page.addInitScript(() => {
  239 |     const control = { armed: false };
  240 |     Object.assign(window, { __weakQuota: control });
  241 |     const put = IDBObjectStore.prototype.put;
  242 |     IDBObjectStore.prototype.put = function (value, key) {
  243 |       if (this.name === 'weaknesses' && control.armed)
  244 |         throw new DOMException('19.1 controlled quota', 'QuotaExceededError');
  245 |       return key === undefined ? put.call(this, value) : put.call(this, value, key);
  246 |     };
  247 |   });
  248 |   await mark(page);
  249 |   const before = await archive(page);
  250 |   await page.evaluate(() => {
  251 |     (window as unknown as { __weakQuota: { armed: boolean } }).__weakQuota.armed = true;
  252 |   });
  253 |   await page.goto('/#/weaknesses');
  254 |   await expect(status(page)).toHaveAttribute('data-state', 'failed');
  255 |   await expect(status(page)).toContainText('S_QUOTA');
  256 |   expect(await archive(page)).toEqual(before);
  257 |   await page.evaluate(() => {
  258 |     (window as unknown as { __weakQuota: { armed: boolean } }).__weakQuota.armed = false;
  259 |   });
  260 |   await page.getByRole('button', { name: '重新归纳本地证据', exact: true }).click();
  261 |   await expect(status(page)).toHaveAttribute('data-state', 'ready');
  262 |   await expect(variable(page)).toContainText('手动自评');
  263 |   const peer = await context.newPage();
  264 |   await peer.goto('/#/settings?panel=data');
  265 |   await ready(peer);
  266 |   await peer.getByRole('button', { name: '清除本地数据', exact: true }).click();
  267 |   await peer
  268 |     .getByRole('dialog', { name: '确认清除本地数据', exact: true })
  269 |     .getByRole('button', { name: '确认清除', exact: true })
  270 |     .click();
  271 |   await expect(variable(page)).toHaveCount(0);
  272 |   await page.reload();
  273 |   await open(page);
  274 |   expect((await archive(page)).receipts).toEqual([]);
  275 |   expect(
  276 |     ((await archive(page)) as unknown as { knowledgeMarks: unknown[] }).knowledgeMarks,
  277 |   ).toEqual([]);
  278 |   await capture(page, 'cleared');
  279 | });
  280 | test('19.1 corrupt or future summary remains preserved, never looks like no weakness, courses still work', async ({
  281 |   page,
  282 | }) => {
  283 |   await mark(page);
  284 |   await open(page);
  285 |   await page.evaluate(async () => {
  286 |     const db = await new Promise<IDBDatabase>((resolve) => {
  287 |       const r = indexedDB.open('c-viz-learning');
  288 |       r.onsuccess = () => resolve(r.result);
  289 |     });
  290 |     const tx = db.transaction('weaknesses', 'readwrite');
  291 |     const r = tx.objectStore('weaknesses').get('current');
  292 |     r.onsuccess = () =>
  293 |       tx.objectStore('weaknesses').put({ ...r.result, weaknessVersion: '99.0.0' }, 'current');
  294 |     await new Promise<void>((resolve) => {
  295 |       tx.oncomplete = () => resolve();
  296 |     });
  297 |     db.close();
  298 |   });
  299 |   const before = await archive(page);
  300 |   await page.reload();
  301 |   await expect(status(page)).toHaveAttribute('data-state', 'failed');
  302 |   await expect(status(page)).toContainText('S_VERSION_UNKNOWN');
  303 |   await expect(page.getByTestId('weakness-empty')).toHaveCount(0);
  304 |   expect(await archive(page)).toEqual(before);
  305 |   await page.getByRole('link', { name: '继续原课程 →', exact: true }).click();
> 306 |   await expect(page.getByRole('heading', { name: '课程', exact: true })).toBeVisible();
      |                                                                        ^ Error: expect(locator).toBeVisible() failed
  307 | });
  308 | test('19.1 passive real playback, C workbench diagnostics and read-only advanced examples do not invent weaknesses', async ({
  309 |   page,
  310 | }) => {
  311 |   await page.goto('/#/visualize/case.c.assignment');
  312 |   await ready(page);
  313 |   await page.getByRole('button', { name: '运行示例', exact: true }).click();
  314 |   await expect(page.getByTestId('case-execution')).toHaveAttribute('data-state', 'completed');
  315 |   const before = await archive(page);
  316 |   await page
  317 |     .getByTestId('player-controls')
  318 |     .getByRole('button', { name: '前进', exact: true })
  319 |     .click();
  320 |   await page
  321 |     .getByTestId('player-controls')
  322 |     .getByRole('button', { name: '后退', exact: true })
  323 |     .click();
  324 |   expect((await archive(page)).receipts).toEqual(before.receipts);
  325 |   await page.goto('/#/custom-code');
  326 |   await page.getByRole('button', { name: '编辑代码', exact: true }).click();
  327 |   await page
  328 |     .getByRole('textbox', { name: 'C 代码', exact: true })
  329 |     .fill('int main(){int x;return x;}');
  330 |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  331 |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute(
  332 |     'data-status',
  333 |     /ready|rejected/,
  334 |   );
  335 |   expect((await archive(page)).receipts).toEqual(before.receipts);
  336 |   await open(page);
  337 |   await expect(page.getByTestId('weakness-empty')).toBeVisible();
  338 |   await capture(page, 'no-inference');
  339 | });
  340 | test('19.1 two distinct real challenge mistakes qualify, replay stays one per question, later correct resolves', async ({
  341 |   page,
  342 | }) => {
  343 |   test.setTimeout(90000);
  344 |   await observeCaseSetExecution(page);
  345 |   const answer = async (id: string, correct = false) => {
  346 |     await page.goto(`/#/visualize/${id}`);
  347 |     await page.reload();
  348 |     await ready(page);
  349 |     await page.getByRole('button', { name: '运行示例', exact: true }).click();
  350 |     await expect(page.getByTestId('case-execution')).toHaveAttribute('data-state', 'completed');
  351 |     await page.getByRole('button', { name: '预测挑战', exact: true }).click();
  352 |     await page
  353 |       .getByRole('group', { name: '本次挑战题目', exact: true })
  354 |       .getByRole('button')
  355 |       .nth(0)
  356 |       .click();
  357 |     await page
  358 |       .locator(`[data-answer-kind="${correct ? 'value.initialize' : 'object.declare'}"]`)
  359 |       .click();
  360 |     await expect(page.getByTestId('challenge-feedback')).toContainText('本次答案已保存');
  361 |   };
  362 |   await answer('case.c.assignment');
  363 |   await answer('case.c.assignment');
  364 |   await open(page);
  365 |   await expect(variable(page)).toContainText('有1道挑战题');
  366 |   const reward = await archive(page);
  367 |   await answer('case.c.branch');
  368 |   await open(page);
  369 |   await expect(variable(page)).toContainText('达到卡壳规则');
  370 |   await capture(page, 'challenge-stall', true);
  371 |   await answer('case.c.assignment', true);
  372 |   await open(page);
  373 |   await expect(variable(page)).not.toContainText('达到卡壳规则');
  374 |   await expect(variable(page)).toContainText('有1道挑战题');
  375 |   const after = await archive(page);
  376 |   expect(after.ledger.filter((l) => l.subjectId === 'challenge.c.assignment.initialize')).toEqual(
  377 |     reward.ledger.filter((l) => l.subjectId === 'challenge.c.assignment.initialize'),
  378 |   );
  379 |   await capture(page, 'challenge-repaired', true);
  380 | });
  381 | 
```