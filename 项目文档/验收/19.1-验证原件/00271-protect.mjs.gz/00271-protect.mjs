import {readFileSync,existsSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const paths=[...Array.from({length:6},(_,i)=>`项目文档/验收/18.${i+1}-验证原件/index.json`),'项目文档/验收/18-整块质量-修改前/index.json','项目文档/验收/18-整块质量原件/index.json'];
const report={archives:0,archiveMismatch:[],sourceChecked:0,sourceMismatch:[],sourceAbsent:[]};
for(const p of paths){const index=JSON.parse(readFileSync(p,'utf8')),dir=p.slice(0,p.lastIndexOf('/'));for(const e of index.files){const b=readFileSync(dir+'/'+e.file);report.archives++;const body=e.encoding==='gzip'?gunzipSync(b):b;if(sha(b)!==e.archiveSha256||sha(body)!==e.sha256) report.archiveMismatch.push(e.source);if(e.source.startsWith('.artifacts/')){if(existsSync(e.source)){report.sourceChecked++;if(sha(readFileSync(e.source))!==e.sha256)report.sourceMismatch.push(e.source);}else report.sourceAbsent.push(e.source);}}}
writeFileSync('.artifacts/19.1/inherited-protection.json',JSON.stringify(report,null,2)+'\n');console.log(report);
