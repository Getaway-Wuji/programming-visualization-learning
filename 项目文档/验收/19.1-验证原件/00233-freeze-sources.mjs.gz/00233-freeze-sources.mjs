import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {format} from 'prettier';
const sha=b=>createHash('sha256').update(b).digest('hex');
const output=[];
for(const version of [60,61,62]) {
 const release=JSON.parse(readFileSync(`content/c/p0/blockly-release-1.0.${version}.json`,'utf8'));
 const dir=`.artifacts/19.1/sources-${version}`;mkdirSync(dir,{recursive:true});const files=[];
 for(const [i,e] of release.files.entries()) {
  let bytes=readFileSync(e.path);
  if(sha(bytes)!==e.sha256) {
   let s=bytes.toString();
   if(e.path==='web/src/weaknesses/model.ts' && version<62) s=s.replace('knowledgeRef: { id: knowledgeRef.id, version: knowledgeRef.version }','knowledgeRef: { ...knowledgeRef }').replace('lessonRef: { id: lessonRef.id, version: lessonRef.version }','lessonRef: { ...lessonRef }');
   if(e.path==='scripts/build-p05-course.mjs') {
    for(let newer=62;newer>version;newer--) {
     s=s.replace(new RegExp(`const releaseVersion = existsSync\\('content/c/p0/blockly-release-1\\.0\\.${newer}\\.json'\\)\\s*\\? '1\\.0\\.${newer}'\\s*:\\s*`),'const releaseVersion = ');
     s=s.replaceAll(`, '1.0.${newer}'`,'').replace(new RegExp(`^\\s*'1\\.0\\.${newer}',\\r?\\n`,'gm'),'');
    }
    if(version===60)s=s.replace("['1.0.60'].includes(releaseVersion)","releaseVersion === '1.0.60'");
   }
   if(e.path==='scripts/restore-release-evidence.mjs') {
    for(let newer=62;newer>version;newer--)s=s.replaceAll(`, '1.0.${newer}'`,'').replace(new RegExp(`^\\s*'1\\.0\\.${newer}',\\r?\\n`,'gm'),'');
    if(version===60){s=s.replace("['1.0.60'].includes(release)","release === '1.0.60'");const marker=s.indexOf('const compressedJson');s=s.slice(0,marker)+s.slice(marker).replace(/^\s*'1\.0\.60',\r?\n/m,'');}
   }
   if(e.path.endsWith('.ts')||e.path.endsWith('.mjs'))s=await format(s,{...JSON.parse(readFileSync('.prettierrc.json','utf8')),parser:e.path.endsWith('.ts')?'typescript':'babel'});
   bytes=Buffer.from(s);
  }
  if(sha(bytes)!==e.sha256)throw new Error(`Historical source mismatch ${version}/${e.path}`);
  const file=String(i+1).padStart(4,'0')+'.gz',b=gzipSync(bytes);writeFileSync(dir+'/'+file,b,{flag:'wx'});files.push({source:e.path,file,bytes:bytes.length,sha256:e.sha256,archiveSha256:sha(b),encoding:'gzip'});
 }
 writeFileSync(dir+'/index.json',JSON.stringify({release:release.releaseVersion,files},null,2)+'\n',{flag:'wx'});output.push({version,files:files.length});
}
console.log(output);
