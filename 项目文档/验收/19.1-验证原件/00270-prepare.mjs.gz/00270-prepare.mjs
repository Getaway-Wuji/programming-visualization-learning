import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
const edit=(p,f)=>writeFileSync(p,f(readFileSync(p,'utf8')));
// Freeze activity before adapting current version assertions; frozen historical evidence is untouched.
mkdirSync('.artifacts/19.1/before',{recursive:true});
for(const p of ['tests/browser/case-set.spec.ts','tests/unit/storage.test.ts','tests/unit/storage-recovery.test.ts','tests/unit/notebook.test.ts','tests/unit/review-scheduler.test.ts','tests/unit/custom-code.test.ts']) {try {copyFileSync(p,'.artifacts/19.1/before/'+p.replaceAll('/','__'));}catch(e){if(e.code!=='ENOENT')throw e;}}
edit('web/src/storage/client.ts',s=>s.replaceAll("db.createObjectStore('customDrafts');","db.createObjectStore('customDrafts');\n            db.createObjectStore('weaknesses');").replace("          if (event.oldVersion !== 0)",`          if (event.oldVersion === 8) {
            const db=request.result, tx=request.transaction!;
            if(db.objectStoreNames.length!==V8_STORE_NAMES.length || V8_STORE_NAMES.some(name=>!db.objectStoreNames.contains(name))) throw new StorageError('S_MIGRATION_UNSUPPORTED');
            for(const name of V8_STORE_NAMES) {const store=tx.objectStore(name);if(store.keyPath!==null || store.autoIncrement || store.indexNames.length) throw new StorageError('S_MIGRATION_UNSUPPORTED');}
            const values=tx.objectStore('meta').getAll(), keys=tx.objectStore('meta').getAllKeys();
            values.onsuccess=()=>{try{for(const value of values.result) upgradeV8Meta(value);}catch(error){failure=error;tx.abort();}};
            keys.onsuccess=()=>{try{const next=values.result.length===1 && keys.result[0]==='current'?upgradeV8Meta(values.result[0]):null;if(next)tx.objectStore('meta').put(next,'current');}catch(error){failure=error;tx.abort();}};
            db.createObjectStore('weaknesses');return;
          }
          if (event.oldVersion !== 0)`));
