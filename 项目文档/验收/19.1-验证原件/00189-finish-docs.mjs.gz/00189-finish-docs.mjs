import {readFileSync,writeFileSync} from 'node:fs';
const paragraph='19.1实际验收（2026-11-01）：本地薄弱点与可核对依据已交付，真实失败/修复再错、手动自评和不同挑战题卡壳独立归纳，不把暂停/回退/C工作台诊断或只读示例当知识缺陷。正式63/402源，SAVE9/DB9/17store、旧档与原奖励保持；2069全量单worker前端、119唯一正式Chrome跨轮、类型/lint/格式/完整构建/自有启动通过，正式三宽Inspector0FAIL/0WARN。原80/88余8、主80/98、P2 11/19、第19为1/5、P0.5 9/9、21为0/10；算法22/22与26案例7C/19CPP不增。旧2673归档/2669原路径及16外窗CI/临时样式元数据保持，四WASM/预算不变。19.2交回协调另派，本轮无暂存/提交/推送，不实施后继。';
for(const p of ['README.md','项目守则.md','项目文档/开发路线与依赖.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md']){
 const root=p.startsWith('项目文档/')?'./':'项目文档/';
 let s=readFileSync(p,'utf8');const i=s.indexOf('\n');
 s=s.slice(0,i+1)+'\n'+paragraph+` 见[验收](${root}验收/19.1-薄弱点事件与本地归纳验收.md)、[独立交接](${root}交接/19.1-交接.md)、[最终复核](${root}验收/19.1-最终复核.json)。下方旧时点保留历史含义。\n`+s.slice(i+1);
 if(p.endsWith('任务进度与交接.md')) {
  s=s.split('\n').map(line=>line.startsWith('| 19.1 |')?'| 19.1 | P2 | [薄弱点事件与本地归纳](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 已验收 | root / 完成19任务 | 63/402源、SAVE9/DB9/17store；2069前端、119唯一正式Chrome跨轮与类型/lint/格式/构建通过；真实来源/修复再错/挑战/自评、迁移/配额/并发/晚到清除齐备。[验收](./验收/19.1-薄弱点事件与本地归纳验收.md) / [交接](./交接/19.1-交接.md)。第19为1/5，19.2未领取，不Git。 |':line.startsWith('阶段统计（18.6及第18整块质量复核后）')?'阶段统计（19.1实际验收后）：原P0 41项、P1 28项、P2 11项已验收，原80/88、余8，主路线80/98；P0.5独立9/9，21新增0/10。第17/18已交付，第19为1/5；19.1交回协调，19.2未领取。P2总门槛20.4未完成，本轮无Git写入。':line).join('\n');
 }
 writeFileSync(p,s);
}
const path='项目文档/契约/19.1-兼容变更登记.json';const card=JSON.parse(readFileSync(path,'utf8'));card.status='accepted';card.approvals=card.requiredOwnerRoles.map(role=>({role,owner:'root',decision:'accepted',evidence:'../验收/19.1-薄弱点事件与本地归纳验收.md'}));card.actualEvidence.push('../验收/19.1-最终复核.json','../验收/发布凭据/19.1-1.0.63/index.json');writeFileSync(path,JSON.stringify(card,null,2)+'\n');
