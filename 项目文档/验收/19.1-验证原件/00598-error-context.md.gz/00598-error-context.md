# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scheduler.spec.ts >> 15.3 formal corrupt knowledgeMarks preserves raw rows and shows unknown rather than an empty queue
- Location: tests\browser\scheduler.spec.ts:269:3

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('.app-shell')
Expected: "ready"
Received: "failed"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('.app-shell') with timeout 5000ms
  - waiting for locator('.app-shell')
    14 × locator resolved to <div data-nav-open="false" data-sidebar="expanded" class="app-shell p05-app" data-workbench-mode="standard" data-learning-goal-status="ready" data-review-storage-status="failed" data-learning-reward-status="ready" data-learning-storage-status="ready" data-learning-reading-status="ready" data-learning-profile-status="ready" data-learning-practice-status="ready" data-achievement-storage-status="ready">…</div>
       - unexpected value "failed"

```

```yaml
- link "跳到主要内容":
  - /url: "#main-content"
- complementary:
  - button "收起侧栏" [expanded]
  - link "编程可视化教学平台 · 学习首页":
    - /url: "#/"
    - text: "{ } 一步一懂 编程可视化教学平台"
  - paragraph: 从代码，到理解。
  - navigation "主导航"
  - strong: 按自己的节奏学习
  - paragraph: 学习记录将保存在当前浏览器，不跨设备同步。
  - link "了解本地数据":
    - /url: "#/settings?panel=data"
- banner:
  - text: C 语言 · 从零开始 本地学习
  - link "本地数据":
    - /url: "#/settings?panel=data"
  - button "切换为深色"
- main:
  - paragraph: 本地复习
  - heading "今日复习" [level=1]
  - paragraph: 回顾真实错题和自己标记的陌生点，再用自评安排下一次复习。
  - status
  - paragraph: 日期待确认 · 自评不代表练习通过，不增加积分或课程完成。
  - paragraph: 复习队列暂不能确认，请先恢复本地档案或重新读取。
  - group: 复习日期怎样安排
```

# Test source

```ts
  1   | import { mkdir, writeFile } from 'node:fs/promises';
  2   | import { gzipSync } from 'node:zlib';
  3   | import { expect, type Page } from '@playwright/test';
  4   | import {
  5   |   archive,
  6   |   ready,
  7   |   openAnswer,
  8   |   submit,
  9   |   confirm,
  10  |   code,
  11  |   panel,
  12  |   observeCaseSetExecution,
  13  | } from './notebook-helpers';
  14  | import { observedCaseSetExecute } from './case-set-observation';
  15  | import type { ReviewCard } from '../../web/src/review-scheduler/model';
  16  | import type { KnowledgeMark } from '../../web/src/storage/knowledge-marks';
  17  | export { ready, openAnswer, submit, confirm, code, panel, observeCaseSetExecution };
  18  | export const folder = `.artifacts/15.3/browser/${process.env.TASK_EVIDENCE_LABEL ?? 'local'}`;
  19  | export const status = (p: Page) => p.getByTestId('review-save-status');
  20  | export async function native(p: Page) {
  21  |   return (await archive(p)) as Awaited<ReturnType<typeof archive>> & {
  22  |     reviewCards: ReviewCard[];
  23  |     knowledgeMarks: KnowledgeMark[];
  24  |   };
  25  | }
  26  | export async function reviewReady(p: Page) {
  27  |   await expect(p.locator('.app-shell')).toHaveAttribute('data-learning-storage-status', 'ready');
> 28  |   await expect(p.locator('.app-shell')).toHaveAttribute('data-review-storage-status', 'ready');
      |                                         ^ Error: expect(locator).toHaveAttribute(expected) failed
  29  |   await expect.poll(async () => (await native(p)).settings.goalTemplate).not.toBeNull();
  30  | }
  31  | export async function reviews(p: Page) {
  32  |   await p.goto('/#/reviews');
  33  |   await expect(p.getByRole('heading', { level: 1, name: '今日复习', exact: true })).toBeVisible();
  34  |   await reviewReady(p);
  35  | }
  36  | export async function mark(p: Page) {
  37  |   await p.goto('/#/lessons/lesson.c.variables-output');
  38  |   await ready(p);
  39  |   await expect(p.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  40  |   await reviewReady(p);
  41  |   await p.locator('[data-knowledge-mark="knowledge.c.variables"]').click();
  42  |   await expect(p.locator('[data-knowledge-mark="knowledge.c.variables"]')).toHaveAttribute(
  43  |     'aria-pressed',
  44  |     'true',
  45  |   );
  46  |   await reviews(p);
  47  |   await expect.poll(async () => (await native(p)).reviewCards.length).toBe(1);
  48  | }
  49  | export async function changePrint(p: Page, expression: string) {
  50  |   const source = await code(p).inputValue();
  51  |   await code(p).fill(source.replace(/printf\([^;]+;/, `printf("%d\\n", ${expression});`));
  52  |   await expect(p.getByTestId('draft-code-editor')).toHaveAttribute('data-sync', 'synced');
  53  | }
  54  | export async function fail(p: Page) {
  55  |   await panel(p).getByRole('button', { name: '提交练习', exact: true }).click();
  56  |   await expect(panel(p)).toHaveAttribute('data-state', 'unmet');
  57  |   await expect(p.getByTestId('practice-attempt-save')).toHaveAttribute('data-save-state', 'saved');
  58  |   await reviewReady(p);
  59  | }
  60  | export async function capture(p: Page, name: string) {
  61  |   const actual = await observedCaseSetExecute(p);
  62  |   expect(actual.moduleSeen).toBe(true);
  63  |   expect(actual.responseOk).toBe(true);
  64  |   await mkdir(folder, { recursive: true });
  65  |   await writeFile(`${folder}/${name}.json.gz`, gzipSync(JSON.stringify(actual)), { flag: 'wx' });
  66  | }
  67  | export function sameLearning(
  68  |   before: Awaited<ReturnType<typeof native>>,
  69  |   after: Awaited<ReturnType<typeof native>>,
  70  | ) {
  71  |   for (const key of [
  72  |     'progress',
  73  |     'receipts',
  74  |     'dailyFacts',
  75  |     'ledger',
  76  |     'goals',
  77  |     'aliases',
  78  |     'settings',
  79  |     'avatar',
  80  |     'appearance',
  81  |     'appearanceAssets',
  82  |   ] as const)
  83  |     expect(after[key]).toEqual(before[key]);
  84  | }
  85  | export async function quota(p: Page) {
  86  |   await p.addInitScript(() => {
  87  |     const c = { armed: false, ids: [] as string[] };
  88  |     Object.assign(window, { __reviewQuota: c });
  89  |     const put = IDBObjectStore.prototype.put;
  90  |     IDBObjectStore.prototype.put = function (value, key) {
  91  |       if (
  92  |         this.name === 'reviewCards' &&
  93  |         (value as { lastCommand?: { mode: string; commandId: string } }).lastCommand?.mode ===
  94  |           'rate'
  95  |       ) {
  96  |         c.ids.push((value as { lastCommand: { commandId: string } }).lastCommand.commandId);
  97  |         if (c.armed) {
  98  |           c.armed = false;
  99  |           throw new DOMException('15.3 native review quota', 'QuotaExceededError');
  100 |         }
  101 |       }
  102 |       return key === undefined ? put.call(this, value) : put.call(this, value, key);
  103 |     };
  104 |   });
  105 | }
  106 | export async function arm(p: Page) {
  107 |   await p.evaluate(() => {
  108 |     (window as unknown as { __reviewQuota: { armed: boolean } }).__reviewQuota.armed = true;
  109 |   });
  110 | }
  111 | export async function clear(p: Page) {
  112 |   await p.goto('/#/settings?panel=data');
  113 |   // Full clear is also valid for an unsaved/partially unavailable archive.
  114 |   await expect(p.getByRole('button', { name: '清除本地数据', exact: true })).toBeEnabled();
  115 |   await p.getByRole('button', { name: '清除本地数据', exact: true }).click();
  116 |   await p
  117 |     .getByRole('dialog', { name: '确认清除本地数据', exact: true })
  118 |     .getByRole('button', { name: '确认清除', exact: true })
  119 |     .click();
  120 | }
  121 | 
```