import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const sha=b=>createHash('sha256').update(b).digest('hex');
const release=JSON.parse(readFileSync('content/c/p0/blockly-release-1.0.63.json','utf8'));
const dir='.artifacts/19.1/sources-63';mkdirSync(dir,{recursive:true});const files=[];
for(const [i,e]of release.files.entries()){const bytes=readFileSync(e.path);if(sha(bytes)!==e.sha256)throw new Error(e.path);const file=String(i+1).padStart(4,'0')+'.gz',b=gzipSync(bytes);writeFileSync(dir+'/'+file,b,{flag:'wx'});files.push({source:e.path,file,bytes:bytes.length,sha256:e.sha256,archiveSha256:sha(b),encoding:'gzip'});}
writeFileSync(dir+'/index.json',JSON.stringify({release:release.releaseVersion,files},null,2)+'\n',{flag:'wx'});
const old=JSON.parse(readFileSync('content/c/p0/blockly-release-1.0.62.json','utf8'));
const delta=release.files.filter((e,i)=>e.sha256!==old.files[i].sha256).map(e=>e.path);
const expected=['scripts/build-p05-course.mjs','scripts/restore-release-evidence.mjs','项目文档/契约/19.1-薄弱证据与SAVE9.md','项目文档/契约/19.1-存档结构9.0.0.schema.json'];
if(JSON.stringify(delta.toSorted())!==JSON.stringify(expected.toSorted()))throw new Error('Unexpected63 delta');
writeFileSync('.artifacts/19.1/source63-delta.json',JSON.stringify({previous:old.releaseVersion,current:release.releaseVersion,delta,allRuntimeWebAndEngineSourcesByteIdentical:true,note:'63 corrects schema title from historical15 to actual17 and explains timestamp display order; no runtime or learning semantic changes.62 browser behavior remains evidence for byte-identical runtime sources.'},null,2)+'\n',{flag:'wx'});
const packet=JSON.parse(gunzipSync(readFileSync('.artifacts/19.1/browser/formal62-r1/two-real-failures.json.gz')).toString());
const names=['meta','settings','avatar','progress','dailyFacts','goals','ledger','receipts','aliases','appearance','appearanceAssets'];
writeFileSync('.artifacts/19.1/schema-current-native.json',JSON.stringify(Object.fromEntries(names.map(n=>[n,packet.rows[n]])),null,2)+'\n',{flag:'wx'});
console.log({sources:files.length,delta,nativeSchemaProjection:names.length});
