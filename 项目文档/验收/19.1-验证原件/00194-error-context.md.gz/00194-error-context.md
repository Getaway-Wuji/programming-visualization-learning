# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: weaknesses.spec.ts >> 19.1 two distinct real challenge mistakes qualify, replay stays one per question, later correct resolves
- Location: tests\browser\weaknesses.spec.ts:340:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByTestId('weakness-status')
Expected: "ready"
Received: "failed"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" getByTestId('weakness-status') with timeout 5000ms
  - waiting for getByTestId('weakness-status')
    14 × locator resolved to <div role="status" data-state="failed" data-testid="weakness-status">…</div>
       - unexpected value "failed"

```

```yaml
- status:
  - paragraph: 薄弱点尚不能确认（S_RECORD_INVALID）。原记录保留，可继续课程或复习。
  - button "重新归纳本地证据"
```

# Test source

```ts
  22  | }) => {
  23  |   await mark(page);
  24  |   const name = 'c-viz-learning.test.weakness-migration8';
  25  |   const original = await page.evaluate(async (name) => {
  26  |     const db = await new Promise<IDBDatabase>((resolve) => {
  27  |       const r = indexedDB.open('c-viz-learning');
  28  |       r.onsuccess = () => resolve(r.result);
  29  |     });
  30  |     const names = Array.from(db.objectStoreNames).filter((n) => n !== 'weaknesses');
  31  |     const tx = db.transaction(names, 'readonly'),
  32  |       all: Record<string, { keys: IDBValidKey[]; values: unknown[] }> = {};
  33  |     for (const n of names) {
  34  |       const store = tx.objectStore(n);
  35  |       all[n] = { keys: [], values: [] };
  36  |       const keys = store.getAllKeys(),
  37  |         values = store.getAll();
  38  |       keys.onsuccess = () => {
  39  |         all[n].keys = keys.result;
  40  |       };
  41  |       values.onsuccess = () => {
  42  |         all[n].values = values.result;
  43  |       };
  44  |     }
  45  |     await new Promise<void>((resolve) => {
  46  |       tx.oncomplete = () => resolve();
  47  |     });
  48  |     db.close();
  49  |     const meta = all.meta.values[0] as Record<string, unknown>;
  50  |     meta.schemaVersion = '8.0.0';
  51  |     meta.dbVersion = 8;
  52  |     await new Promise<void>((resolve, reject) => {
  53  |       const r = indexedDB.open(name, 8);
  54  |       r.onupgradeneeded = () => {
  55  |         for (const n of names) {
  56  |           const store = r.result.createObjectStore(n);
  57  |           all[n].values.forEach((v, i) => store.put(v, all[n].keys[i]));
  58  |         }
  59  |       };
  60  |       r.onsuccess = () => {
  61  |         r.result.close();
  62  |         resolve();
  63  |       };
  64  |       r.onerror = () => reject(r.error);
  65  |     });
  66  |     return all;
  67  |   }, name);
  68  |   await page.goto('/checks/');
  69  |   await page.waitForFunction(() => Boolean(window.historyHarness));
  70  |   await page.evaluate((name) => window.historyHarness.open(name), name);
  71  |   const after = await page.evaluate(async (name) => {
  72  |     const db = await new Promise<IDBDatabase>((resolve) => {
  73  |       const r = indexedDB.open(name);
  74  |       r.onsuccess = () => resolve(r.result);
  75  |     });
  76  |     const names = Array.from(db.objectStoreNames),
  77  |       tx = db.transaction(names, 'readonly'),
  78  |       all: Record<string, { keys: IDBValidKey[]; values: unknown[] }> = {};
  79  |     for (const n of names) {
  80  |       const store = tx.objectStore(n);
  81  |       all[n] = { keys: [], values: [] };
  82  |       const k = store.getAllKeys(),
  83  |         v = store.getAll();
  84  |       k.onsuccess = () => {
  85  |         all[n].keys = k.result;
  86  |       };
  87  |       v.onsuccess = () => {
  88  |         all[n].values = v.result;
  89  |       };
  90  |     }
  91  |     await new Promise<void>((resolve) => {
  92  |       tx.oncomplete = () => resolve();
  93  |     });
  94  |     const version = db.version;
  95  |     db.close();
  96  |     return { version, all };
  97  |   }, name);
  98  |   expect(after.version).toBe(9);
  99  |   expect(Object.keys(after.all)).toHaveLength(17);
  100 |   expect(after.all.weaknesses).toEqual({ keys: [], values: [] });
  101 |   for (const n of Object.keys(original))
  102 |     if (n !== 'meta') expect(after.all[n], n).toEqual(original[n]);
  103 |   expect(after.all.meta).toEqual({
  104 |     keys: original.meta.keys,
  105 |     values: [
  106 |       {
  107 |         ...(original.meta.values[0] as object),
  108 |         schemaVersion: '9.0.0',
  109 |         dbVersion: 9,
  110 |         revision: (original.meta.values[0] as { revision: number }).revision + 1,
  111 |       },
  112 |     ],
  113 |   });
  114 |   await writeFile(`${folder}/db8-upgrade.json`, JSON.stringify({ original, after }, null, 2), {
  115 |     flag: 'wx',
  116 |   });
  117 | });
  118 | async function open(p: Page) {
  119 |   await p.goto('/#/weaknesses');
  120 |   await expect(p.getByRole('heading', { name: '薄弱点与学习依据', exact: true })).toBeVisible();
  121 |   await ready(p);
> 122 |   await expect(status(p)).toHaveAttribute('data-state', 'ready');
      |                           ^ Error: expect(locator).toHaveAttribute(expected) failed
  123 | }
  124 | async function fail(p: Page) {
  125 |   await openAnswer(p, 'exercise.c.echo');
  126 |   const text = await code(p).inputValue();
  127 |   await code(p).fill(text.replace(/printf\([^;]+;/, 'printf("%d\\n", x + 1);'));
  128 |   await expect(p.getByTestId('draft-code-editor')).toHaveAttribute('data-sync', 'synced');
  129 |   await panel(p).getByRole('button', { name: '提交练习', exact: true }).click();
  130 |   await expect(panel(p)).toHaveAttribute('data-state', 'unmet');
  131 |   await expect(p.getByTestId('practice-attempt-save')).toHaveAttribute('data-save-state', 'saved');
  132 | }
  133 | async function mark(p: Page) {
  134 |   await p.goto('/#/lessons/lesson.c.variables-output');
  135 |   await ready(p);
  136 |   await expect(p.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  137 |   await p.locator('[data-knowledge-mark="knowledge.c.variables"]').click();
  138 |   await expect(p.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  139 | }
  140 | async function capture(p: Page, name: string, worker = false) {
  141 |   await writeFile(
  142 |     `${folder}/${name}.json.gz`,
  143 |     gzipSync(
  144 |       JSON.stringify({
  145 |         rows: await archive(p),
  146 |         worker: worker ? await observedCaseSetExecute(p) : null,
  147 |       }),
  148 |     ),
  149 |     { flag: 'wx' },
  150 |   );
  151 | }
  152 | test('19.1 candidate screen preserves honest unavailable-source state and course fallback', async ({
  153 |   page,
  154 | }) => {
  155 |   await page.goto('/#/weaknesses');
  156 |   await expect(page.getByRole('heading', { name: '薄弱点与学习依据', exact: true })).toBeVisible();
  157 |   await expect(page.getByRole('link', { name: '继续原课程 →', exact: true })).toBeVisible();
  158 |   await expect(status(page)).toHaveAttribute('data-state', /^(ready|failed)$/);
  159 |   await expect(page.getByText(/暂停、回退/)).toBeVisible();
  160 | });
  161 | test('19.1 empty data, persisted summary refresh and three responsive widths are honest', async ({
  162 |   page,
  163 | }) => {
  164 |   await open(page);
  165 |   await expect(page.getByTestId('weakness-empty')).toContainText('暂无可确认');
  166 |   const before = await archive(page);
  167 |   await page.reload();
  168 |   await expect(status(page)).toHaveAttribute('data-state', 'ready');
  169 |   expect(await archive(page)).toEqual(before);
  170 |   for (const width of [1440, 768, 390]) {
  171 |     await page.setViewportSize({ width, height: 900 });
  172 |     expect(
  173 |       await page.evaluate(() => document.documentElement.scrollWidth - innerWidth),
  174 |     ).toBeLessThanOrEqual(1);
  175 |     await page.screenshot({ path: `${folder}/empty-${width}.png`, fullPage: true });
  176 |   }
  177 |   await capture(page, 'empty');
  178 | });
  179 | test('19.1 two real Rust failures explain recurrence, repair closes and another failure reopens without duplicate rewards', async ({
  180 |   page,
  181 | }) => {
  182 |   test.setTimeout(90000);
  183 |   await observeCaseSetExecution(page);
  184 |   await confirm(page, 'lesson.c.expressions');
  185 |   await openAnswer(page, 'exercise.c.two-x-plus-three');
  186 |   await submit(page);
  187 |   await fail(page);
  188 |   await open(page);
  189 |   await expect(variable(page)).toContainText('近30天未修复失败 1 次');
  190 |   await fail(page);
  191 |   await open(page);
  192 |   await expect(variable(page)).toContainText('最近通过后有2次真实失败');
  193 |   await variable(page).getByText('查看最近依据（最多3条）', { exact: true }).click();
  194 |   await expect(variable(page)).toContainText('自动证据');
  195 |   await expect(variable(page)).toContainText('答案不符');
  196 |   await capture(page, 'two-real-failures', true);
  197 |   const before = await archive(page);
  198 |   await page.reload();
  199 |   await expect(status(page)).toHaveAttribute('data-state', 'ready');
  200 |   expect(await archive(page)).toEqual(before);
  201 |   await openAnswer(page, 'exercise.c.echo');
  202 |   await submit(page);
  203 |   await open(page);
  204 |   await expect(variable(page)).toHaveCount(0);
  205 |   await page.getByRole('checkbox', { name: '显示已修复与历史', exact: true }).check();
  206 |   await expect(variable(page)).toContainText('现有证据已修复');
  207 |   const repaired = await archive(page);
  208 |   await fail(page);
  209 |   await open(page);
  210 |   await expect(variable(page)).toContainText('近30天未修复失败 1 次');
  211 |   expect((await archive(page)).ledger).toEqual(repaired.ledger);
  212 |   await capture(page, 'reopened', true);
  213 | });
  214 | test('19.1 manual evidence stays distinct, cancellation and peer synchronization preserve true facts', async ({
  215 |   page,
  216 |   context,
  217 | }) => {
  218 |   await mark(page);
  219 |   await open(page);
  220 |   await expect(variable(page)).toContainText('手动自评');
  221 |   const before = await archive(page);
  222 |   const peer = await context.newPage();
```