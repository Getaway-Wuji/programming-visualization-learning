# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p05-course.spec.ts >> P05 fresh archive: 32 real code answers and 140 groups produce 32 confirmed completions and durable deduplicated rewards
- Location: tests\browser\p05-course.spec.ts:615:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByTestId('case-view-coverage')
Expected: "6"
Received: "4"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" getByTestId('case-view-coverage') with timeout 5000ms
  - waiting for getByTestId('case-view-coverage')
    14 × locator resolved to <p data-total="4" data-covered="0" aria-live="polite" data-testid="case-view-coverage">…</p>
       - unexpected value "4"

```

```yaml
- paragraph: 已查看 0 / 4 个关键步骤。请从初始状态逐步前进或播放至结束。
```

# Test source

```ts
  437 |         step.changes.flatMap((change) => (change.op === 'output' ? [change.append] : [])),
  438 |       )
  439 |       .join('');
  440 |     expect(stdout).toBe(group.expectedStdout);
  441 |     const prefix = `${label}-${String(index + 1).padStart(2, '0')}-${group.caseKey}`;
  442 |     await writeFile(join(folder, `${prefix}.request.json`), requestBytes, { flag: 'wx' });
  443 |     await writeFile(join(folder, `${prefix}.result.json`), responseBytes, { flag: 'wx' });
  444 |     await writeFile(join(folder, `${prefix}.catalog.json`), worker.catalogJson!, { flag: 'wx' });
  445 |     results.push({
  446 |       exerciseId: exercise.id,
  447 |       caseKey: group.caseKey,
  448 |       requestSha256: sha(requestBytes),
  449 |       resultSha256: sha(responseBytes),
  450 |       catalogSha256: sha(worker.catalogJson!),
  451 |       steps: result.trace!.steps.length,
  452 |       stdout,
  453 |       protocolVersion: request.protocolVersion,
  454 |       judgeVersion: request.judgeVersion,
  455 |       remainingMs: request.remainingMs,
  456 |     });
  457 |   }
  458 |   return results;
  459 | }
  460 | async function complete(
  461 |   page: Page,
  462 |   content: ContentPackage,
  463 |   lesson: LessonEntity,
  464 |   folder: string,
  465 |   label: string,
  466 | ) {
  467 |   const exercise = content.exercises.find(
  468 |     (entry) => entry.id === lesson.requiredExerciseRefs[0].id,
  469 |   )!;
  470 |   await openLesson(page, lesson);
  471 |   await openAnswer(page, exercise.id);
  472 |   await fillAnswer(page, content, exercise);
  473 |   const offset = await executeCount(page);
  474 |   await submit(page);
  475 |   const runs = await captureRuns(page, content, exercise, offset, folder, label);
  476 |   await expect(page.getByTestId('lesson-completion')).toHaveAttribute('data-state', 'completed');
  477 |   return runs;
  478 | }
  479 | /** The ordinary independent-case path uses its original execution vector in the new package. */
  480 | async function viewAndConfirmCase(page: Page, folder: string, label: string) {
  481 |   const subject = current.cases.find((entry) => entry.id === 'case.c.assignment')!;
  482 |   const casePanel = page.getByTestId('case-execution');
  483 |   const controls = page.getByTestId('player-controls');
  484 |   const confirmation = page.getByTestId('case-view-confirmation');
  485 |   const coverage = page.getByTestId('case-view-coverage');
  486 |   const confirm = confirmation.getByRole('button', { name: '确认已观看', exact: true });
  487 |   await page.goto(`/#/visualize/${subject.id}`);
  488 |   await expect(casePanel).toHaveAttribute('data-state', 'ready');
  489 |   await ready(page);
  490 |   const before = await archive(page);
  491 |   await page.getByTestId('input-field-x').fill('-7');
  492 |   await casePanel.getByRole('button', { name: '应用输入并准备', exact: true }).click();
  493 |   await expect(casePanel).toHaveAttribute('data-state', 'ready');
  494 |   await casePanel.getByRole('button', { name: '运行示例', exact: true }).click();
  495 |   await expect(casePanel).toHaveAttribute('data-state', 'completed');
  496 |   const worker = await observedCaseSetExecute(page);
  497 |   expect(worker.moduleSeen).toBe(true);
  498 |   expect(worker.responseOk).toBe(true);
  499 |   expect(worker.terminated).toBe(true);
  500 |   expect(worker.responseOperationId).toBe(worker.operationId);
  501 |   const requestBytes = Buffer.from(worker.requestBytes!);
  502 |   const resultBytes = Buffer.from(worker.responseBytes!);
  503 |   // Preserve actual packets before consumer assertions or viewing can fail.
  504 |   await writeFile(join(folder, `${label}.request.json`), requestBytes, { flag: 'wx' });
  505 |   await writeFile(join(folder, `${label}.result.json`), resultBytes, { flag: 'wx' });
  506 |   await writeFile(join(folder, `${label}.catalog.json`), worker.catalogJson!, { flag: 'wx' });
  507 |   const request = JSON.parse(requestBytes.toString('utf8')) as ExecuteRequest;
  508 |   const result = await decodeResult(Uint8Array.from(resultBytes).buffer, request);
  509 |   expect(request.packageRef).toEqual(p05Package);
  510 |   expect(request.subjectRef).toEqual({ id: subject.id, version: subject.version });
  511 |   expect(request.mode).toBe('case');
  512 |   expect(request.input.values).toEqual({ x: -7 });
  513 |   expect(request.input.random).toBeNull();
  514 |   expect([
  515 |     request.protocolVersion,
  516 |     request.traceVersion,
  517 |     request.diagnosticVersion,
  518 |     request.judgeVersion,
  519 |     request.encodingVersion,
  520 |   ]).toEqual(['1.0.0', '1.0.0', '1.0.0', '1.0.0', '1.0.0']);
  521 |   expect(result.producer).toBe('rust');
  522 |   expect(result.identity).toEqual(request.identity);
  523 |   expect(result.terminal).toMatchObject({ status: 'completed', exitCode: 0, diagnostics: [] });
  524 |   expect(result.trace?.completeness).toBe('complete');
  525 |   expect(request.source.text).toBe(
  526 |     await casePanel.getByRole('textbox', { name: '当前执行的 C 代码', exact: true }).inputValue(),
  527 |   );
  528 |   const stdout = result
  529 |     .trace!.steps.flatMap((step) =>
  530 |       step.changes.flatMap((change) => (change.op === 'output' ? [change.append] : [])),
  531 |     )
  532 |     .join('');
  533 |   expect(stdout).toBe('-5\n');
  534 |   const length = result.trace!.steps.length;
  535 |   expect(length).toBeGreaterThan(0);
  536 |   await expect(controls).toHaveAttribute('data-cursor', '0');
> 537 |   await expect(coverage).toHaveAttribute('data-total', String(length));
      |                          ^ Error: expect(locator).toHaveAttribute(expected) failed
  538 |   await expect(confirm).toBeDisabled();
  539 |   const trace = page.getByTestId('trace-view');
  540 |   const painted = async () =>
  541 |     page.evaluate(
  542 |       () =>
  543 |         new Promise<void>((resolve) => {
  544 |           requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
  545 |         }),
  546 |     );
  547 |   await trace.scrollIntoViewIfNeeded();
  548 |   await painted();
  549 |   const viewedCursors = [0];
  550 |   for (let cursor = 1; cursor <= length; cursor++) {
  551 |     await controls.getByRole('button', { name: '前进', exact: true }).click();
  552 |     await expect(controls).toHaveAttribute('data-cursor', String(cursor));
  553 |     await expect(trace).toHaveAttribute('data-cursor', String(cursor));
  554 |     await trace.scrollIntoViewIfNeeded();
  555 |     await painted();
  556 |     await expect(coverage).toHaveAttribute('data-covered', String(cursor));
  557 |     viewedCursors.push(cursor);
  558 |   }
  559 |   await expect(confirmation).toHaveAttribute('data-view-state', 'ready');
  560 |   const beforeConfirm = await archive(page);
  561 |   stableLearning(before.data, beforeConfirm.data);
  562 |   const coverageBeforeConfirm = {
  563 |     covered: Number(await coverage.getAttribute('data-covered')),
  564 |     total: Number(await coverage.getAttribute('data-total')),
  565 |   };
  566 |   await confirm.click();
  567 |   await expect(confirmation).toHaveAttribute('data-view-state', 'saved');
  568 |   await ready(page);
  569 |   const saved = await archive(page);
  570 |   noExecutionPersistence(saved.data);
  571 |   return {
  572 |     saved,
  573 |     run: {
  574 |       label,
  575 |       packageRef: request.packageRef,
  576 |       subjectRef: request.subjectRef,
  577 |       mode: request.mode,
  578 |       identity: request.identity,
  579 |       requestSha256: sha(requestBytes),
  580 |       resultSha256: sha(resultBytes),
  581 |       catalogSha256: sha(worker.catalogJson!),
  582 |       steps: length,
  583 |       stdout,
  584 |       viewedCursors,
  585 |       coverageBeforeConfirm,
  586 |       before,
  587 |       beforeConfirm,
  588 |     },
  589 |   };
  590 | }
  591 | async function openGoals(page: Page) {
  592 |   await page.goto('/#/?panel=goals');
  593 |   await ready(page);
  594 |   await expect(page.getByRole('dialog', { name: '每日目标', exact: true })).toBeVisible();
  595 | }
  596 | async function fillTargets(page: Page, value: GoalTargets) {
  597 |   const form = page.getByTestId('daily-goal-settings');
  598 |   for (const [name, count] of [
  599 |     ['每日练习数', value.exercise],
  600 |     ['每日小节数', value.lesson],
  601 |     ['每日案例数', value.case],
  602 |   ] as const)
  603 |     await form.getByRole('spinbutton', { name, exact: true }).fill(String(count));
  604 | }
  605 | async function saveTargets(page: Page, value: GoalTargets) {
  606 |   await fillTargets(page, value);
  607 |   await page
  608 |     .getByTestId('daily-goal-settings')
  609 |     .getByRole('button', { name: '保存自定义目标', exact: true })
  610 |     .click();
  611 |   await ready(page);
  612 |   await expect(page.getByTestId('goal-template-saved')).toContainText('目标已保存');
  613 | }
  614 | 
  615 | test('P05 fresh archive: 32 real code answers and 140 groups produce 32 confirmed completions and durable deduplicated rewards', async ({
  616 |   page,
  617 | }, info) => {
  618 |   test.setTimeout(300_000);
  619 |   bundlePath();
  620 |   const folder = await directory(info, 'fresh-32');
  621 |   expect(await page.context().storageState({ indexedDB: true })).toEqual({
  622 |     cookies: [],
  623 |     origins: [],
  624 |   });
  625 |   await page.goto('/#/courses');
  626 |   await ready(page);
  627 |   await expect(page.locator('[data-course-lesson]')).toHaveCount(32);
  628 |   const initial = await archive(page);
  629 |   expect(initial.databaseVersion).toBe(9);
  630 |   expect(initial.stores).toHaveLength(17);
  631 |   expect(initial.data.meta.activePackageRef).toEqual(p05Package);
  632 |   for (const key of ['progress', 'receipts', 'ledger', 'dailyFacts', 'goals'] as const)
  633 |     expect(initial.data[key]).toEqual([]);
  634 |   const runs = [];
  635 |   for (const [index, lesson] of current.lessons.entries()) {
  636 |     const next = await complete(
  637 |       page,
```