import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const sha=b=>createHash('sha256').update(b).digest('hex');
const base=JSON.parse(readFileSync('.artifacts/19.1/baseline.json','utf8'));
const changed=[],missing=[];
for(const e of base.files){if(!existsSync(e.path)){missing.push(e.path);continue;}const hash=sha(readFileSync(e.path));if(hash!==e.sha256)changed.push({path:e.path,before:e.sha256,after:hash});}
const release=JSON.parse(readFileSync('content/c/p0/blockly-release-1.0.63.json','utf8'));
for(const e of release.files)if(sha(readFileSync(e.path))!==e.sha256)throw new Error('Unreviewed '+e.path);
const protectedPaths=base.files.filter(e=>/2026-10-31-(?:CI|GitHub-Actions)/.test(e.path)||e.path==='.taste-skill/direction.json');
for(const e of protectedPaths)if(sha(readFileSync(e.path))!==e.sha256)throw new Error('Other owner '+e.path);
for(const p of ['package.json','package-lock.json','Cargo.toml','Cargo.lock','vite.config.ts','tsconfig.json']){const e=base.files.find(e=>e.path===p);if(sha(readFileSync(p))!==e.sha256)throw new Error('Root change '+p);}
const git=a=>execFileSync('git',a,{encoding:'utf8'}).trim();
const report={at:new Date().toISOString(),baselineFiles:base.files.length,head:git(['rev-parse','HEAD']),stage:git(['diff','--cached','--name-only']),aheadBehind:git(['rev-list','--left-right','--count','HEAD...origin/main']),missing,changed,reviewedSources:release.files.length,release:release.releaseVersion,otherOwnerProtected:protectedPaths.length,otherOwnerPaths:protectedPaths.map(e=>e.path)};
writeFileSync('.artifacts/19.1/audit-current.json',JSON.stringify(report,null,2)+'\n');console.log({...report,changed:changed.map(e=>e.path)});
