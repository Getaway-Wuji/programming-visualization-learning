# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scheduler.spec.ts >> 15.3 formal peer clear discards a pending review and never resurrects its source or schedule
- Location: tests\browser\scheduler.spec.ts:245:1

# Error details

```
Error: page.evaluate: SecurityError: Failed to execute 'open' on 'IDBFactory': access to the Indexed Database API is denied in this context.
    at db (eval at evaluate (:370:30), <anonymous>:3:29)
    at new Promise (<anonymous>)
    at eval (eval at evaluate (:370:30), <anonymous>:2:22)
    at UtilityScript.evaluate (<anonymous>:372:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary [ref=e5]:
    - button "收起侧栏" [expanded] [ref=e6] [cursor=pointer]
    - link "编程可视化教学平台 · 学习首页" [ref=e10] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e11]: "{ }"
      - generic [ref=e12]:
        - text: 一步一懂
        - generic [ref=e13]: 编程可视化教学平台
    - paragraph [ref=e14]: 从代码，到理解。
    - navigation "主导航" [ref=e15]:
      - link "学习首页" [ref=e16] [cursor=pointer]:
        - /url: "#/"
      - link "C 语言课程" [ref=e20] [cursor=pointer]:
        - /url: "#/courses"
      - link "进阶课程" [ref=e24] [cursor=pointer]:
        - /url: "#/advanced"
      - link "算法与演示" [ref=e28] [cursor=pointer]:
        - /url: "#/cases"
      - link "C 代码工作台" [ref=e32] [cursor=pointer]:
        - /url: "#/custom-code"
      - link "编译流程" [ref=e36] [cursor=pointer]:
        - /url: "#/compilation"
      - link "错题与陌生点" [ref=e40] [cursor=pointer]:
        - /url: "#/notebook"
      - link "今日复习" [ref=e44] [cursor=pointer]:
        - /url: "#/reviews"
      - link "学习成就" [ref=e48] [cursor=pointer]:
        - /url: "#/achievements"
      - link "本地设置" [ref=e52] [cursor=pointer]:
        - /url: "#/settings"
    - generic [ref=e56]:
      - strong [ref=e59]: 按自己的节奏学习
      - paragraph [ref=e60]: 学习记录将保存在当前浏览器，不跨设备同步。
      - link "了解本地数据" [ref=e61] [cursor=pointer]:
        - /url: "#/settings?panel=data"
  - generic [ref=e64]:
    - banner [ref=e65]:
      - generic [ref=e66]: C 语言 · 从零开始
      - generic [ref=e67]:
        - generic [ref=e68]: 本地学习
        - link "本地数据" [ref=e69] [cursor=pointer]:
          - /url: "#/settings?panel=data"
        - button "切换为深色" [ref=e73] [cursor=pointer]
    - main [ref=e76]:
      - generic [ref=e77]:
        - generic [ref=e78]:
          - paragraph [ref=e79]: 本地复习
          - heading "今日复习" [level=1] [ref=e80]
          - paragraph [ref=e81]: 回顾真实错题和自己标记的陌生点，再用自评安排下一次复习。
        - status [ref=e82]:
          - paragraph [ref=e83]: 复习计划尚未保存或无法确认（S_QUOTA）。已有记录保留。
          - paragraph [ref=e84]: 有1项复习操作未保存，刷新会丢失；显示的仍是已保存计划。
          - button "重试复习操作" [ref=e85] [cursor=pointer]
        - paragraph [ref=e86]: 2026-11-01 · Asia/Shanghai · 自评不代表练习通过，不增加积分或课程完成。
        - paragraph [ref=e87]: 到期 1 · 未到期 0 · 暂停 0
        - generic [ref=e88]:
          - region "复习卡片列表" [ref=e89]:
            - generic [ref=e90]:
              - heading "到期 · 1" [level=2] [ref=e91]
              - list [ref=e92]:
                - listitem [ref=e93]:
                  - button "变量与作用域 陌生知识 · 2026-11-01" [pressed] [ref=e94] [cursor=pointer]:
                    - generic [ref=e95]: 变量与作用域
                    - generic [ref=e96]: 陌生知识 · 2026-11-01
            - generic [ref=e97]:
              - heading "未到期 · 0" [level=2] [ref=e98]
              - paragraph [ref=e99]: 没有尚未到期的计划。
            - generic [ref=e100]:
              - heading "暂停 · 0" [level=2] [ref=e101]
              - paragraph [ref=e102]: 没有暂停的卡片。
          - region [ref=e103]:
            - paragraph [ref=e104]: 陌生知识自评
            - heading "变量与作用域" [level=2] [ref=e105]
            - paragraph [ref=e106]: 待复习 · 下次复习 2026-11-01 · 已评价 0 次
            - paragraph [ref=e107]: 先回顾来源，想一想概念或解题方法，再选择最接近当前情况的评价。
            - link "复习：变量和输出" [ref=e109] [cursor=pointer]:
              - /url: "#/lessons/lesson.c.variables-output"
            - generic "本次复习评价" [ref=e110]:
              - button "重学 下次 2026-11-02" [disabled] [ref=e111]:
                - generic [ref=e112]: 重学
                - generic [ref=e113]: 下次 2026-11-02
              - button "吃力 下次 2026-11-02" [disabled] [ref=e114]:
                - generic [ref=e115]: 吃力
                - generic [ref=e116]: 下次 2026-11-02
              - button "记得 下次 2026-11-02" [disabled] [ref=e117]:
                - generic [ref=e118]: 记得
                - generic [ref=e119]: 下次 2026-11-02
              - button "熟练 下次 2026-11-04" [disabled] [ref=e120]:
                - generic [ref=e121]: 熟练
                - generic [ref=e122]: 下次 2026-11-04
            - button "重新学习此卡（今天到期）" [disabled] [ref=e123] [cursor=pointer]
        - group [ref=e124]:
          - generic "复习日期怎样安排" [ref=e125] [cursor=pointer]
```