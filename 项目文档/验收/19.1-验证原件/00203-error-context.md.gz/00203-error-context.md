# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scheduler.spec.ts >> 15.3 formal real Rust failure creates one card, run-one does not, pass pauses and new failure reopens
- Location: tests\browser\scheduler.spec.ts:127:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('.app-shell')
Expected: "ready"
Received: "conflict"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('.app-shell') with timeout 5000ms
  - waiting for locator('.app-shell')
    14 × locator resolved to <div data-nav-open="false" data-sidebar="expanded" class="app-shell p05-app" data-workbench-mode="standard" data-learning-goal-status="ready" data-review-storage-status="ready" data-learning-reward-status="ready" data-learning-reading-status="ready" data-learning-profile-status="ready" data-learning-practice-status="ready" data-learning-storage-status="conflict" data-achievement-storage-status="ready">…</div>
       - unexpected value "conflict"

```

```yaml
- link "跳到主要内容":
  - /url: "#main-content"
- complementary:
  - button "收起侧栏" [expanded]
  - link "编程可视化教学平台 · 学习首页":
    - /url: "#/"
    - text: "{ } 一步一懂 编程可视化教学平台"
  - paragraph: 从代码，到理解。
  - navigation "主导航"
  - strong: 按自己的节奏学习
  - paragraph: 学习记录将保存在当前浏览器，不跨设备同步。
  - link "了解本地数据":
    - /url: "#/settings?panel=data"
- banner:
  - text: C 语言 · 从零开始
  - button "进入专注模式": 专注
  - text: 本地学习
  - link "本地数据":
    - /url: "#/settings?panel=data"
  - button "切换为深色" [disabled]
- main:
  - navigation "当前位置"
  - paragraph: 动手练习 · 程序与输入
  - heading "输出输入变量" [level=1]
  - paragraph: 用 C 代码或积木解答，提交后逐步复盘真实执行。
  - paragraph: 尚无已保存的学习记录
  - heading "题目与答题区" [level=2]
  - paragraph: 保留输入源变量x（-999到999），用输出积木读取x，输出它的十进制整数和一个换行，不要加提示文字。例：x=7输出7并换行，x=0输出0，x=-9输出-9。必须实际声明、读取输入变量，不能打印固定答案。所有测试正常结束且main返回0。思路：先找到输入声明，再把变量读取放进printf的%d参数。
  - paragraph: 教学目标：真实声明并读取x，输出依赖输入，不打印固定答案。
  - group: 练习与保存说明
  - button "独立练习" [pressed]
  - button "改错练习"
  - button "拆积木练习"
  - link "查看课程示例":
    - /url: "#/lessons/lesson.c.variables-output"
  - paragraph: 从零搭建解答。已保留本题输入声明，请在 main 中加入你的程序。各模式草稿独立保留，切换会清除本次结果；已保存的编辑历史可在离题或刷新后选择恢复，未保存内容可能丢失。示例在新标签页打开。
  - strong: 需要一点帮助？
  - button "查看第 1 层提示"
  - button "运行本组"
  - button "准备代码"
  - button "提交练习"
  - button "取消运行" [disabled]
  - link "查看本次复盘":
    - /url: "#/practice/exercise.c.echo/review"
  - paragraph: 运行本组只检查第一组输入，不记录通过或积分；提交练习才检查全部3 组与教学目标。准备代码只生成源码。 修改积木或代码会立即使旧判定和轨迹失效；已保存的历史通过仍保留。
  - text: 积木显示
  - combobox "积木显示"
  - paragraph: 本节推荐代码作答。隐藏积木后仍可写代码、运行和提交；切换显示不会修改解答。
  - alert: 其他页面已更新档案，这次选择仅临时使用，尚未保存。
  - button "重新读取并保存选择"
  - button "采用已保存选择"
  - group: 积木权限：已永久解锁 0 / 20 · 本节临时开放 8 类
  - group: 编辑历史 · 3 条已保存
  - region "编辑代码"
  - heading "本组运行结果" [level=3]
  - paragraph: 这是第一组输入的运行与局部检查，不代表全部测试通过。确认程序后，提交练习检查全部测试。
  - status: 当前输入已运行结束；这不代表全部测试通过，也没有保存通过记录。
  - paragraph: 程序正常结束，返回值 0。程序能够结束，但本题要求尚未全部满足。
  - list
  - paragraph: 输出按原样比较，空格与换行也计入；教学目标需要真实的输入贡献或控制路径，只有输出相同仍可能未通过。
  - heading "本组实际输出" [level=4]
  - text: "0"
  - heading "本组预期输出" [level=4]
  - text: "7"
  - alert
  - region "小节完成清单"
  - paragraph: 当前源码与复盘对应测试组：positive。只保留本组轨迹；复盘不重新运行。
  - paragraph
  - group: 查看本组实际执行的 C 代码
  - region "运行结果"
  - paragraph: 积木只生成受支持的 C 程序。返回本节可查看已保存的历史进度。
  - link "返回本节学习":
    - /url: "#/lessons/lesson.c.variables-output"
```

# Test source

```ts
  1   | import { mkdir, writeFile } from 'node:fs/promises';
  2   | import { gzipSync } from 'node:zlib';
  3   | import { expect, type Page } from '@playwright/test';
  4   | import {
  5   |   archive,
  6   |   ready,
  7   |   openAnswer,
  8   |   submit,
  9   |   confirm,
  10  |   code,
  11  |   panel,
  12  |   observeCaseSetExecution,
  13  | } from './notebook-helpers';
  14  | import { observedCaseSetExecute } from './case-set-observation';
  15  | import type { ReviewCard } from '../../web/src/review-scheduler/model';
  16  | import type { KnowledgeMark } from '../../web/src/storage/knowledge-marks';
  17  | export { ready, openAnswer, submit, confirm, code, panel, observeCaseSetExecution };
  18  | export const folder = `.artifacts/15.3/browser/${process.env.TASK_EVIDENCE_LABEL ?? 'local'}`;
  19  | export const status = (p: Page) => p.getByTestId('review-save-status');
  20  | export async function native(p: Page) {
  21  |   return (await archive(p)) as Awaited<ReturnType<typeof archive>> & {
  22  |     reviewCards: ReviewCard[];
  23  |     knowledgeMarks: KnowledgeMark[];
  24  |   };
  25  | }
  26  | export async function reviewReady(p: Page) {
> 27  |   await expect(p.locator('.app-shell')).toHaveAttribute('data-learning-storage-status', 'ready');
      |                                         ^ Error: expect(locator).toHaveAttribute(expected) failed
  28  |   await expect(p.locator('.app-shell')).toHaveAttribute('data-review-storage-status', 'ready');
  29  |   await expect.poll(async () => (await native(p)).settings.goalTemplate).not.toBeNull();
  30  | }
  31  | export async function reviews(p: Page) {
  32  |   await p.goto('/#/reviews');
  33  |   await expect(p.getByRole('heading', { level: 1, name: '今日复习', exact: true })).toBeVisible();
  34  |   await reviewReady(p);
  35  | }
  36  | export async function mark(p: Page) {
  37  |   await p.goto('/#/lessons/lesson.c.variables-output');
  38  |   await ready(p);
  39  |   await expect(p.getByTestId('knowledge-marks-status')).toHaveAttribute('data-state', 'ready');
  40  |   await reviewReady(p);
  41  |   await p.locator('[data-knowledge-mark="knowledge.c.variables"]').click();
  42  |   await expect(p.locator('[data-knowledge-mark="knowledge.c.variables"]')).toHaveAttribute(
  43  |     'aria-pressed',
  44  |     'true',
  45  |   );
  46  |   await reviews(p);
  47  |   await expect.poll(async () => (await native(p)).reviewCards.length).toBe(1);
  48  | }
  49  | export async function changePrint(p: Page, expression: string) {
  50  |   const source = await code(p).inputValue();
  51  |   await code(p).fill(source.replace(/printf\([^;]+;/, `printf("%d\\n", ${expression});`));
  52  |   await expect(p.getByTestId('draft-code-editor')).toHaveAttribute('data-sync', 'synced');
  53  | }
  54  | export async function fail(p: Page) {
  55  |   await panel(p).getByRole('button', { name: '提交练习', exact: true }).click();
  56  |   await expect(panel(p)).toHaveAttribute('data-state', 'unmet');
  57  |   await expect(p.getByTestId('practice-attempt-save')).toHaveAttribute('data-save-state', 'saved');
  58  |   await reviewReady(p);
  59  | }
  60  | export async function capture(p: Page, name: string) {
  61  |   const actual = await observedCaseSetExecute(p);
  62  |   expect(actual.moduleSeen).toBe(true);
  63  |   expect(actual.responseOk).toBe(true);
  64  |   await mkdir(folder, { recursive: true });
  65  |   await writeFile(`${folder}/${name}.json.gz`, gzipSync(JSON.stringify(actual)), { flag: 'wx' });
  66  | }
  67  | export function sameLearning(
  68  |   before: Awaited<ReturnType<typeof native>>,
  69  |   after: Awaited<ReturnType<typeof native>>,
  70  | ) {
  71  |   for (const key of [
  72  |     'progress',
  73  |     'receipts',
  74  |     'dailyFacts',
  75  |     'ledger',
  76  |     'goals',
  77  |     'aliases',
  78  |     'settings',
  79  |     'avatar',
  80  |     'appearance',
  81  |     'appearanceAssets',
  82  |   ] as const)
  83  |     expect(after[key]).toEqual(before[key]);
  84  | }
  85  | export async function quota(p: Page) {
  86  |   await p.addInitScript(() => {
  87  |     const c = { armed: false, ids: [] as string[] };
  88  |     Object.assign(window, { __reviewQuota: c });
  89  |     const put = IDBObjectStore.prototype.put;
  90  |     IDBObjectStore.prototype.put = function (value, key) {
  91  |       if (
  92  |         this.name === 'reviewCards' &&
  93  |         (value as { lastCommand?: { mode: string; commandId: string } }).lastCommand?.mode ===
  94  |           'rate'
  95  |       ) {
  96  |         c.ids.push((value as { lastCommand: { commandId: string } }).lastCommand.commandId);
  97  |         if (c.armed) {
  98  |           c.armed = false;
  99  |           throw new DOMException('15.3 native review quota', 'QuotaExceededError');
  100 |         }
  101 |       }
  102 |       return key === undefined ? put.call(this, value) : put.call(this, value, key);
  103 |     };
  104 |   });
  105 | }
  106 | export async function arm(p: Page) {
  107 |   await p.evaluate(() => {
  108 |     (window as unknown as { __reviewQuota: { armed: boolean } }).__reviewQuota.armed = true;
  109 |   });
  110 | }
  111 | export async function clear(p: Page) {
  112 |   const generation = (await native(p)).meta.generation;
  113 |   await p.goto('/#/settings?panel=data');
  114 |   // Full clear is also valid for an unsaved/partially unavailable archive.
  115 |   await expect(p.getByRole('button', { name: '清除本地数据', exact: true })).toBeEnabled();
  116 |   await p.getByRole('button', { name: '清除本地数据', exact: true }).click();
  117 |   await p
  118 |     .getByRole('dialog', { name: '确认清除本地数据', exact: true })
  119 |     .getByRole('button', { name: '确认清除', exact: true })
  120 |     .click();
  121 |   await expect.poll(async () => (await native(p)).meta.generation).not.toBe(generation);
  122 | }
  123 | 
```