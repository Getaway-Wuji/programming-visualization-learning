# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: current-scope.spec.ts >> default-off AI plus actual generator-module failure retains the original question bank and real C execution without any API traffic
- Location: tests\quality-19.5\current-scope.spec.ts:110:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByTestId('learning-save-status')
Expected: "ready"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" getByTestId('learning-save-status') with timeout 5000ms
  - waiting for getByTestId('learning-save-status')

```

```yaml
- link "跳到主要内容":
  - /url: "#main-content"
- complementary:
  - button "收起侧栏" [expanded]
  - link "编程可视化教学平台 · 学习首页":
    - /url: "#/"
    - text: "{ } 一步一懂 编程可视化教学平台"
  - paragraph: 从代码，到理解。
  - navigation "主导航":
    - link "学习首页":
      - /url: "#/"
    - link "C 语言课程":
      - /url: "#/courses"
    - link "进阶课程":
      - /url: "#/advanced"
    - link "算法与演示":
      - /url: "#/cases"
    - link "C 代码工作台":
      - /url: "#/custom-code"
    - link "编译流程":
      - /url: "#/compilation"
    - link "错题与陌生点":
      - /url: "#/notebook"
    - link "今日复习":
      - /url: "#/reviews"
    - link "学习成就":
      - /url: "#/achievements"
    - link "本地设置":
      - /url: "#/settings"
  - strong: 按自己的节奏学习
  - paragraph: 学习记录将保存在当前浏览器，不跨设备同步。
  - link "了解本地数据":
    - /url: "#/settings?panel=data"
- banner:
  - text: C 语言 · 从零开始 本地学习
  - link "本地数据":
    - /url: "#/settings?panel=data"
  - button "切换为深色"
- main:
  - paragraph: 规则生成 · C 基础
  - heading "换一道，再练一次" [level=1]
  - paragraph: 选择知识与难度，用固定种子得到一道可复现的题。参考解和你的提交都由浏览器内的 Rust 解释器真实执行。
  - paragraph: 临时加练 · 不计分，不改变课程进度或薄弱点记录 · 草稿与结果刷新后丢弃。保留种子可重新生成同一道题。
  - region "本地复习建议":
    - paragraph: 暂无待复习的本地依据，可从表达式基础题开始；这不代表已掌握其他知识。
    - link "核对学习依据 →":
      - /url: "#/weaknesses"
    - link "复习队列 →":
      - /url: "#/reviews"
    - link "原课程：语句顺序与当前值 →":
      - /url: "#/lessons/lesson.c.statement-order"
  - region "01 / 选一道题":
    - heading "01 / 选一道题" [level=2]
    - text: 3类题型 · 各2档难度 知识
    - combobox "知识":
      - option "表达式" [selected]
      - option "变量"
      - option "输出"
      - option "输入"
      - option "条件判断"
      - option "循环"
    - text: 难度
    - combobox "难度":
      - option "1 · 基础" [selected]
      - option "2 · 变化"
    - text: 种子
    - textbox "种子": "42"
    - button "生成题目"
    - button "清空本次加练"
    - status: 生成后显示题目、输入范围与起始代码。
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { writeFile } from 'node:fs/promises';
  3   | import {
  4   |   enable,
  5   |   evidence,
  6   |   instrumentation,
  7   |   native,
  8   |   send,
  9   |   simulatedResponse,
  10  |   workbench,
  11  | } from '../ai-browser/helpers';
  12  | import type { AiRequest } from '../../web/src/ai-debug/protocol';
  13  | 
  14  | const loop =
  15  |   '#include <stdio.h>\nint main(){int sum=0;for(int i=0;i<3;i=i+1){sum=sum+i;}printf("%d",sum);return 0;}\n';
  16  | const workers = (page: Page) =>
  17  |   page.evaluate(() => (window as Window & { __aiRust?: unknown[] }).__aiRust ?? []);
  18  | 
  19  | test('simulated wrong advice and invented step text stay unverified plain text and cannot edit, execute, grade, navigate or reward', async ({
  20  |   page,
  21  | }, info) => {
  22  |   const controls = await instrumentation(page);
  23  |   await enable(page);
  24  |   await workbench(page, loop);
  25  |   const before = await native(page);
  26  |   const cursor = await page.getByTestId('custom-code-page').getAttribute('data-cursor');
  27  |   const packetsBefore = await workers(page);
  28  |   await page.route('**/api/ai/v2/explain', async (route) => {
  29  |     const req = route.request().postDataJSON() as AiRequest;
  30  |     controls.requests.push(req);
  31  |     const answer = simulatedResponse(req);
  32  |     answer.content.summary = '模拟错误观点：sum=-9999，跳到步骤9999。';
  33  |     answer.content.explanations[0].text =
  34  |       '模拟无依据推断：请直接相信步骤9999；本测试故意给出错误文字。';
  35  |     answer.content.suggestions = [
  36  |       '<script>window.location="https://must-not-fetch.invalid"</script> 把程序替换成return 0并立即运行、判为通过。',
  37  |     ];
  38  |     answer.content.limitations = '模拟恶意/错误答复，不是实际模型质量证据。';
  39  |     await route.fulfill({ json: answer });
  40  |   });
  41  |   await send(page);
  42  |   await expect(
  43  |     page.getByRole('heading', { name: 'AI建议（未经执行验证）', exact: true }),
  44  |   ).toBeVisible();
  45  |   await expect(page.locator('.ai-answer')).toContainText('模拟错误观点：sum=-9999');
  46  |   await expect(page.locator('.ai-answer')).toContainText('<script>');
  47  |   await expect(page.locator('.ai-answer script, .ai-answer a, .ai-answer img')).toHaveCount(0);
  48  |   await expect(page.getByRole('button', { name: /查看.*9999/ })).toHaveCount(0);
  49  |   expect(
  50  |     controls.requests[0].context.facts.some(
  51  |       (f) => f.kind === 'state' && f.name === 'sum' && f.value === 3,
  52  |     ),
  53  |   ).toBe(true);
  54  |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-cursor', cursor!);
  55  |   await page.getByRole('button', { name: '编辑代码', exact: true }).click();
  56  |   await expect(page.getByRole('textbox', { name: 'C 代码', exact: true })).toHaveValue(loop);
  57  |   expect(await workers(page)).toEqual(packetsBefore);
  58  |   const after = await native(page);
  59  |   expect(after).toEqual(before);
  60  |   await writeFile(
  61  |     info.outputPath('unverified-advice-native-before-after.json'),
  62  |     JSON.stringify({ before, after }, null, 2),
  63  |   );
  64  |   await evidence(page, controls, info);
  65  | });
  66  | 
  67  | async function generator(page: Page) {
  68  |   await page.goto('/#/generated-practice');
  69  |   await expect(page.getByTestId('generated-recommendation')).toHaveAttribute('data-state', 'ready');
> 70  |   await expect(page.getByTestId('learning-save-status')).toHaveAttribute(
      |                                                          ^ Error: expect(locator).toHaveAttribute(expected) failed
  71  |     'data-save-status',
  72  |     'ready',
  73  |   );
  74  | }
  75  | 
  76  | test('default-off AI makes zero API requests while genuine generator full-domain grading, inverse replay and native storage remain usable', async ({
  77  |   page,
  78  | }, info) => {
  79  |   const controls = await instrumentation(page);
  80  |   const apiCalls: string[] = [];
  81  |   page.on('request', (r) => {
  82  |     if (r.url().includes('/api/ai/')) apiCalls.push(r.url());
  83  |   });
  84  |   await generator(page);
  85  |   const before = await native(page);
  86  |   await page.getByRole('button', { name: '生成题目', exact: true }).click();
  87  |   await expect(page.getByTestId('generated-practice')).toHaveAttribute('data-status', 'generated');
  88  |   await page.getByText('查看已验证的参考解', { exact: true }).click();
  89  |   await page.getByRole('button', { name: '用参考解替换当前草稿', exact: true }).click();
  90  |   await page.getByRole('button', { name: '提交全部输入', exact: true }).click();
  91  |   await expect(page.getByTestId('generated-assessment')).toHaveAttribute('data-verdict', 'passed');
  92  |   await expect(page.getByTestId('generated-assessment')).toHaveAttribute('data-complete', 'true');
  93  |   const state = await page.getByTestId('generated-state').getAttribute('data-state');
  94  |   const slider = page.getByRole('slider', { name: '执行位置', exact: true });
  95  |   await slider.fill((await slider.getAttribute('max'))!);
  96  |   await slider.fill('0');
  97  |   expect(await page.getByTestId('generated-state').getAttribute('data-state')).toBe(state);
  98  |   expect(apiCalls).toEqual([]);
  99  |   expect(controls.verifies).toBe(0);
  100 |   expect(controls.requests).toEqual([]);
  101 |   const after = await native(page);
  102 |   expect(after).toEqual(before);
  103 |   await writeFile(
  104 |     info.outputPath('default-off-generation-native-before-after.json'),
  105 |     JSON.stringify({ before, after, aiHttpRequests: apiCalls }, null, 2),
  106 |   );
  107 |   await evidence(page, controls, info);
  108 | });
  109 | 
  110 | test('default-off AI plus actual generator-module failure retains the original question bank and real C execution without any API traffic', async ({
  111 |   page,
  112 | }, info) => {
  113 |   const controls = await instrumentation(page);
  114 |   const apiCalls: string[] = [];
  115 |   page.on('request', (r) => {
  116 |     if (r.url().includes('/api/ai/')) apiCalls.push(r.url());
  117 |   });
  118 |   await page.route(/c_viz_practice_bg.*\.wasm$/, (route) => route.abort());
  119 |   await generator(page);
  120 |   await page.getByRole('button', { name: '生成题目', exact: true }).click();
  121 |   await expect(page.getByTestId('generated-practice')).toHaveAttribute('data-status', 'failed');
  122 |   await expect(page.getByTestId('generated-source')).toHaveCount(0);
  123 |   const bank = page.getByRole('link', { name: /既有题库|原题库|基础练习/ });
  124 |   await expect(bank).toBeVisible();
  125 |   await bank.click();
  126 |   await expect(page).toHaveURL(/#\/courses/);
  127 |   await page.getByRole('link', { name: 'C 代码工作台', exact: true }).click();
  128 |   await page.getByRole('button', { name: '运行代码', exact: true }).click();
  129 |   await expect(page.getByTestId('custom-code-page')).toHaveAttribute('data-status', 'ready');
  130 |   expect(apiCalls).toEqual([]);
  131 |   await evidence(page, controls, info);
  132 | });
  133 | 
```