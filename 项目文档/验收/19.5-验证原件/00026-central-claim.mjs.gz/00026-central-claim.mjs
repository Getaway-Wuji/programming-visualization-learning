import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
for(const path of ['README.md','项目守则.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md']){
 let s=readFileSync(path,'utf8');assert.ok(!s.includes('19.5当前范围领取（2026-11-01）'));
 const prefix=path.includes('/')?'./':'./项目文档/';
 const entry=`19.5当前范围领取（2026-11-01）：用户明确“先完成后面的任务吧，我现在先不提供key后面再说，现在先是默认关闭”。按[DEC-P2-012](${prefix}架构决策/19.5-默认关闭范围与真实API后置裁决.md)，真实19.4/19.5及20.4相应AI验证后置，未验事实保留，不再阻挡19.5→第20。root在同聊天仅领取19.5质量/降级，复用19.2原全验及协调实核的19.4独立工程；AI默认关闭，不索取/寻找Key、不请求官方鉴权/推理、不下载模型。原全量口径82/88、主82/98、P2 13/19、第19全验3/5保持；本次范围另计，19.5尚未通过不提前增加。20/Git仍待协调另派；第20授权范围验收、交接及Git远端实核后停止，不进入21，不自动补后置AI。旧冻结契约/原件/成功与失败记录保持；本条覆盖旧“等Key再后续”的顺序限制。`;
 const blank=/\r?\n\r?\n/.exec(s);assert.ok(blank);const at=blank.index+blank[0].length;s=s.slice(0,at)+entry+blank[0]+s.slice(at);
 if(path.endsWith('任务进度与交接.md')){
  s=s.replace(/^\| 19\.4 \|.*$/m,'| 19.4 | P2 | [基于真实轨迹的 AI 调试](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 本次范围工程验收通过；真实AI后置 | root / 完成19任务 | 65/451源和独立工程由协调实核；官方调用0。用户后置真实API，不再阻挡19.5/20；原全验不增。见DEC-P2-012。 |');
  s=s.replace(/^\| 19\.5 \|.*$/m,'| 19.5 | P2 | [生成内容质量与降级验收](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 进行中（默认关闭范围；真实模型质量后置） | root / 完成19任务 | 19.5-20261101-send1；只质量/降级与当前范围交接，不进20/Git，不等Key。见DEC-P2-012。 |');
 }
 writeFileSync(path,s);
}
console.log('Claim and user-authorized deferral recorded in all five current records.');
