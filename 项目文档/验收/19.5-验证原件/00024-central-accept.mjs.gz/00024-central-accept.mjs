import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
for(const path of ['README.md','项目守则.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md']){
 let s=readFileSync(path,'utf8');assert.ok(!s.includes('19.5本次范围验收通过（2026-11-01）'));
 const prefix=path.includes('/')?'./':'./项目文档/';
 const entry=`19.5本次范围验收通过（2026-11-01）：按用户“先完成后面的任务吧，我现在先不提供key后面再说，现在先是默认关闭”及[DEC-P2-012](${prefix}架构决策/19.5-默认关闭范围与真实API后置裁决.md)，19.4独立工程/19.5质量降级作为当前范围交付，真实指针/循环/无轨迹API成功、模型质量及20.4相应AI检查明确后置，不再阻挡后续。产品65/451源不变，原30组合460全域/6生成Rust/47生成前端/13唯一生成Chrome、2138完整正式前端、AI22前端/12网关Rust/24与21两套Chrome及15原事实等按精确SHA复核继承，未机械重跑；新3项Chrome同轮3/3及类型/lint/格式通过，错误建议无权限、默认关真实出题全域/全逆和全17store原始行键/local/session相等、实际模块失败回原课程与C执行齐。首轮失败原件保留，官方鉴权/推理0次。原全量仍82/88、主82/98、P2 13/19、第19全验3/5；本次范围另列84/88、主84/98、P2 15/19、第19当前范围5/5（3原全验+2范围验收/真实AI后置），不是原SRS全量AI成功。P0.5 9/9、21为0/10。见[验收](${prefix}验收/19.5-默认关闭范围质量与降级验收.md)、[降级/后置清单](${prefix}交付/19.5-默认关闭降级与后置AI清单.md)、[独立交接](${prefix}交接/19.5-交接.md)。旧7971归档/7960原路径、89旧19.3/17外窗及冻源/五WASM/SAVE9/DB9/预算保持。本轮不Git或进入20；交协调实核并另派第19当前范围Git，再另派20.1。第20当前授权范围验收/交接/远端实核后停止，不进入21，不自动补后置AI。`;
 const blank=/\r?\n\r?\n/.exec(s);assert.ok(blank);const at=blank.index+blank[0].length;s=s.slice(0,at)+entry+blank[0]+s.slice(at);
 if(path.endsWith('任务进度与交接.md')){
  s=s.replace(/^\| 19\.4 \|.*$/m,'| 19.4 | P2 | [基于真实轨迹的 AI 调试](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 本次范围验收通过；真实API后置 | root / 完成19任务 | 65/451独立工程由协调实核；官方0次，原全验不增；按DEC-P2-012可进入19.5/20，无Key等待。 |');
  s=s.replace(/^\| 19\.5 \|.*$/m,'| 19.5 | P2 | [生成内容质量与降级验收](<./任务包/第19步-实现薄弱点出题与 AI 可视化调试.md>) | 本次范围验收通过；真实模型质量后置 | root / 完成19任务 | 同SHA复用原件、新Chrome3/3及质量检查通过，官方0次；[验收](./验收/19.5-默认关闭范围质量与降级验收.md) / [交接](./交接/19.5-交接.md)。交协调实核，Git/20另派。 |');
  s=s.replace('第19当前3/5，19.4未领取，不Git。','本行计数为原子项验收历史时点；当前见19.4/19.5及DEC-P2-012。');
  s=s.replace('第19当前3/5，19.4未领取，不Git。','本行计数为原子项验收历史时点；当前见19.4/19.5及DEC-P2-012。');
  s=s.replace('第19为3/5不重复计数，19.4/19.5未开始，不Git。','设计修订不重复计数；当前19.4/19.5范围见DEC-P2-012，旧全验3/5保持。');
  const marker='阶段统计（19.3 API-Key设计修订验收后）：';assert.ok(s.includes(marker));
  s=s.replace(marker,'当前双口径统计（19.5本次范围验收后）：原全量原82/88、主82/98、P2 13/19、第19全验3/5；本次授权范围原84/88、主84/98、P2 15/19、第19为5/5（3原全验＋2范围通过/真实AI后置）。P0.5 9/9、21为0/10；20.1—20.4均未领取。第19当前范围可交协调质量实核/Git另派；不等待Key，不把后置项当原SRS通过。\n\n历史'+marker);
 }
 writeFileSync(path,s);
}
console.log('Current scoped acceptance recorded separately from original full acceptance.');
