import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
const read=p=>readFileSync(p),json=p=>JSON.parse(read(p).toString().replace(/^\uFEFF/,'')),sha=b=>createHash('sha256').update(b).digest('hex');
const proof=path=>({path,sha256:sha(read(path))});
const save=(path,value)=>writeFileSync(path,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const dir='.artifacts/19.5',reuse=json(dir+'/reuse-final.json'),browser=json(dir+'/browser-r2.json'),quality=json(dir+'/quality-r1.json');
assert.equal(browser.stats.expected,3);assert.equal(browser.stats.unexpected+browser.stats.skipped+browser.stats.flaky,0);assert.deepEqual(browser.errors,[]);assert.deepEqual(Object.values(quality).sort(),[0,0,0]);assert.equal(reuse.unchangedCurrentReviewedSources,451);assert.equal(reuse.oldArchives,7971);assert.equal(reuse.oldArtifactRawPaths,7960);
const first=json(dir+'/browser-r1.json');assert.equal(first.stats.expected,1);assert.equal(first.stats.unexpected,2);
const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(d+'/'+e.name):[d+'/'+e.name]);
const snapshots=walk(dir+'/browser-r2-output').filter(p=>p.endsWith('before-after.json'));assert.equal(snapshots.length,2);
for(const p of snapshots){const v=json(p);assert.deepEqual(v.before,v.after);assert.equal(v.before.databases['c-viz-learning'].version,9);assert.equal(v.before.databases['c-viz-learning'].names.length,17);assert.ok(!JSON.stringify(v).includes('DESIGN_ONLY_NOT_A_REAL_KEY'));}
const traces=walk(dir+'/browser-r2-output').filter(p=>p.endsWith('/actual-rust-and-simulated-api.json'));assert.equal(traces.length,3);for(const p of traces){const r=json(p);assert.equal(r.modelCalls,0);assert.equal(r.credentialCalls,0);assert.deepEqual(r.externalBrowserRequests,[]);assert.deepEqual(r.consoleErrors,[]);}
const reg=json('content/c/p0/blockly-release-1.0.65.json');assert.equal(sha(read(reg.aiGateway.executable.path)),reg.aiGateway.executable.sha256);
const build=json('.artifacts/artifact-hashes.json');for(const f of build.entries)assert.equal(sha(read(f.path)),f.sha256);save(dir+'/unchanged-built-files.json',{source:proof('.artifacts/artifact-hashes.json'),entries:build.entries,executable:reg.aiGateway.executable,rebuiltThisTask:false});
const central=['README.md','项目守则.md','项目文档/需求覆盖与范围裁决.md','项目文档/任务进度与交接.md','项目文档/开发路线与依赖.md'];
const docs=['项目文档/架构决策/19.5-默认关闭范围与真实API后置裁决.md','项目文档/验收/19.5-默认关闭范围质量与降级验收.md','项目文档/交付/19.5-默认关闭降级与后置AI清单.md','项目文档/交接/19.5-交接.md'];
mkdirSync(dir+'/document-snapshots');const documentSnapshots=[];for(const [i,path] of [...central,...docs].entries()){const file=`${dir}/document-snapshots/${i}.gz`;writeFileSync(file,gzipSync(read(path)),{flag:'wx'});documentSnapshots.push({original:proof(path),snapshot:proof(file)});}
for(const p of central){const s=read(p).toString();assert.ok(s.includes('19.5本次范围验收通过（2026-11-01）'));assert.ok(s.includes('原全量仍82/88'));}
const ledger=read('项目文档/任务进度与交接.md').toString();for(const n of [1,2,3,4])assert.match(ledger,new RegExp('\\| 20\\.'+n+' \\|[^\\n]+\\| 未开始 \\|'));
const result={task:'19.5',dispatch:'19.5-20261101-send1',date:'2026-11-01',currentAuthorizedScopeAccepted:true,originalSrsFullAiAccepted:false,step19CurrentAuthorizedScopeDelivered:true,userInstruction:'先完成后面的任务吧，我现在先不提供key后面再说，现在先是默认关闭',
 originalFullCounts:{original:'82/88',main:'82/98',P2:'13/19',step19:'3/5'},currentAuthorizedScopeCounts:{original:'84/88',main:'84/98',P2:'15/19',step19:'5/5',meaning:'3 original full acceptances + 2 scoped deliveries with live AI explicitly deferred'},P05:'9/9',step21:'0/10',
 release:{...proof('content/c/p0/blockly-release-1.0.65.json'),version:'1.0.65',sources:451,newProductSourceChanges:0,newReleaseRegistered:false,existingBuildVerified:proof(dir+'/unchanged-built-files.json')},
 freshChrome:{...proof(dir+'/browser-r2.json'),stats:browser.stats,singleRound:true,tests:3,nativeSnapshots:snapshots.map(proof),actualRustAndSimulatedApiRecords:traces.map(proof)},quality:{...proof(dir+'/quality-r1.json'),checks:quality},
 inheritance:{...proof(dir+'/reuse-final.json'),frontend:2138,generatorNativeTests:6,generatorIndependentCombinations:30,generatorCompleteFiniteInputs:460,generatorFrontend:47,generatorUniqueChrome:13,apiFrontend:22,proxyRust:12,formalChrome:24,currentRegressionChrome:21,originalRustContexts:15,fullSuitesRerunThisTask:false},
 protection:{baselineFiles:24433,oldArchives:7971,oldArtifactRawPaths:7960,old19_3Files:89,otherOwnerFiles:17,oldFrozen64:420,oldFrozen65:451,currentProductSources:451,baselineChanges:reuse.changed},
 firstRoundFailurePreserved:{...proof(dir+'/browser-r1.json'),passed:1,failed:2,beforeFixQa:proof(dir+'/qa-before-r1.spec.ts.gz'),reason:'New QA incorrectly used settings-only readiness marker on generated practice; actual app-shell readiness and exact existing course-link semantics used. Product and assertions unchanged.'},
 officialCredentialVerifications:0,officialModelCalls:0,actualTestedOfficialModels:[],simulatedAnswersAreNotModelQualityEvidence:true,
 deferredLiveAi:['19.4 official own-Key verification and pointer/loop/no-trace successful answers','19.5 real-model quality including wrong advice/unsupported inference and reference semantics','Actual provider permissions/quota/cost/retention/logging/cancellation observations','20.4 corresponding live-AI checks'],
 noKeyWaitBlockForCurrent19_5Or20:true,noAutomaticDeferredAiResumeAfter20:true,stopAfter20AndDoNotEnter21:true,
 notStartedThisTask:['20.1','20.2','20.3','20.4','21','Git stage/commit/push'],next:'Coordinator verifies current step19 quality/handoff, separately dispatches adjusted-scope step19 Git, then separately dispatches20.1. This task stops at19.5.',
 docs:docs.map(proof),documentSnapshots,git:reuse.git,retainedExistingScene:'http://127.0.0.1:4196/#/settings?panel=ai',priorRejectedProcessTransitionRetried:false,
};
save(dir+'/scoped-final.json',result);console.log(JSON.stringify({task:'19.5',currentAuthorizedScopeAccepted:true,originalSrsFullAiAccepted:false,newChrome:3,productSourceChanges:0,release:'1.0.65',officialCalls:0,deferredLiveAiStillUnverified:true}));
