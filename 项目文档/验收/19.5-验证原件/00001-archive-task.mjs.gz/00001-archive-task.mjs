import assert from 'node:assert/strict';
import {readdirSync,readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {basename} from 'node:path';
const target='项目文档/验收/19.5-验证原件';assert.equal(existsSync(target),false);
const sha=b=>createHash('sha256').update(b).digest('hex');
const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(d+'/'+e.name):[d+'/'+e.name]);
const sources=[...walk('.artifacts/19.5'),'tests/quality-19.5.config.ts',...walk('tests/quality-19.5')].sort();assert.equal(new Set(sources).size,sources.length);mkdirSync(target,{recursive:true});
const files=sources.map((source,i)=>{const raw=readFileSync(source),compress=/\.(?:json|log|txt|mjs|ts|tsx|md|css|html|ps1)$/.test(source);const b=compress?gzipSync(raw):raw,file=String(i+1).padStart(5,'0')+'-'+basename(source)+(compress?'.gz':'');writeFileSync(target+'/'+file,b,{flag:'wx'});return{source,file,bytes:raw.length,sha256:sha(raw),archiveBytes:b.length,archiveSha256:sha(b),encoding:compress?'gzip':'identity'};});
writeFileSync(target+'/index.json',JSON.stringify({version:'1.0.0',task:'19.5',at:new Date().toISOString(),scope:'Current default-off authorized quality scope, explicit user deferral/dual counts, immutable baseline and exact-SHA inherited evidence, new genuine Rust Chrome behavior and simulated wrong-advice boundaries, all failures/before-fix QA, full native keyed DB9/local/session snapshots, current document snapshots, no official authentication/inference, no product edits.',files},null,2)+'\n',{flag:'wx'});
for(const f of files){const b=readFileSync(target+'/'+f.file);assert.equal(sha(b),f.archiveSha256);assert.equal(sha(f.encoding==='gzip'?gunzipSync(b):b),f.sha256);assert.equal(sha(readFileSync(f.source)),f.sha256);}
console.log(JSON.stringify({task:'19.5',archives:files.length,artifactRawPaths:files.filter(f=>f.source.startsWith('.artifacts/')).length,allThreeLayersVerified:true}));
